using OccultPot.Core.Session;
using OccultPot.Core.Game;
using OccultPot.Core;
using OccultPot.Models;
using Clock=OccultPot.Core.Session.Environment;

int passed=0,failed=0;
var inside=new ExitSnapshot(1252,true,true,true,false,false,false,1200,true,false);
var outside=inside with {Territory=1055,OnIsland=false,InDuty=false,RemainingSeconds=null};
void Check(bool value,string message="unexpected result"){if(!value)throw new Exception(message);}
void Run(string name,Action test){try{Clock.TickCount64=0;IslandExitWorld.Snapshot=inside;IslandExitWorld.Logs.Clear();IslandExitWorld.Sends.Clear();IslandExitWorld.Throw=false;test();passed++;Console.WriteLine("PASS "+name);}catch(Exception ex){failed++;Console.WriteLine("FAIL "+name+": "+ex.Message);}}
ExitRecoveryController New(){var c=new ExitRecoveryController(new IslandExitWorld());c.Begin(0,inside,false,"round-ended");return c;}
ExitTickResult Tick(ExitRecoveryController c,double time,ExitSnapshot? s=null){Clock.TickCount64=(long)(time*1000);return c.Tick(time,s??inside);}
void SessionTick(PotSessionOrchestrator p,double time,ExitSnapshot? s=null){Clock.TickCount64=(long)(time*1000);IslandExitWorld.Snapshot=s??inside;p.TickExitSafety();}
Run("first timeout remains active and retries original method",()=>{var c=New();Tick(c,0);Tick(c,30);Check(c.Active&&c.Recovering&&c.Attempt==2&&c.Method==ExitMethod.Callback);});
Run("second timeout switches to native normal exit",()=>{var c=New();Tick(c,0);Tick(c,30);Tick(c,60);Check(c.Active&&c.Recovering&&c.Attempt==3&&c.Method==ExitMethod.NativeDutyExit);});
Run("long recovery survives 4 hours with 20s cadence",()=>{var c=New();Tick(c,0);Tick(c,30);Tick(c,60);for(int t=61;t<=14400;t++)Tick(c,t);var sends=IslandExitWorld.Sends.Where(x=>x.Time>=60).GroupBy(x=>(int)((x.Time-60)/20)).ToArray();Check(c.Active&&c.Recovering&&c.Attempt>700);foreach(var g in sends)Check(g.Max(x=>x.Time)-g.Min(x=>x.Time)<8);Check(IslandExitWorld.Logs.Count(x=>x.Contains("success"))==0);});
Run("attempt interaction window closes after 8 seconds",()=>{var c=New();Tick(c,0);Tick(c,7);var n=IslandExitWorld.Sends.Count;for(int t=8;t<30;t++)Tick(c,t);Check(IslandExitWorld.Sends.Count==n);});
Run("busy state reaches adapter for owned confirmation",()=>{var c=New();Tick(c,0,inside with {Busy=true});Check(IslandExitWorld.Sends.Count==1);});
foreach(var blocked in new[]{inside with{Combat=true},inside with{Available=false},inside with{BetweenAreas=true}})
Run("blocked snapshot never invokes game actions "+blocked,()=>{var c=New();for(int t=0;t<=100;t++)Tick(c,t,blocked);Check(c.Active&&IslandExitWorld.Sends.Count==0);});
Run("rechecks player after it becomes available",()=>{var c=New();Tick(c,0,inside with{Available=false});Tick(c,1);Check(IslandExitWorld.Sends.Count==1);});
Run("no false completion for territory zero",()=>{var c=New();Tick(c,0,outside with{Territory=0});Tick(c,5,outside with{Territory=0});Check(c.Active);});
foreach(var unstable in new[]{outside with{InDuty=true},outside with{Available=false},outside with{BetweenAreas=true},outside with{Busy=true}})
Run("outside transition must settle "+unstable,()=>{var c=New();Tick(c,0,unstable);Tick(c,10,unstable);Check(c.Active);});
Run("completion needs two stable seconds and resets controller",()=>{var c=New();Tick(c,0);Check(Tick(c,1,outside)==ExitTickResult.Waiting);Check(Tick(c,2.9,outside)==ExitTickResult.Waiting);Check(Tick(c,3,outside)==ExitTickResult.Completed);Check(!c.Active&&!c.Emergency&&c.Attempt==0);Check(Tick(c,4,outside)==ExitTickResult.Idle);});
Run("interrupted outside settlement restarts window",()=>{var c=New();Tick(c,1,outside);Tick(c,2,inside);Tick(c,3,outside);Check(Tick(c,4,outside)==ExitTickResult.Waiting);Check(Tick(c,5,outside)==ExitTickResult.Completed);});
Run("watchdog rearms after long frame gap",()=>{var c=New();Tick(c,0);Tick(c,46);Check(c.Active&&c.Recovering&&c.Attempt==2);Check(IslandExitWorld.Logs.Any(x=>x.Contains("watchdog")));});
Run("watchdog does not preempt active round work",()=>{var c=New();Tick(c,0);Tick(c,46,inside with{HasWork=true});Check(!IslandExitWorld.Logs.Any(x=>x.Contains("watchdog")));});
Run("game exception enters recovery and waits twenty seconds",()=>{var c=New();IslandExitWorld.Throw=true;Tick(c,0);Tick(c,1);Tick(c,19);Check(c.Active&&c.Recovering&&IslandExitWorld.Sends.Count==1);IslandExitWorld.Throw=false;Tick(c,20);Check(c.Attempt==2&&IslandExitWorld.Sends.Count==2);});
Run("stop cancels all future retries",()=>{var c=New();Tick(c,0);c.Reset();var n=IslandExitWorld.Sends.Count;Tick(c,100);Check(!c.Active&&IslandExitWorld.Sends.Count==n);});
Run("emergency default threshold requires stable low observation",()=>{var c=New();var s=inside with{RemainingSeconds=299};Check(!c.ShouldEmergency(0,s,5));Check(!c.ShouldEmergency(.9,s,5));Check(c.ShouldEmergency(1,s,5));});
Run("five minute boundary is strictly below threshold",()=>{var c=New();Check(!c.ShouldEmergency(0,inside with{RemainingSeconds=300},5));Check(!c.ShouldEmergency(5,inside with{RemainingSeconds=300},5));});
Run("configured threshold respected",()=>{var c=New();var s=inside with{RemainingSeconds=500};Check(!c.ShouldEmergency(0,s,10));Check(c.ShouldEmergency(1,s,10));Check(!c.ShouldEmergency(2,s,5));});
foreach(double? bad in new double?[]{null,0,-1,double.NaN,double.PositiveInfinity})
Run("unknown or initial invalid timer ignored "+bad,()=>{var c=New();Check(!c.ShouldEmergency(0,inside with{RemainingSeconds=bad},5));Check(!c.ShouldEmergency(10,inside with{RemainingSeconds=bad},5));});
Run("known positive timer reaching zero triggers emergency",()=>{var c=New();c.ShouldEmergency(0,inside,5);Check(!c.ShouldEmergency(1,inside with{RemainingSeconds=0},5));Check(c.ShouldEmergency(2,inside with{RemainingSeconds=0},5));});
Run("new island resets timer validity",()=>{var c=New();c.ShouldEmergency(0,inside,5);Check(!c.ShouldEmergency(1,inside with{Territory=1346,RemainingSeconds=0},5));Check(!c.ShouldEmergency(4,inside with{Territory=1346,RemainingSeconds=0},5));});
Run("emergency latched across timer loss and busy state",()=>{var c=New();c.Begin(0,inside,true,"time-low");Tick(c,0);Tick(c,30,inside with{RemainingSeconds=null,Busy=true});Check(c.Emergency&&c.Active&&c.Recovering);});
Run("promoting recovery to emergency preserves attempt budget",()=>{var c=New();Tick(c,0);Tick(c,30);c.Begin(31,inside,true,"time-low");Check(c.Attempt==2&&c.Emergency);Tick(c,60);Check(c.Attempt==3&&c.Method==ExitMethod.NativeDutyExit);});
Run("diagnostics include all required snapshot fields",()=>{var c=New();Tick(c,0);Tick(c,30);var log=string.Join("\n",IslandExitWorld.Logs);foreach(var key in new[]{"attempt=#","method=","Territory=","IsInDuty=","Player.Available=","Player.Busy=","elapsed=","attemptWait=","timeout","ExitRecovery=","nextRetry=","EmergencyExit=","reason="})Check(log.Contains(key),key);});
Run("production session leave cancels all work and survives timeout",()=>{var p=new PotSessionOrchestrator();p.EnableWork();p.BeginTest();Check(!p.HasWork&&p.IsRunning);SessionTick(p,0);SessionTick(p,30);SessionTick(p,60);Check(p.Phase==SessionPhase.ExitRecovery&&p.IsRunning&&p.Attempt==3);});
Run("production session repeated leave request preserves attempts",()=>{var p=new PotSessionOrchestrator();p.BeginTest();SessionTick(p,0);SessionTick(p,30);p.BeginTest();Check(p.Attempt==2);});
foreach(var pair in new[]{(0,SessionPhase.PlanRoute),(1,SessionPhase.EnsureWorld),(2,SessionPhase.ReadyIsland)})
Run("production session resumes original destination "+pair,()=>{var p=new PotSessionOrchestrator();p.BeginTest(pair.Item1);SessionTick(p,0);SessionTick(p,30);SessionTick(p,31,outside);SessionTick(p,33,outside);Check(!p.IsExiting&&p.Phase==pair.Item2);});
Run("production session intercepts stale exit timeout Fail",()=>{var p=new PotSessionOrchestrator();Check(p.FailTest(RuntimeStatusCode.Leave_Timeout));Check(p.IsExiting&&p.IsRunning);});
Run("unrelated failure policy is unchanged outside exit",()=>{var p=new PotSessionOrchestrator();Check(!p.FailTest(RuntimeStatusCode.ErrorEmptyRoute));});
Run("watchdog reconstructs lost controller without task queue",()=>{var p=new PotSessionOrchestrator();p.SetPhase(SessionPhase.WaitLeave);SessionTick(p,46);Check(p.Attempt==1&&p.IsRunning);Check(IslandExitWorld.Logs.Any(x=>x.Contains("watchdog")));});
Run("emergency preempts active FATE/dig/carrot in production partial",()=>{var p=new PotSessionOrchestrator();p.SetPhase(SessionPhase.WaitFight);p.EnableWork();var low=inside with{RemainingSeconds=100};SessionTick(p,0,low);SessionTick(p,1,low);Check(p.Phase==SessionPhase.EmergencyExit&&!p.HasWork&&p.IsExiting);SessionTick(p,2,inside with{RemainingSeconds=null});Check(p.Phase==SessionPhase.EmergencyExit);});
Run("standalone emergency completes without requiring a route",()=>{var p=new PotSessionOrchestrator();p.SetPhase(SessionPhase.Idle);p.EnableWork();var low=inside with{RemainingSeconds=100};SessionTick(p,0,low);SessionTick(p,1,low);Check(!p.HasWork&&p.IsExiting);SessionTick(p,2,outside);SessionTick(p,4,outside);Check(!p.IsExiting&&p.Phase==SessionPhase.Idle);});
Run("production manual stop does not rearm old recovery",()=>{var p=new PotSessionOrchestrator();p.BeginTest();SessionTick(p,0);p.StopTest();SessionTick(p,60);Check(!p.IsExiting);});

T Field<T>(object obj,string name)=>(T)obj.GetType().GetField(name,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic)!.GetValue(obj)!;
void ServiceTick(OccultPotService svc,double time,ExitSnapshot snapshot){Clock.TickCount64=(long)(time*1000);IslandExitWorld.Snapshot=snapshot;svc.Tick();}
Run("production service preserves Enabled during normal exit recovery",()=>{
 var cfg=new OccultPot.PluginConfiguration();var svc=new OccultPotService(()=>cfg,()=>{});svc.Start();
 Field<PotSessionOrchestrator>(svc,"session").BeginTest();
 ServiceTick(svc,0,inside);ServiceTick(svc,30,inside);ServiceTick(svc,60,inside);
 Check(cfg.Enabled&&svc.IsRunning&&svc.Phase==SessionPhase.ExitRecovery);
 ServiceTick(svc,61,outside);ServiceTick(svc,63,outside);Check(cfg.Enabled&&svc.Phase==SessionPhase.PlanRoute);
});
Run("dig-only emergency cancellation does not disable plugin via stop callback",()=>{
 var cfg=new OccultPot.PluginConfiguration();int saves=0;var svc=new OccultPotService(()=>cfg,()=>saves++);svc.StartDigOnly();
 var low=inside with{RemainingSeconds=100};ServiceTick(svc,0,low);var dig=Field<OccultPot.Core.Dig.PotDigController>(svc,"dig");int ticks=dig.Ticks;
 ServiceTick(svc,1,low);Check(cfg.Enabled&&svc.IsRunning&&svc.Phase==SessionPhase.EmergencyExit&&!dig.IsActive&&dig.Ticks==ticks);
 ServiceTick(svc,31,low);Check(cfg.Enabled&&dig.Ticks==ticks);
 ServiceTick(svc,32,outside);ServiceTick(svc,34,outside);Check(cfg.Enabled&&!svc.IsDigOnlyMode&&svc.Phase==SessionPhase.PlanRoute);
});
Run("carrot-only emergency freezes work then returns to enabled original mode",()=>{
 var cfg=new OccultPot.PluginConfiguration{RunMode=RunMode.Carrot};var svc=new OccultPotService(()=>cfg,()=>{});svc.Start();
 var low=inside with{RemainingSeconds=100};ServiceTick(svc,0,low);var carrot=Field<OccultPot.Core.Carrot.CarrotRunner>(svc,"carrot");int ticks=carrot.Ticks;
 ServiceTick(svc,1,low);ServiceTick(svc,31,low);Check(cfg.Enabled&&svc.Phase==SessionPhase.EmergencyExit&&carrot.Ticks==ticks&&!carrot.IsActive&&svc.CarrotStatus==null);
 ServiceTick(svc,32,outside);ServiceTick(svc,34,outside);Check(cfg.Enabled&&svc.IsRunning&&svc.Phase==SessionPhase.Idle);
});
Run("service stop disables and cannot revive emergency",()=>{
 var cfg=new OccultPot.PluginConfiguration{RunMode=RunMode.Carrot};var svc=new OccultPotService(()=>cfg,()=>{});svc.Start();
 var low=inside with{RemainingSeconds=100};ServiceTick(svc,0,low);ServiceTick(svc,1,low);svc.Stop();var count=IslandExitWorld.Sends.Count;
 ServiceTick(svc,100,low);Check(!cfg.Enabled&&!svc.IsRunning&&IslandExitWorld.Sends.Count==count);
});
Run("service keeps original fail-safe for unrelated session failure",()=>{
 var cfg=new OccultPot.PluginConfiguration();var svc=new OccultPotService(()=>cfg,()=>{});svc.Start();
 Field<PotSessionOrchestrator>(svc,"session").SetPhase(SessionPhase.Failed);ServiceTick(svc,0,inside);Check(!cfg.Enabled);
});
Run("lost controller outside still completes without a manual restart",()=>{var p=new PotSessionOrchestrator();p.SetPhase(SessionPhase.WaitLeave);SessionTick(p,1,outside);SessionTick(p,3,outside);Check(!p.IsExiting&&p.Phase==SessionPhase.PlanRoute);});

Run("standalone search timeout during dig tick keeps Enabled through recovery",()=>{
 var cfg=new OccultPot.PluginConfiguration();var svc=new OccultPotService(()=>cfg,()=>{});svc.StartDigOnly();
 Field<OccultPot.Core.Dig.PotDigController>(svc,"dig").StopOnTick=OccultPot.Core.Dig.StopReason.SearchTimeout;
 ServiceTick(svc,60,inside);Check(cfg.Enabled&&!svc.IsDigOnlyMode&&svc.Phase==SessionPhase.WaitLeave);
 ServiceTick(svc,90,inside);ServiceTick(svc,120,inside);Check(cfg.Enabled&&svc.Phase==SessionPhase.ExitRecovery);
 ServiceTick(svc,121,outside);ServiceTick(svc,123,outside);Check(cfg.Enabled&&svc.Phase==SessionPhase.PlanRoute);
 Check(cfg.ActivityHistory.Entries.Any(x=>x.Type=="Abort"&&x.Reason.Contains("搜索超时")));
});
Run("service manual stop persists reason and timestamp after stopped",()=>{
 var cfg=new OccultPot.PluginConfiguration();int saves=0;var svc=new OccultPotService(()=>cfg,()=>saves++);svc.Start();svc.Stop();
 Check(!cfg.Enabled&&cfg.ActivityHistory.LastStop?.Reason=="用户停止"&&cfg.ActivityHistory.LastStop.At!=default&&saves>0);
});
Console.WriteLine($"RESULT: {passed} passed, {failed} failed");System.Environment.ExitCode=failed==0?0:1;
