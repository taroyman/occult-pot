using OccultPot.Models;
using OccultPot.Core.Session;
using OccultPot.Core;

// Game boundary and unrelated session work are simulated. The exit partial and controller are production files.
namespace OccultPot.Core.Game
{
    internal sealed class IslandExitWorld : IIslandExitWorld
    {
        internal static ExitSnapshot Snapshot;
        internal static List<string> Logs = [];
        internal static List<(double Time, ExitMethod Method)> Sends = [];
        internal static bool Throw;
        internal static ExitSnapshot Read(bool ended, bool work) => Snapshot with { RoundEnded=ended, HasWork=work };
        public void ResetAttempt() { }
        public string TickAttempt(ExitMethod method)
        {
            Sends.Add((OccultPot.Core.Session.Environment.TickCount64/1000d,method));
            if(Throw) throw new InvalidOperationException("UI unavailable");
            return "request-accepted";
        }
        public void Log(string message) => Logs.Add(message);
    }
}
namespace OccultPot.Core.Adapters
{
    internal static class BmrAi { internal static int Offs; internal static void ForceOff()=>Offs++; }
}
namespace OccultPot.Core.Session
{
    // Resolve the production partial's monotonic clock against a deterministic clock in this test assembly only.
    internal static class Environment { internal static long TickCount64; }
    internal sealed partial class PotSessionOrchestrator
    {
        private enum AfterLeave { Advance, ResumeEnsureWorld, ResumeIslandVisit }
        private AfterLeave afterLeave;
        private SessionPhase phase=SessionPhase.FindPot;
        private RuntimeStatus status;
        private readonly TreasureStub treasure=new();
        private readonly RouteStub route=new();
        private ushort targetTerritory;
        private uint committedWorldID;
        private void RememberSkippedIsland(){}
        internal void RecordActivity(string type,string reason) => activity?.Invoke(type,reason);
        private Action<string,string>? activity;
        internal string ActivityContext=>"DC=test; World=1; Instance=test";
        internal bool TreasureOwnsControl=>false;
        internal void TickTreasureCleanup(){}
        private sealed class TreasureStub { internal void Cancel(double t,string reason){} }
        private sealed class RouteStub {internal void Build(OccultPot.PluginConfiguration config){} }
        private readonly Worker taskHelper=new(),find=new(),vnav=new(),fateDismount=new();
        private readonly OccultPot.Core.Carrot.CarrotRunner carrot=new();
        private readonly OccultPot.Core.Dig.PotDigController dig=new();
        private bool carrotOwnsMovement;
        private object? activeLayout=new();
        private readonly Func<OccultPot.PluginConfiguration> getConfig=()=>new();
        private double phaseStart;
        internal bool IsRunning=> phase is not SessionPhase.Idle and not SessionPhase.Completed and not SessionPhase.Failed;
        internal int Resumes;
        internal SessionPhase Phase=>phase;
        internal int Attempt=>exit.Attempt;
        internal void BeginTest(int resume=0) { afterLeave=(AfterLeave)resume; BeginLeave(RuntimeStatus.Of(RuntimeStatusCode.Leave_DigDone)); }
        internal void SetPhase(SessionPhase p)=>phase=p;
        internal void EnableWork(){ dig.IsActive=carrot.IsActive=true; carrotOwnsMovement=true; }
        internal bool HasWork=>dig.IsActive||carrot.IsActive||carrotOwnsMovement;
        internal bool FailTest(RuntimeStatusCode code)=>TryRecoverExitFailure(RuntimeStatus.Of(code));
        internal void StopTest(){ exit.Reset(); standaloneExit=false; phase=SessionPhase.Idle; }
        private void Enter(SessionPhase p,RuntimeStatus s){ if(phase!=p)phaseStart=Environment.TickCount64/1000d;phase=p;status=s; }
        private bool TimedOut(double s)=>Environment.TickCount64/1000d-phaseStart>=s;
        private void AdvanceAfterLeave(){Resumes++;Enter(SessionPhase.PlanRoute,default);}
        private void BeginIslandVisit(){Resumes++;Enter(SessionPhase.ReadyIsland,default);}
        internal PotSessionOrchestrator() {}
        internal PotSessionOrchestrator(Func<OccultPot.PluginConfiguration> config,OccultPot.Core.Dig.PotDigController d,OccultPot.Core.Carrot.CarrotRunner c,Action<string,string>? record=null){activity=record;getConfig=config;dig=d;carrot=c;phase=SessionPhase.Idle;}
        internal RuntimeStatus Status=>status;
        internal string RouteSummary=>"";
        internal RuntimeStatus TrackerStatus=>default;
        internal RuntimeStatus TrackerCatalog=>default;
        internal PotKind? ActiveKind=>null;
        internal bool CanSkipCurrentIsland=>false;
        internal bool IsPotFateCombat=>false;
        internal bool ShouldKeepPotFateTarget()=>false;
        internal bool TryGetCurrentTargetLabel(out string l){l="";return false;}
        internal bool TryGetNextTargetLabel(out string l){l="";return false;}
        internal void Tick() {}
        internal void OnDigStopped(OccultPot.Core.Dig.StopReason r) {}
        internal void OnChatMessage(string s) {}
        internal void Start(){StopTest();phase=SessionPhase.PlanRoute;Resumes++;}
        internal void Stop()=>StopTest();
        internal void Uninit()=>StopTest();
        internal void RequestSkipIsland()=>BeginTest();
        private sealed class Worker
        {
            internal bool IsActive;
            internal void Abort(){} internal void Stop()=>IsActive=false;
            internal void Reset(){} internal void Cancel(string _) => IsActive=false;
        }
    }
}

namespace OccultPot
{
    internal class PluginConfiguration
    {
        internal bool Enabled,PreferTp=true,UseDiveTp=true;
        internal RunMode RunMode;
        internal int EmergencyExitThresholdMinutes=5;
        internal long CarrotChestsOpened;
        internal float TpIntervalSeconds=5;
        internal DigStatistics DigStatistics=new();
        internal ActivityHistory ActivityHistory=new();
        internal void NormalizeCarrot(){} internal void SyncHomeWorldLock(){}
    }
}
namespace OccultPot.Core.Carrot
{
    internal class CarrotGameWorld {}
    internal class CarrotRunner
    {
        internal bool IsActive;
        internal int Ticks;
        internal string Status=>"carrot";
        internal string TargetLabel=>"target";
        internal CarrotRunner(){}
        internal CarrotRunner(CarrotGameWorld w,Action a,Action<string,string>? record=null){}
        internal void Cancel(string s)=>IsActive=false;
        internal bool TryStart(double t,OccultPot.PluginConfiguration c){IsActive=true;return true;}
        internal void Tick(double t,OccultPot.PluginConfiguration c)=>Ticks++;
    }
}
namespace OccultPot.Core.Dig
{
    internal struct OccultPotSnapshot {}
    internal sealed class PotDigController
    {
        internal bool IsActive;
        internal int Ticks;
        private Action<StopReason>? stopped;
        internal PotDigController(){}
        internal PotDigController(Action<StopReason> s,Func<bool> a,Func<bool>b,Func<float>c,Action<bool,ChestGrade>d){stopped=s;}
        internal void Stop(){IsActive=false;stopped?.Invoke(StopReason.UserRequested);}
        internal StopReason? StopOnTick;
        internal void Tick(){Ticks++;if(StopOnTick is {} r){IsActive=false;StopOnTick=null;stopped?.Invoke(r);}}
        internal (bool Success,int Unused) Start(){IsActive=true;return (true,0);}
        internal OccultPotSnapshot? GetSnapshot()=>null;
    }
}
namespace OccultPot.Core
{
    internal static class OccultPotRuntime { internal static bool RequireSupported()=>true; }
}
namespace OccultPot.Core.Adapters { internal static class ExternalCommands { internal static void Echo(string s){} } }
namespace OccultPot.Core.Data { internal static class ZoneIds {internal static bool IsSupportedIsland(ushort id)=>id is 1252 or 1346;} }
namespace OccultPot.Core.Session
{
    internal static class SessionBriefFormatter
    {internal static string Activity(OccultPotService s)=>"";internal static string CurrentTarget(OccultPotService s)=>"";internal static string NextTarget(OccultPotService s)=>"";}
}
namespace OmenTools
{
    internal sealed class DService
    {internal static DService Instance()=>new();internal Client ClientState=new();internal class Client{internal uint TerritoryType=1252;}}
}
namespace OmenTools.Dalamud
{
    internal static class DLog{internal static void Debug(string s){}internal static void Error(string s,Exception e){}}
}
namespace Dalamud.Game.Chat
{
    internal interface IHandleableChatMessage{}
    internal interface IMutableChatMessage {ChatText Message{get;}}
    internal class ChatText{internal string TextValue=>"";}
}

namespace OmenTools.OmenService { internal static class GameState {internal static uint TerritoryType=1252;} }
namespace OccultPot.Core.Data { internal static class CnWorldCatalog {internal static uint CurrentWorldID=>1;} }
