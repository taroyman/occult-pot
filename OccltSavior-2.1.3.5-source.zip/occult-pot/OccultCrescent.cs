using Dalamud.Game.Chat;
using Dalamud.Game.Command;
using Dalamud.Game.Gui.Toast;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using OccultPot.Core;
using OccultPot.Core.Game;
using OccultPot.Core.Dig;
using OccultPot.Ui;
using OmenTools;
using OmenTools.Dalamud;
using OmenTools.OmenService;

namespace OccultPot;

internal sealed class OccultCrescent : IDisposable
{
    internal const string CommandName = "/ocsa";
    internal const string Title = "新月岛拯救者";
    internal const string Description = "新月岛拯救者：自动挖罐、自动胡萝卜";

    internal static PluginConfiguration Config { get; private set; } = new();

    private readonly IDalamudPluginInterface pluginInterface;
    private readonly IPluginLog log;
    private readonly ICommandManager commands;
    private readonly OccultPotService service;
    private readonly MainWindow mainWindow;
    private readonly PotTalkHooks talkHooks;

    internal OccultCrescent(
        IDalamudPluginInterface pluginInterface,
        ICommandManager commands,
        IPluginLog log)
    {
        this.pluginInterface = pluginInterface;
        this.log = log;
        this.commands = commands;

        Config = ConfigurationLoader.Load(pluginInterface.ConfigFile.FullName, message => log.Information(message), out var migratedIdentity);
        var migratedSchema = MigrateConfig(Config);
        if (migratedSchema || migratedIdentity)
            pluginInterface.SavePluginConfig(Config);

        service = new OccultPotService(() => Config, SaveConfig);
        mainWindow = new MainWindow(Config, SaveConfig, service);
        WindowManager.Instance().AddWindow(mainWindow);

        pluginInterface.UiBuilder.OpenMainUi += OpenMainUI;
        pluginInterface.UiBuilder.OpenConfigUi += OpenMainUI;

        commands.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开新月岛拯救者。/ocsa start | stop | skip | dig",
        });

        FrameworkManager.Instance().Reg(OnTargetTick, 100);
        FrameworkManager.Instance().Reg(OnServiceTick, 200);

        DService.Instance().Chat.ChatMessage += OnChatMessage;
        DService.Instance().Toast.Toast += OnToast;

        talkHooks = new PotTalkHooks(text => service.OnChatText(text));
        talkHooks.Enable();

        log.Information("[OccltSavior] Loaded. Use {Command}.", CommandName);
    }

    private void OnChatMessage(IHandleableChatMessage message) =>
        service.OnChatMessage(message);

    private void OnToast(ref SeString message, ref ToastOptions options, ref bool isHandled) =>
        service.OnChatText(message.TextValue);

    private void OnTargetTick(IFramework framework)
    {
        if (Config.Enabled)
            PotFateTargeter.Tick(service.ShouldKeepPotFateTarget());
        else
            PotFateTargeter.Idle();
    }

    private void OnServiceTick(IFramework framework)
    {
        service.Tick(); // Also retry a pending DR job restore after a user stop.
    }

    private void OnCommand(string command, string args)
    {
        var trimmed = args.Trim();
        if (trimmed.Equals("start", StringComparison.OrdinalIgnoreCase))
        {
            service.Start();
            return;
        }

        if (trimmed.Equals("stop", StringComparison.OrdinalIgnoreCase))
        {
            service.Stop();
            return;
        }

        if (trimmed.Equals("skip", StringComparison.OrdinalIgnoreCase) ||
            trimmed.Equals("next", StringComparison.OrdinalIgnoreCase))
        {
            service.SkipCurrentIsland();
            return;
        }

        if (trimmed.Equals("dig", StringComparison.OrdinalIgnoreCase))
        {
            service.StartDigOnly();
            return;
        }

        OpenMainUI();
    }

    private void OpenMainUI() => mainWindow.IsOpen = true;

    private void SaveConfig() => pluginInterface.SavePluginConfig(Config);

    private static bool MigrateConfig(PluginConfiguration config)
    {
        var migrated = false;

        if (config.Version < 17)
        {
            if (config.WindowWidth >= 600f || config.WindowHeight >= 620f)
            {
                config.WindowWidth = 520f;
                config.WindowHeight = 460f;
            }

            config.Version = 17;
            migrated = true;
        }

        if (config.Version < 18)
        {
            if (config.WindowWidth > 0f && config.WindowWidth <= 520f)
                config.WindowWidth = 560f;

            config.Version = 18;
            migrated = true;
        }

        if (config.Version < 19)
        {
            config.RunMode = Models.RunMode.Pot;
            config.Version = 19;
            migrated = true;
        }
        config.NormalizeCarrot();
        return migrated;
    }

    public void Dispose()
    {
        talkHooks.Dispose();

        DService.Instance().Toast.Toast -= OnToast;
        DService.Instance().Chat.ChatMessage -= OnChatMessage;

        FrameworkManager.Instance().Unreg(OnTargetTick, OnServiceTick);

        commands.RemoveHandler(CommandName);

        pluginInterface.UiBuilder.OpenMainUi -= OpenMainUI;
        pluginInterface.UiBuilder.OpenConfigUi -= OpenMainUI;

        WindowManager.Instance().RemoveWindow(mainWindow);

        service.Uninit();
    }
}
