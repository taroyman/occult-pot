using Dalamud.Bindings.ImGui;
using OccultPot.Models;

namespace OccultPot.Ui;

internal static class CarrotSection
{
    internal static void Draw(PluginConfiguration config, Action save, bool running)
    {
        ImGui.TextUnformatted("新月岛拯救者 · 2.1.3.5");
        ImGui.BeginDisabled(running);
        string[] modes = ["自动挖罐", "自动胡萝卜", "自动挖罐跑刀"];
        RunMode[] values = [RunMode.Pot, RunMode.Carrot, RunMode.AutoPotTreasure];
        var mode = Math.Max(0, Array.IndexOf(values, config.RunMode));
        var changed = ImGui.Combo("运行模式", ref mode, modes, modes.Length);
        if (changed) config.RunMode = values[mode];
        ImGui.EndDisabled();
        changed |= ImGui.Checkbox("挖罐等待期间允许胡萝卜", ref config.PotIdleCarrots);
        changed |= ImGui.Checkbox("启用自动胡萝卜", ref config.AutoCarrotEnabled);
        ImGui.BeginDisabled(running);
        if (RunModePolicy.UsesTreasure(config.RunMode))
        {
            ImGui.TextWrapped("进岛后使用魔寻宝；铜箱达到阈值时，传送至预备点并联动 DR 外环、内环，结束后继续挖罐。");
            changed |= ImGui.InputInt("铜宝箱阈值（大于等于）", ref config.BronzeTreasureThreshold);
        }
        ImGui.EndDisabled();
        changed |= ImGui.Checkbox("胡萝卜 DiveTP 玩家安全检测", ref config.CarrotPlayerSafetyEnabled);
        if (!config.CarrotPlayerSafetyEnabled) ImGui.TextWrapped("安全检测关闭时暂停胡萝卜任务；挖罐保持原行为。");
        changed |= ImGui.SliderFloat("玩家半径（米）", ref config.CarrotSafetyRadius, 10, 100);
        changed |= ImGui.SliderFloat("二次确认（秒）", ref config.CarrotConfirmSeconds, 0.5f, 10);
        changed |= ImGui.SliderFloat("Pot 前停止（秒）", ref config.CarrotStopBeforePotSeconds, 10, 180);
        changed |= ImGui.SliderFloat("Pot 前允许开始（秒）", ref config.CarrotStartBeforePotSeconds, 30, 600);
        if (changed) { config.NormalizeCarrot(); save(); }
        ImGui.TextWrapped("等待期间的胡萝卜仅在当前实例时间可信时启动。先DiveTP探测候选点，落地识别痕迹后两次检测玩家；只检测客户端已加载的玩家。");
        ImGui.Separator();
    }
}
