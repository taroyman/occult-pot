using Dalamud.Configuration;
using OccultPot.Core.Data;
using OccultPot.Models;

namespace OccultPot;


public sealed class PluginConfiguration : IPluginConfiguration
{
	public DigStatistics DigStatistics = new();
	public bool Enabled;
    public int EmergencyExitThresholdMinutes = 5;
    public ActivityHistory ActivityHistory = new();
    public int BronzeTreasureThreshold = 30;
    public bool PotIdleCarrots;
    public bool SectionParametersExpanded;
    public RunMode RunMode = RunMode.Pot;
    public bool AutoCarrotEnabled = true;
    public bool CarrotPlayerSafetyEnabled = true;
    public float CarrotSafetyRadius = 60f;
    public float CarrotConfirmSeconds = 1.5f;
    public float CarrotStartBeforePotSeconds = 90f;
    public float CarrotStopBeforePotSeconds = 30f;
    public long CarrotChestsOpened;

    public void NormalizeCarrot()
    {
        static float Bound(float n, float fallback, float min, float max) => float.IsFinite(n) ? Math.Clamp(n, min, max) : fallback;
        EmergencyExitThresholdMinutes = Math.Clamp(EmergencyExitThresholdMinutes, 1, 30);
        NorthNearStepMeters = Bound(NorthNearStepMeters, 5, 3, 8);
        NorthNearMaxAttempts = Math.Clamp(NorthNearMaxAttempts, 1, 12);
        NorthNearMaxDistance = Bound(NorthNearMaxDistance, 30, 3, 96);
        if (!Enum.IsDefined(RunMode)) RunMode = RunMode.Pot;
        if (RunMode == RunMode.Mixed) { RunMode = RunMode.Pot; PotIdleCarrots = true; }
        BronzeTreasureThreshold = Math.Clamp(BronzeTreasureThreshold, 0, 9999);
        CarrotSafetyRadius = Bound(CarrotSafetyRadius, 60, 10, 100);
        CarrotConfirmSeconds = Bound(CarrotConfirmSeconds, 1.5f, 0.5f, 10);
        CarrotStopBeforePotSeconds = Bound(CarrotStopBeforePotSeconds, 30, 10, 180);
        CarrotStartBeforePotSeconds = Math.Max(CarrotStopBeforePotSeconds + 10, Bound(CarrotStartBeforePotSeconds, 90, 30, 600));
    }

	public bool AutoAcceptPartyAtFate = true;

	public bool PreferTp = true;

	public bool UseDiveTp = true;

	public float TpIntervalSeconds = 5f;
    public float NorthNearStepMeters = 5f;
    public int NorthNearMaxAttempts = 6;
    public float NorthNearMaxDistance = 30f;

	public uint AutoBaseClassJobID;

	public int AutoPhantomJobID = -1;

	public bool SectionRouteExpanded = true;

	public bool SectionDutyExpanded = true;

	public bool SectionRequirementsExpanded;

	public bool SimplifiedUI;

	public float WindowWidth = 560f;

	public float WindowHeight = 460f;

	public float SimplifiedWindowWidth = 360f;

	public float SimplifiedWindowHeight;

	public DataCenterRouteConfig Chocobo = new DataCenterRouteConfig
	{
		Enabled = true
	};

	public DataCenterRouteConfig Moogle = new DataCenterRouteConfig
	{
		Enabled = true
	};

	public DataCenterRouteConfig Cat = new DataCenterRouteConfig
	{
		Enabled = true
	};

	public DataCenterRouteConfig Atomos = new DataCenterRouteConfig
	{
		Enabled = true
	};

	public int Version { get; set; } = 19;

	public DataCenterRouteConfig GetRoute(CnDataCenterKind kind)
	{
		return kind switch
		{
			CnDataCenterKind.Chocobo => Chocobo, 
			CnDataCenterKind.Moogle => Moogle, 
			CnDataCenterKind.Cat => Cat, 
			CnDataCenterKind.Atomos => Atomos, 
			_ => Chocobo, 
		};
	}

	public void SetRoute(CnDataCenterKind kind, DataCenterRouteConfig value)
	{
		switch (kind)
		{
		case CnDataCenterKind.Chocobo:
			Chocobo = value;
			break;
		case CnDataCenterKind.Moogle:
			Moogle = value;
			break;
		case CnDataCenterKind.Cat:
			Cat = value;
			break;
		case CnDataCenterKind.Atomos:
			Atomos = value;
			break;
		}
	}

	public void SyncHomeWorldLock()
	{
		uint homeWorldID = CnWorldCatalog.HomeWorldID;
		CnDataCenterKind? homeDCKind = CnWorldCatalog.HomeDCKind;
		if (homeDCKind.HasValue && homeWorldID != 0)
		{
			GetRoute(homeDCKind.Value).DestinationWorldID = homeWorldID;
		}
	}
}
