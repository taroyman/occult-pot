using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace OccultPot;

// Read fields without resolving assembly-qualified $type metadata from OccultPot.
// A corrupt existing file stops loading rather than silently replacing user settings.
internal static class ConfigurationLoader
{
    internal static PluginConfiguration Load(string currentPath, Action<string> log, out bool migrated)
    {
        migrated = false;
        var legacyPath = Path.Combine(Path.GetDirectoryName(currentPath)!, "OccultPot.json");
        var source = File.Exists(currentPath) ? currentPath : File.Exists(legacyPath) ? legacyPath : null;
        if (source == null) return new PluginConfiguration();
        var json = JObject.Parse(File.ReadAllText(source));
        var config = json.ToObject<PluginConfiguration>(JsonSerializer.Create(new JsonSerializerSettings
        {
            TypeNameHandling = TypeNameHandling.None,
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
        })) ?? throw new InvalidDataException("配置为空，拒绝覆盖：" + source);
        if (!string.Equals(source, currentPath, StringComparison.OrdinalIgnoreCase))
        {
            var backup = legacyPath + ".pre-OccltSavior-2.1.3.2.bak";
            if (!File.Exists(backup)) File.Copy(legacyPath, backup, overwrite: false);
            migrated = true;
            log($"[OccltSavior.Config] migrated from {source}; backup={backup}; legacy file preserved");
        }
        return config;
    }
}
