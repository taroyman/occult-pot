using OccultPot.Core.Data;

namespace OccultPot.Core.DrTreasure;

internal static class TreasurePreparationPoints
{
    internal static string? For(ushort territory, bool outer) => (territory, outer) switch
    {
        (ZoneIds.SouthHorn, true) => "放浪神圣域遗迹",
        (ZoneIds.SouthHorn, false) => "石塔水沼",
        (ZoneIds.NorthHorn, true) => "沉没圣堂前",
        (ZoneIds.NorthHorn, false) => "妖火渔村",
        _ => null,
    };
}
