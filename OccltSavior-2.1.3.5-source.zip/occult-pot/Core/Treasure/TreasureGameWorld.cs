using FFXIVClientStructs.FFXIV.Client.Game;
using OccultPot.Core.Data;
using OccultPot.Core.Game;
using OccultPot.Core.Adapters;
using OccultPot.Core.Nav;
using OmenTools;
using OmenTools.Dalamud;
using OmenTools.Info.Game;
using OmenTools.Interop.Game.Lumina;
using OmenTools.OmenService;

namespace OccultPot.Core.DrTreasure;

internal sealed class TreasureGameWorld : ITreasureAutomationWorld
{
    public bool Available => DService.Instance().Command.Commands.ContainsKey("/pdr");
    public TreasureWorldSnapshot Read()
    {
        var territory = (ushort)GameState.TerritoryType;
        var ready = ZoneIds.IsSupportedIsland(territory) && PlayerReader.IsAvailable()
            && !PlayerReader.IsTransitionLocked() && !PlayerReader.IsBusy() && !PlayerReader.IsInCombat();
        var job = ready ? CrescentSupportJob.GetCurrentSupportJob() : null;
        return new(territory, ready, job is null ? null : (int)job.DataID,
            (int)CrescentSupportJob.Freelancer.DataID,
            ready && PlayerReader.Position.HasValue && IslandPotLayout.TryCamp(territory, out var camp, out _)
                ? PlayerReader.DistanceTo(camp) : null);
    }
    public bool SwitchJob(int job)
    {
        if (!PlayerReader.CanSwitchJob()) return false;
        var target = CrescentSupportJob.AllJobs.FirstOrDefault(j => j.DataID == job);
        if (target is null) return false;
        target.ChangeTo(); return true;
    }
    public unsafe bool UseSearch()
    {
        // Resolve the CN action from the installed game's data, never guess an action ID.
        var action = LuminaGetter.Get<Lumina.Excel.Sheets.Action>().FirstOrDefault(a => a.Name.ToString() == "魔寻宝");
        var manager = ActionManager.Instance();
        return action.RowId != 0 && manager != null
            && manager->UseAction(ActionType.Action, action.RowId, LocalPlayerState.EntityID);
    }
    // ProcessCommand reports unknown commands, unlike sending chat text optimistically.
    public bool Command(string command) => Available && DService.Instance().Command.ProcessCommand(command);
    public TreasurePreparationResult PrepareStart(string point)
    {
        if (!Read().Ready) return TreasurePreparationResult.Pending;
        if (PlayerReader.IsOnMount())
        {
            MountActions.TryDismount();
            return TreasurePreparationResult.Pending;
        }
        // Reuse the same PTP command and destination data as IslandTravel.
        return Command("/pdr ptp " + point) ? TreasurePreparationResult.Sent : TreasurePreparationResult.Failed;
    }
    public bool AtPreparationPoint(ushort territory, string point)
    {
        var shard = IslandAethernet.ForTerritory(territory).FirstOrDefault(s => s.Name == point && !s.IsCamp);
        return GameState.TerritoryType == territory && PlayerReader.Position.HasValue && shard is not null
            && PlayerReader.DistanceTo(shard.Landing) <= 50f;
    }
    public void Log(string text) => DLog.Debug("[OccltSavior.Treasure] " + text);
}
