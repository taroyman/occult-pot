using System.Text;
using System.Text.RegularExpressions;

namespace OccultPot.Core.DrTreasure;

internal static class TreasureCountParser
{
    internal static bool TryParse(string text, out int silver, out int bronze)
    {
        silver = bronze = 0;
        var normalized = Regex.Replace(text.Normalize(NormalizationForm.FormKC), @"\s+", "");
        if (!normalized.Contains("当前区域") || !normalized.Contains("银宝箱") || !normalized.Contains("铜宝箱")) return false;
        return Count(normalized, "银宝箱", out silver) && Count(normalized, "铜宝箱", out bronze);
    }

    private static bool Count(string text, string keyword, out int value)
    {
        var match = Regex.Match(text, keyword + @"[：:×x]+([0-9]+)");
        if (!match.Success) match = Regex.Match(text, @"([0-9]+)(?:个|只|座)?" + keyword);
        if (!match.Success) match = Regex.Match(text, keyword + @"[：:×x]*([0-9]+)");
        return int.TryParse(match.Groups[1].Value, out value) && value >= 0;
    }
}
