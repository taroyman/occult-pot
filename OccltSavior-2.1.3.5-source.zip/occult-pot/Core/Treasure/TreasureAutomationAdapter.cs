namespace OccultPot.Core.DrTreasure;

internal enum TreasureAutomationState { Idle, SwitchJob, CastSearch, WaitChat, PrepareOuterStart, Outer, PrepareInnerStart, Inner, RestoreJob, Completed }
internal enum TreasurePreparationResult { Pending, Sent, Failed }
internal readonly record struct TreasureWorldSnapshot(ushort Territory, bool Ready, int? Job, int Freelancer, float? CampDistance);
internal interface ITreasureAutomationWorld
{
    TreasureWorldSnapshot Read();
    bool Available { get; }
    bool SwitchJob(int job);
    bool UseSearch();
    bool Command(string command);
    TreasurePreparationResult PrepareStart(string point);
    bool AtPreparationPoint(ushort territory, string point);
    void Log(string text);
}

// All DR protocol and timeout handling stays here, outside the route planner.
internal sealed class TreasureAutomationAdapter(ITreasureAutomationWorld world, Action<string, string> record)
{
    internal TreasureAutomationState State { get; private set; }
    internal bool Active => State is not (TreasureAutomationState.Idle or TreasureAutomationState.Completed);
    internal bool HasLeftCamp { get; private set; }
    internal int? PendingRestoreJob { get; private set; }
    internal string Status { get; private set; } = "DR 未启动";
    internal const double ChatTimeout = 8, StartTimeout = 45, RouteTimeout = 900, RestoreTimeout = 20, PreparationTimeout = 20;
    private int preparationAttempt;
    private bool preparationSent;
    private double preparedSince = -1;
    private string preparationPoint = "";
    private double since, nextAction, returnedSince = -1;
    private ushort territory;
    private int threshold;
    private bool routeOwned;
    private (int Silver, int Bronze)? counts;

    internal void Begin(double now, int bronzeThreshold)
    {
        if (Active) return;
        threshold = Math.Clamp(bronzeThreshold, 0, 9999);
        counts = null; HasLeftCamp = false; returnedSince = -1;
        try
        {
            var s = world.Read(); territory = s.Territory;
            if (PendingRestoreJob.HasValue) { Fail(now, "上次辅助职业仍待恢复，跳过 DR"); return; }
            if (!world.Available) { Complete("Daily Routines /pdr 不可用，继续挖罐"); return; }
            if (!s.Ready || !s.Job.HasValue || !s.CampDistance.HasValue) { Complete("辅助职业/据点数据不可用，继续挖罐"); return; }
            PendingRestoreJob = s.Job;
            record("Pause", "DR 前置寻宝接管控制");
            Set(TreasureAutomationState.SwitchJob, now, "切换自由人");
        }
        catch (Exception ex) { Fail(now, "DR 初始化异常：" + ex.Message); }
    }

    internal void OnChat(string text)
    {
        if (State == TreasureAutomationState.WaitChat && counts is null && TreasureCountParser.TryParse(text, out var silver, out var bronze))
            counts = (silver, bronze);
    }

    internal void Tick(double now)
    {
        if (!Active) { RetryRestore(now); return; }
        try
        {
            if (State == TreasureAutomationState.RestoreJob)
            {
                RetryRestore(now);
                if (!PendingRestoreJob.HasValue) Complete("辅助职业已恢复，继续自动挖罐");
                else if (now - since >= RestoreTimeout) Complete("辅助职业暂不可切换，后台重试恢复；继续自动挖罐");
                return;
            }
            var s = world.Read();
            if (s.Territory != territory) { Fail(now, "区域改变，取消 DR"); return; }
            if (!world.Available) { Fail(now, "Daily Routines 运行中不可用"); return; }
            switch (State)
            {
                case TreasureAutomationState.SwitchJob:
                    if (s.Job == s.Freelancer) Set(TreasureAutomationState.CastSearch, now, "使用魔寻宝");
                    else if (now - since >= 15) Fail(now, "切换自由人超时");
                    else if (s.Ready && now >= nextAction) { nextAction = now + 2; world.SwitchJob(s.Freelancer); }
                    break;
                case TreasureAutomationState.CastSearch:
                    // Set the listener before dispatch: a synchronous reply cannot be lost.
                    if (s.Ready && now >= nextAction)
                    {
                        Set(TreasureAutomationState.WaitChat, now, "等待魔寻宝聊天结果");
                        if (!world.UseSearch()) Fail(now, "魔寻宝不可用/调用失败");
                    }
                    else if (now - since >= 10) Fail(now, "魔寻宝施放条件超时");
                    break;
                case TreasureAutomationState.WaitChat:
                    if (counts is { } c)
                    {
                        world.Log($"silverCount={c.Silver}; bronzeCount={c.Bronze}; BronzeTreasureThreshold={threshold}");
                        if (c.Bronze < threshold) Restore(now, $"铜宝箱 {c.Bronze} < {threshold}，跳过寻宝");
                        else PrepareRoute(now, outer: true);
                    }
                    else if (now - since >= ChatTimeout) Fail(now, "魔寻宝聊天结果超时（8秒）");
                    break;
                case TreasureAutomationState.PrepareOuterStart:
                case TreasureAutomationState.PrepareInnerStart:
                    TickPreparation(now, s);
                    break;
                case TreasureAutomationState.Outer:
                case TreasureAutomationState.Inner:
                    if (now - since >= RouteTimeout) { Fail(now, $"{State} 路线超时（900秒）"); break; }
                    if (!HasLeftCamp && now - since >= StartTimeout) { Fail(now, $"{State} 启动失败：45秒未离开据点"); break; }
                    // Hysteresis and a stable return prevent boundary jitter / loading false positives.
                    if (!s.Ready || !s.CampDistance.HasValue) { returnedSince = -1; break; }
                    if (s.CampDistance > 90) { HasLeftCamp = true; returnedSince = -1; }
                    if (!HasLeftCamp || s.CampDistance > 80) { returnedSince = -1; break; }
                    if (returnedSince < 0) returnedSince = now;
                    if (now - returnedSince < 2) break;
                    world.Log($"{State}; HasLeftCamp=true; ReturnToCamp=true");
                    if (State == TreasureAutomationState.Outer) PrepareRoute(now, outer: false);
                    else Restore(now, "外环、内环均已返回据点");
                    break;
            }
        }
        catch (Exception ex) { Fail(now, "DR 异常：" + ex.Message); }
    }

    private void PrepareRoute(double now, bool outer)
    {
        // Returning to camp completes the route; release DR before dispatching PTP.
        AbortRoute();
        preparationPoint = TreasurePreparationPoints.For(territory, outer) ?? "";
        if (preparationPoint.Length == 0) { Fail(now, "当前岛区没有寻宝预备点"); return; }
        preparationAttempt = 1; preparationSent = false; preparedSince = -1;
        HasLeftCamp = false; returnedSince = -1;
        Set(outer ? TreasureAutomationState.PrepareOuterStart : TreasureAutomationState.PrepareInnerStart,
            now, $"传送至{preparationPoint}，确认远离据点（第1次）");
    }

    private void TickPreparation(double now, TreasureWorldSnapshot s)
    {
        // A successful dispatch alone is not arrival. Require both destination and camp distance,
        // stable for two seconds after loading. Never infer success from a travel timeout.
        if (s.Ready && s.CampDistance > 90 && world.AtPreparationPoint(territory, preparationPoint))
        {
            preparedSince = preparedSince < 0 ? now : preparedSince;
            if (now - preparedSince >= 2) StartRoute(now, State == TreasureAutomationState.PrepareOuterStart);
            return;
        }
        preparedSince = -1;
        if (now - since >= PreparationTimeout) { RetryPreparation(now, "传送超时或仍在据点安全范围"); return; }
        if (preparationSent || !s.Ready || now < nextAction) return;
        nextAction = now + 2;
        TreasurePreparationResult result;
        try { result = world.PrepareStart(preparationPoint); }
        catch (Exception ex) { RetryPreparation(now, "传送调用异常：" + ex.Message); return; }
        if (result == TreasurePreparationResult.Failed) RetryPreparation(now, "传送命令不可调用");
        else preparationSent = result == TreasurePreparationResult.Sent;
    }

    private void RetryPreparation(double now, string reason)
    {
        if (preparationAttempt >= 2) { Fail(now, $"{preparationPoint} 两次预备失败：{reason}"); return; }
        preparationAttempt++; preparationSent = false; preparedSince = -1;
        Set(State, now, $"{reason}；重试传送至{preparationPoint}（第2次）");
        nextAction = now + 2;
    }

    private void StartRoute(double now, bool outer)
    {
        HasLeftCamp = false; returnedSince = -1;
        Set(outer ? TreasureAutomationState.Outer : TreasureAutomationState.Inner, now, outer ? "DR 外环运行中" : "DR 内环运行中");
        routeOwned = true; // Even a throwing command may have partially started the route.
        if (!world.Command(outer ? "/pdr ptreasure 外环" : "/pdr ptreasure 内环")) Fail(now, "DR 路线命令不可调用");
    }

    internal void Cancel(double now, string reason)
    {
        if (!Active && !PendingRestoreJob.HasValue) return;
        AbortRoute();
        record("Abort", reason);
        State = TreasureAutomationState.Completed; Status = reason;
        nextAction = now;
        RetryRestore(now);
    }

    private void Fail(double now, string reason)
    {
        AbortRoute(); record("Abort", reason); Restore(now, reason);
    }
    private void AbortRoute()
    {
        if (!routeOwned) return;
        routeOwned = false;
        try { if (!world.Command("/pdr ptreasure abort")) world.Log("DR abort dispatch=false"); }
        catch (Exception ex) { world.Log("DR abort exception=" + ex.Message); }
    }
    private void Restore(double now, string reason)
    {
        // Release DR's route state before Occlt Savior resumes movement, including normal completion.
        AbortRoute();
        Set(TreasureAutomationState.RestoreJob, now, reason + "；恢复原辅助职业");
    }
    private void RetryRestore(double now)
    {
        if (!PendingRestoreJob.HasValue || now < nextAction) return;
        nextAction = now + 2;
        try
        {
            var s = world.Read();
            if (s.Job == PendingRestoreJob) { PendingRestoreJob = null; return; }
            if (s.Ready) world.SwitchJob(PendingRestoreJob.Value);
        }
        catch (Exception ex) { world.Log("辅助职业恢复待重试：" + ex.Message); }
    }
    private void Set(TreasureAutomationState state, double now, string text)
    {
        State = state; since = nextAction = now; Status = text; world.Log($"state={state}; {text}");
    }
    private void Complete(string text)
    {
        State = TreasureAutomationState.Completed; Status = text;
        record("Resume", text); world.Log(text);
    }
}
