using System.Numerics;
using OccultPot.Core.Data;
namespace OccultPot.Core.Carrot;
// Candidate coordinates from Eureka Linker (MIT); see THIRD-PARTY-NOTICES.md.
internal static class CarrotData
{
    internal const uint ItemId = 48096;
    internal const uint TraceId = 2010139;
    private static readonly Vector3[] South =
    [
        new(283.6546f, 55.999996f, 587.3107f),
        new(-439.0463f, 115.82392f, 184.4665f),
        new(477.4074f, 96.10128f, 138.6543f),
        new(-743.601f, 96.39003f, 84.43998f),
        new(-575.6361f, 162.39511f, 668.7043f),
        new(865.0009f, 95.99958f, -214.6744f),
        new(248.9159f, 55.999996f, 791.1138f),
        new(-490.3187f, 3f, -741.0153f),
        new(720.4133f, 120f, 271.05f),
        new(466.2025f, 70.3f, 563.2519f),
        new(-701.8768f, 201f, 718.7181f),
        new(-273.0878f, 75f, 850.0336f),
        new(650.2321f, 108f, 141.1927f),
        new(827.2007f, 108f, -156.4444f),
        new(845.5334f, 98f, 777.4331f),
        new(772.3591f, 70.3f, 531.1259f),
        new(-84.73673f, 2.999999f, -796.0166f),
        new(-843.8602f, 83.657074f, -36.78173f),
        new(-727.8528f, 81.47683f, 328.9311f),
        new(-400.528f, 2.999999f, -518.3032f),
        new(-806.5123f, 107f, 887.6146f),
        new(-174.0473f, 121.00001f, 107.6488f),
        new(-771.6308f, 5f, -694.0016f),
        new(-710.266f, 3f, -451.5128f),
        new(-554.0244f, 110.698654f, -365.897f),
    ];
    private static readonly Vector3[] North =
    [
        new(-857.4f, 71.45287f, 379.6f),
        new(7.60699f, 4.3169565f, -35.67316f),
        new(287.2872f, 142.99992f, -366.9024f),
        new(-608.8f, 59.286507f, 373.9f),
        new(-254f, 54.388798f, -739f),
        new(-560.9f, 50.74249f, -447f),
        new(-500f, 48.000004f, -867.6f),
        new(226f, 90.400055f, 904f),
        new(-258.7481f, 3.588304f, 53.59217f),
        new(-604f, 160.05638f, 939.1f),
        new(756.858f, 68.92707f, -79.33746f),
        new(-814.6948f, 5.6813054f, -561.0853f),
        new(-129.7795f, 8.029996f, -171.18f),
        new(-847.9f, 114f, 196.6f),
        new(-808f, 6.3495464f, -879f),
        new(960f, 97.05797f, -879f),
        new(625.8f, 61.06923f, -846.3f),
        new(-956.1f, 157.8f, 720.2f),
        new(-581f, 160f, 791f),
        new(108f, 22.332209f, -556f),
        new(-35f, 72.89336f, -860f),
        new(882.1526f, 53.999996f, 115.9092f),
        new(923f, 80.26997f, -277f),
        new(853.9f, 70.20017f, -343.3f),
        new(-124f, 76.75548f, 777f),
    ];
    internal static IReadOnlyList<Vector3> GetAll(ushort territory) => territory switch
    { ZoneIds.SouthHorn => South, ZoneIds.NorthHorn => North, _ => [] };
}
