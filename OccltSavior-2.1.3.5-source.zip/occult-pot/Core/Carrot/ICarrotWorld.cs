using System.Numerics;

namespace OccultPot.Core.Carrot;

internal readonly record struct CarrotTarget(Vector3 Position, uint EntityId = 0);

internal interface ICarrotWorld
{
    ushort Territory { get; }
    uint World { get; }
    bool Ready { get; }
    bool Busy { get; }
    bool Combat { get; }
    bool Mounted { get; }
    int CarrotCount { get; }
    Vector3 Position { get; }
    IReadOnlyList<CarrotTarget> Scan();
    IReadOnlyList<Vector3> Points { get; }
    bool TraceExists(CarrotTarget target);
    int CountPlayers(Vector3 target, float radius);
    bool Navigate(Vector3 target);
    void StopMovement();
    bool DiveTp(Vector3 target, double now, float interval);
    void Dismount();
    void SnapshotChests(Vector3 target);
    void ObserveChestSafety();
    Vector3? ChestPosition { get; }
    bool UseCarrot();
    bool HasChest { get; }
    bool ChestGone { get; }
    bool OpenChest();
    bool ConfirmChest();
    void ClearChest();
    void Log(string message);
}
