using System.Numerics;
using OccultPot.Core.Safety;

namespace OccultPot.Core.Carrot;

// Framework-thread state machine. No background command queue: cancellation takes effect on this tick.
internal sealed class CarrotRunner(ICarrotWorld world, Action onOpened, Action<string, string>? onActivity = null)
{
    internal enum Step { Idle, Approach, Safety, Teleport, Scan, Use, CarrotChestWait, CarrotChestDetect, Open }
    private readonly TwoPassSafetyGate gate = new();
    private readonly Dictionary<Vector3, double> skipped = new();
    private CarrotTarget target;
    private Step step;
    private ushort territory;
    private uint worldId;
    private double started, phaseAt, nextAction, nextScan, goneAt = -1;
    private bool sentUse;
    private int countBeforeUse;
    private bool pauseRecorded;
    internal bool IsActive => step != Step.Idle;
    internal Step Phase => step;
    internal string Status { get; private set; } = "胡萝卜待机";
    internal string TargetLabel => IsActive ? $"胡萝卜 ({target.Position.X:0.0}, {target.Position.Y:0.0}, {target.Position.Z:0.0})" : "扫描胡萝卜候选点";

    internal bool TryStart(double now, PluginConfiguration config)
    {
        if (IsActive) return true;
        if (territory != world.Territory || worldId != world.World)
        { skipped.Clear(); nextScan = 0; territory = world.Territory; worldId = world.World; }
        if (!config.AutoCarrotEnabled || !config.CarrotPlayerSafetyEnabled)
        {
            Status = "胡萝卜已暂停（自动功能及玩家检测均需开启）";
            if (!pauseRecorded) { pauseRecorded = true; onActivity?.Invoke("Pause", Status); }
            return false;
        }
        if (pauseRecorded) { pauseRecorded = false; onActivity?.Invoke("Resume", "胡萝卜设置恢复，重新扫描"); }
        if (!world.Ready || world.Busy || world.Combat) { Status = "等待角色可操作/进入新月岛"; return false; }
        if (world.CarrotCount <= 0) { Status = "背包没有好运胡萝卜"; return false; }
        if (now < nextScan) return false;
        foreach (var key in skipped.Where(x => x.Value <= now).Select(x => x.Key).ToArray()) skipped.Remove(key);
        bool Available(Vector3 p) => !skipped.Keys.Any(k => Vector3.DistanceSquared(k, p) < 64);
        var live = world.Scan().Where(t => Available(t.Position)).OrderBy(t => Vector3.DistanceSquared(t.Position, world.Position)).ToArray();
        var points = world.Points.Where(Available).OrderBy(p => Vector3.DistanceSquared(p, world.Position)).ToArray();
        if (live.Length == 0 && points.Length == 0)
        { Status = "本轮候选点已跳过，返回 Pot/稍后扫描"; nextScan = now + 10; return false; }
        target = live.Length != 0 ? live[0] : new CarrotTarget(points[0]);
        started = phaseAt = now; nextAction = now; goneAt = -1; sentUse = false; gate.Reset();
        step = Step.Approach;
        Status = TargetLabel;
        world.Log($"target; territory={territory}; entity={target.EntityId}; position={target.Position}; source={(target.EntityId == 0 ? "table" : "live")}");
        return true;
    }

    internal void Tick(double now, PluginConfiguration config)
    {
        if (!IsActive) return;
        if (!config.AutoCarrotEnabled || !config.CarrotPlayerSafetyEnabled || !world.Ready ||
            territory != world.Territory || worldId != world.World || world.Combat)
        { Cancel("配置关闭、过图、角色不可用或进入战斗"); return; }
        if (now - started >= 120) { Skip(now, "目标总超时120秒"); return; }
        if (step is Step.CarrotChestWait or Step.CarrotChestDetect or Step.Open)
        {
            world.ObserveChestSafety();
            if (step != Step.Open && now - phaseAt >= 25)
            { Skip(now, "CarrotChestWait/Detect超时25秒；不重复用物"); return; }
            if (step == Step.Open && now - phaseAt >= 20)
            { Skip(now, "宝箱交互超时20秒"); return; }
        }
        if (world.Busy)
        {
            gate.Reset();
            if (step == Step.Use) { step = Step.Safety; phaseAt = now; }
            return;
        }
        var distance = Vector3.Distance(world.Position, target.Position);
        switch (step)
        {
            case Step.Approach:
                // Remote ObjectTable absence is never evidence that a candidate is empty.
                if (now >= nextAction)
                {
                    nextAction = now + 0.5;
                    world.StopMovement();
                    if (world.DiveTp(target.Position, now, config.TpIntervalSeconds))
                    {
                        world.Log($"DiveTP-probe; target={target.Position}");
                        step = Step.Teleport; phaseAt = now;
                        Status = "DiveTP探测候选点，确认到达";
                    }
                }
                break;
            case Step.Teleport:
                if (distance <= 3)
                {
                    world.StopMovement();
                    step = Step.Scan; phaseAt = now;
                    ScanArrived(now, config);
                    return;
                }
                if (now - phaseAt >= 15) Skip(now, "DiveTP未到达（15秒），不重复发送");
                break;
            case Step.Scan:
                ScanArrived(now, config);
                break;
            case Step.Safety:
                if (distance > 3 || !world.TraceExists(target)) { Skip(now, "落地二次确认前痕迹消失或离开目标"); return; }
                CheckSafety(now, config);
                break;
            case Step.Use:
                if (now - phaseAt >= 15) { Skip(now, "到达后道具不可用"); return; }
                if (distance > 3 || !world.TraceExists(target)) { Skip(now, "到达后痕迹消失或位置改变"); return; }
                // Recheck through dismount/item delays; a late arrival must still prevent use.
                if (world.CountPlayers(target.Position, config.CarrotSafetyRadius) != 0)
                { Skip(now, "用物前附近出现玩家或无法检测"); return; }
                if (world.Mounted) { world.Dismount(); return; }
                if (world.CarrotCount <= 0) { Skip(now, "好运胡萝卜耗尽"); return; }
                if (now < nextAction) return;
                world.SnapshotChests(target.Position);
                countBeforeUse = world.CarrotCount;
                nextAction = now + 1;
                if (world.UseCarrot())
                {
                    sentUse = true; step = Step.CarrotChestWait; phaseAt = now;
                    Status = "已请求使用好运胡萝卜，等待宝箱";
                    world.Log($"use-carrot; item=48096; target={target.Position}; request-sent=true");
                }
                break;
            case Step.CarrotChestWait:
                if (distance > 8) { Skip(now, "使用后离开目标区域"); return; }
                world.ObserveChestSafety();
                if (world.CarrotCount < countBeforeUse)
                {
                    world.Log($"carrot-use-confirmed; inventory={countBeforeUse}->{world.CarrotCount}; traceExists={world.TraceExists(target)}");
                    step = Step.CarrotChestDetect;
                    Status = "好运胡萝卜已消耗，检测本次黄金财宝箱";
                    goto case Step.CarrotChestDetect;
                }
                if (now - phaseAt >= 25) Skip(now, "胡萝卜消耗未确认（25秒），不交互、不重复用物");
                break;
            case Step.CarrotChestDetect:
                if (distance > 8) { Skip(now, "使用后离开目标区域"); return; }
                world.ObserveChestSafety();
                if (world.HasChest) { step = Step.Open; phaseAt = now; nextAction = now; return; }
                if (now - phaseAt >= 25) Skip(now, "宝箱未生成/道具请求未生效（25秒），不重复消耗");
                break;
            case Step.Open:
                if (distance > 8) { Skip(now, "开箱时离开目标区域"); return; }
                world.ObserveChestSafety();
                if (world.ChestGone)
                {
                    if (goneAt < 0) { goneAt = now; world.Log("carrot-chest-gone; wait-settle=2s"); }
                    if (now - goneAt >= 2)
                    {
                        if (world.ConfirmChest()) { onOpened(); world.Log("chest-result=confirmed; accepted-interaction+gone+settle"); }
                        else world.Log("chest-result=unconfirmed; no accepted interaction; not counted");
                        Skip(now, "本次宝箱处理结束");
                    }
                    return;
                }
                goneAt = -1;
                if (now - phaseAt >= 20) { Skip(now, "宝箱交互超时（20秒）"); return; }
                if (world.Mounted) { world.Dismount(); return; }
                if (world.ChestPosition is { } chest && Vector3.Distance(world.Position, chest) > 4.5f)
                {
                    if (now >= nextAction)
                    { nextAction = now + 1; world.Log($"carrot-chest-approach; target={chest}; accepted={world.Navigate(chest)}"); }
                    return;
                }
                world.StopMovement();
                if (now >= nextAction)
                { nextAction = now + 1; world.Log($"chest-interact; accepted={world.OpenChest()}"); }
                break;
        }
    }

    private void CheckSafety(double now, PluginConfiguration config)
    {
        var players = world.CountPlayers(target.Position, config.CarrotSafetyRadius);
        var decision = gate.Check(players, now, config.CarrotConfirmSeconds);
        // Log each observation, including the first and final confirmation.
        world.Log($"safety; target={target.Position}; players={players}; radius={config.CarrotSafetyRadius}; decision={decision}");
        if (decision == SafetyDecision.Skip) { Skip(now, "目标附近有玩家或无法检测；不等待"); return; }
        if (decision != SafetyDecision.Clear) { Status = "附近无人，等待第二次确认"; return; }
        step = Step.Use; phaseAt = now; nextAction = now;
        Status = "落地两次确认无人，准备使用好运胡萝卜";
    }

    private void ScanArrived(double now, PluginConfiguration config)
    {
        if (Vector3.Distance(world.Position, target.Position) > 3)
        { Skip(now, "探测时已离开候选点"); return; }
        var nearby = world.Scan().Where(t => Vector3.DistanceSquared(t.Position, target.Position) <= 9
            && Vector3.DistanceSquared(t.Position, world.Position) <= 9).ToArray();
        if (nearby.Length == 0)
        {
            // One bounded loading grace after landing; once it expires move to the next point.
            if (now - phaseAt >= 1.0) Skip(now, "落地扫描无胡萝卜痕迹，转下一候选点");
            return;
        }
        target = nearby.OrderBy(t => Vector3.DistanceSquared(t.Position, world.Position)).First();
        world.Log($"probe-found; entity={target.EntityId}; position={target.Position}");
        gate.Reset(); step = Step.Safety; phaseAt = now;
        CheckSafety(now, config);
    }

    private void Skip(double now, string reason)
    {
        skipped[target.Position] = now + (sentUse ? 120 : 60);
        Cancel("skip: " + reason);
    }

    internal void Cancel(string reason)
    {
        if (!IsActive) return;
        world.Log($"stop; reason={reason}; step={step}; target={target.Position}; used={sentUse}");
        onActivity?.Invoke("Abort", $"胡萝卜：{reason}；阶段={step}；目标={target.Position}");
        world.StopMovement(); world.ClearChest(); gate.Reset(); step = Step.Idle;
        Status = reason;
    }
}
