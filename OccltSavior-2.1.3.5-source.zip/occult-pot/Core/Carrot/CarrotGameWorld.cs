using System.Numerics;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using OccultPot.Core.Adapters;
using OccultPot.Core.Data;
using OccultPot.Core.Game;
using OccultPot.Core.Safety;
using OmenTools;
using OmenTools.Dalamud;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;
using OmenTools.OmenService;

namespace OccultPot.Core.Carrot;

internal sealed class CarrotGameWorld : ICarrotWorld
{
    private readonly TpNavigator tp = new();
    private readonly VNavController vnav = new();
    public ushort Territory => (ushort)DService.Instance().ClientState.TerritoryType;
    public uint World => CnWorldCatalog.CurrentWorldID;
    public bool Ready => ZoneIds.IsSupportedIsland(Territory) && PlayerReader.IsAvailable() && !PlayerReader.IsTransitionLocked();
    public bool Busy => PlayerReader.IsBusy();
    public bool Combat => PlayerReader.IsInCombat();
    public bool Mounted => PlayerReader.IsOnMount();
    public int CarrotCount => InventoryReader.GetElixirCount(CarrotData.ItemId);
    public Vector3 Position => PlayerReader.Position ?? Vector3.Zero;
    public IReadOnlyList<Vector3> Points => CarrotData.GetAll(Territory);
    public IReadOnlyList<CarrotTarget> Scan() => !Ready ? [] : DService.Instance().ObjectTable
        .Where(IsTrace).Select(o => new CarrotTarget(o.Position, o.EntityID)).ToArray();
    private static unsafe bool IsTrace(IGameObject obj) =>
        obj.IsValid() && (int)obj.ObjectKind == 7 && obj.Address != 0 &&
        ((GameObject*)obj.Address)->BaseId == CarrotData.TraceId;
    public bool TraceExists(CarrotTarget target) => DService.Instance().ObjectTable.Any(o =>
        o.EntityID == target.EntityId && IsTrace(o) && Vector3.DistanceSquared(o.Position, target.Position) < 9);
    public int CountPlayers(Vector3 target, float radius) => PlayerSafetyService.CountPlayers(target, radius);
    public bool Navigate(Vector3 target) => vnav.IsRunning() || vnav.PathfindTo(target);
    public void StopMovement() { tp.Stop(); vnav.Stop(); }
    public bool DiveTp(Vector3 target, double now, float interval) => tp.MoveTo(target, now, interval, useDiveTp: true);
    public void Dismount() => MountActions.TryDismount();
    public void SnapshotChests(Vector3 target) => TreasureChestInteractor.SnapshotCarrot(target);
    public void ObserveChestSafety() => TreasureChestInteractor.ObserveCarrotSafety();
    public Vector3? ChestPosition => TreasureChestInteractor.GetPotChestPosition();
    public bool UseCarrot() => !PlayerReader.IsMoving && InventoryReader.TryUseElixir(CarrotData.ItemId);
    public bool HasChest => TreasureChestInteractor.HasPotChest();
    public bool ChestGone => TreasureChestInteractor.TrackedChestGone();
    public bool OpenChest() => TreasureChestInteractor.TryOpenNearby();
    public bool ConfirmChest() => TreasureChestInteractor.TryTakeOpenedGrade(out _);
    public void ClearChest() => TreasureChestInteractor.ClearSnapshot();
    public void Log(string message) => DLog.Debug("[OccultSavior.Carrot] " + message);
}
