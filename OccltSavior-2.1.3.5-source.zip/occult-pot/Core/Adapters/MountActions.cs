using OccultPot.Core.Game;
using FFXIVClientStructs.FFXIV.Client.Game;
using OmenTools;
using OmenTools.Dalamud;
using OmenTools.Extensions;

namespace OccultPot.Core.Adapters;

internal static class MountActions
{
	private static DateTime nextDismountUTC;
	private static DateTime nextErrorLogUTC;
	internal static bool CanMount()
	{
		if (PlayerReader.IsOnMount() || !PlayerReader.IsAvailable() || PlayerReader.IsBusy())
		{
			return false;
		}
		return IConditionExtension.get_IsAbleToMount(DService.Instance().Condition);
	}

	internal static bool TryMount()
	{
		if (!CanMount())
		{
			return false;
		}
		ExternalCommands.Run("/共通技能 随机坐骑");
		return true;
	}

	internal static unsafe bool TryDismount()
	{
		if (!PlayerReader.IsOnMount() || !PlayerReader.IsAvailable() || PlayerReader.IsBusy())
			return false;
		var now = DateTime.UtcNow;
		if (now < nextDismountUTC)
			return false;
		nextDismountUTC = now.AddSeconds(1);
		try
		{
			// GeneralAction 23 = 跳下。Avoid the OmenTools ExecuteCommand path that throws on this installation.
			var manager = ActionManager.Instance();
			return manager != null && manager->UseAction(ActionType.GeneralAction, 23);
		}
		catch (Exception ex)
		{
			if (now >= nextErrorLogUTC)
			{
				nextErrorLogUTC = now.AddSeconds(30);
				DLog.Error("[OccultPot] 下坐骑动作暂不可用，稍后重试", ex);
			}
			return false;
		}
	}
}
