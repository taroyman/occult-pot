using FFXIVClientStructs.FFXIV.Component.GUI;
using OccultPot.Core.Data;
using OccultPot.Core.Game;
using OmenTools;
using OmenTools.Dalamud;
using OmenTools.Interop.Game.AddonEvent;
using OmenTools.OmenService;
using FFXIVClientStructs.FFXIV.Client.Game.Event;
using OccultPot.Core.Session;

namespace OccultPot.Core.Adapters;

internal static unsafe class IslandLeave
{
    private static long nextAttemptAt;
    private static long confirmationUntil;
    private static string lastAction = "not-issued";
    private static bool nativeIssued;

    internal static void Reset()
    {
        nextAttemptAt = 0;
        confirmationUntil = 0;
        lastAction = "not-issued";
        nativeIssued = false;
    }

    internal static void TickLeave() => TickLeave(ExitMethod.Callback);

    internal static string TickLeave(ExitMethod method)
    {
        if (!ZoneIds.IsSupportedIsland((ushort)GameState.TerritoryType)
            || !PlayerReader.IsAvailable() || PlayerReader.IsBetweenAreas() || PlayerReader.IsInCombat())
            return "player-unavailable/transition/combat/outside";

        var now = Environment.TickCount64;
        // 只确认本流程发起的退出任务提示，避免点击退队等其他确认框。
        if (confirmationUntil > now && AddonSelectYesnoEvent.ClickYes("退出任务"))
        {
            confirmationUntil = 0;
            nextAttemptAt = now + 3000;
            DLog.Debug("[OccultPot.Leave] 已确认退出任务；等待离岛状态");
            return lastAction = "exit-confirmed; awaiting-territory-change";
        }
        if (PlayerReader.IsBusy() || now < nextAttemptAt)
            return PlayerReader.IsBusy() ? "player-busy" : lastAction;

        nextAttemptAt = now + 1500;
        try
        {
            if (method == ExitMethod.NativeDutyExit)
            {
                if (nativeIssued) return lastAction;
                if (!EventFramework.CanLeaveCurrentContent()) return lastAction = "native-exit-not-permitted";
                EventFramework.LeaveCurrentContent(false);
                nativeIssued = true;
                confirmationUntil = now + 5000;
                return lastAction = "NativeDutyExit(requested,forced=false)";
            }
            // 保留原窗口操作顺序，但不把 SND 宏语法发送到游戏聊天框。
            if (TryCallback("ContentsFinderMenu", 0))
            {
                confirmationUntil = now + 5000;
                lastAction = "ContentsFinderMenu(0)";
            }
            else
                lastAction = TryCallback("_ToDoList", 23) ? "_ToDoList(23)" : "exit-ui-unavailable";
        }
        catch (Exception ex)
        {
            nextAttemptAt = now + 10000;
            DLog.Error("[OccultPot.Leave] 退岛窗口暂不可用，稍后重试", ex);
            throw; // Recovery controller applies a bounded retry, never Session.Fail.
        }
        return lastAction;
    }

    private static bool TryCallback(string addonName, int value)
    {
        var addon = (AtkUnitBase*)DService.Instance().GameGUI.GetAddonByName(addonName).Address;
        if (addon == null || !addon->IsVisible || !addon->IsReady)
            return false;
        var argument = new AtkValue { Type = AtkValueType.Int, Int = value };
        addon->FireCallback(1, &argument, true);
        DLog.Debug($"[OccultPot.Leave] 窗口回调 {addonName}({value})");
        return true;
    }
}
