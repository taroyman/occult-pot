using System.Numerics;
using OmenTools;
using OmenTools.OmenService;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;

namespace OccultPot.Core.Safety;

internal static class PlayerSafetyService
{
    // ObjectTable contains loaded actors only; this is not a server-wide visibility guarantee.
    internal static int CountPlayers(Vector3 target, float radius)
    {
        var self = LocalPlayerState.Object;
        if (self == null) return -1;
        return DService.Instance().ObjectTable.OfType<IPlayerCharacter>()
            .Count(p => p.IsValid() && p.EntityID != self.EntityID &&
                        Vector3.DistanceSquared(p.Position, target) <= radius * radius);
    }
}

internal sealed class TwoPassSafetyGate
{
    private double? firstClear;
    internal void Reset() => firstClear = null;
    internal SafetyDecision Check(int players, double now, double delay)
    {
        if (players != 0) { Reset(); return SafetyDecision.Skip; }
        if (!firstClear.HasValue) { firstClear = now; return SafetyDecision.Wait; }
        return now - firstClear.Value >= delay ? SafetyDecision.Clear : SafetyDecision.Wait;
    }
}

internal enum SafetyDecision { Wait, Clear, Skip }
