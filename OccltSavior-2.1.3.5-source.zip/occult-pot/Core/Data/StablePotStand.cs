using System.Numerics;

namespace OccultPot.Core.Data;

internal static class StablePotStand
{
    // Explicit FNV-1a; string.GetHashCode is salted between processes.
    internal static Vector3 Candidate(Vector3 center, string character, uint homeWorld, uint fate, int attempt)
    {
        ulong hash = 14695981039346656037UL;
        foreach (var c in $"{homeWorld}:{character}:{fate}:{attempt}")
            hash = unchecked((hash ^ c) * 1099511628211UL);
        var angle = (hash & 0xFFFFFFFFUL) / (double)uint.MaxValue * Math.PI * 2;
        var radius = 5 + (hash >> 32) / (double)uint.MaxValue * 10;
        return center + new Vector3((float)(Math.Cos(angle) * radius), 0, (float)(Math.Sin(angle) * radius));
    }

    internal static bool IsSafeProjection(Vector3 center, Vector3 requested, Vector3 projected)
    {
        if (!float.IsFinite(projected.X) || !float.IsFinite(projected.Y) || !float.IsFinite(projected.Z)) return false;
        var offset = new Vector2(projected.X - center.X, projected.Z - center.Z).Length();
        return offset >= 5 && offset <= 15 && Math.Abs(projected.Y - center.Y) <= 3
            && Vector3.DistanceSquared(requested, projected) <= 4;
    }

    internal static bool IsSafePath(Vector3 start, Vector3 end, IReadOnlyList<Vector3> path)
    {
        if (path.Count == 0 || Vector3.DistanceSquared(path[^1], end) > 1) return false;
        var previous = start;
        float length = 0;
        foreach (var point in path)
        {
            if (!float.IsFinite(point.X) || !float.IsFinite(point.Y) || !float.IsFinite(point.Z)
                || Math.Abs(point.Y - start.Y) > 4) return false;
            length += Vector3.Distance(previous, point);
            previous = point;
        }
        return length <= 60;
    }
}
