using System;
using System.Collections.Generic;
using System.Numerics;
using OccultPot.Core.Dig;
using OccultPot.Core.Safety;
using OccultPot.Models;
using Lumina.Excel.Sheets;
using OmenTools.Dalamud;
using OmenTools.Interop.Game.Lumina;
using OmenTools;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;
using OmenTools.Extensions;
using OmenTools.OmenService;

namespace OccultPot.Core.Game;

internal static class TreasureChestInteractor
{
	internal const float DetectRange = 12f;

	internal const float OpenRange = 5f;

	private const float TableMatchRange = 8f;

	private static readonly HashSet<uint> PreexistingEntityIDs = new HashSet<uint>();

	private static Vector3? carrotOrigin;
    private static bool carrotContested;
    private static readonly HashSet<string> CarrotDiagnostics = new();
    private static readonly HashSet<uint> CarrotExistingTargetable = new();

    internal static void ObserveCarrotSafety()
    {
        if (carrotOrigin is not { } origin) return;
        if (PlayerSafetyService.CountPlayers(origin, 12f) != 0)
        {
            carrotContested = true;
            LogCarrot("contested; another player nearby or scan unavailable; explicit self ownership required");
        }
    }

    private static void LogCarrot(string message)
    {
        if (CarrotDiagnostics.Add(message)) DLog.Debug("[OccltSavior.CarrotChest] " + message);
    }
	private static uint trackedEntityID;
    private static bool carrotTrackedSelfOwned;
	private static Vector3 trackedPosition;
	private static readonly ChestCountLatch CountLatch = new();

	internal static uint TrackedEntityID => trackedEntityID;

	internal static void SnapshotCarrot(Vector3 origin)
    {
        SnapshotExisting();
        carrotOrigin = origin;
        carrotContested = false;
        CarrotDiagnostics.Clear();
        CarrotExistingTargetable.Clear();
        foreach (var obj in DService.Instance().ObjectTable)
            if (obj.IsValid() && obj.IsTargetable && LooksLikeChest(obj)) CarrotExistingTargetable.Add(obj.EntityID);
        LogCarrot($"snapshot; origin={origin}; targetable={CarrotExistingTargetable.Count}; dormant objects may activate after use");
    }

    internal static void SnapshotExisting()
    {
        carrotOrigin = null;
		PreexistingEntityIDs.Clear();
		trackedEntityID = 0u;
		CountLatch.Reset();
		foreach (IGameObject item in DService.Instance().ObjectTable)
		{
			if (item != null && item.IsValid() && LooksLikeChest(item) && item.EntityID != 0)
			{
				PreexistingEntityIDs.Add(item.EntityID);
			}
		}
	}

	internal static void ClearSnapshot()
	{
        carrotOrigin = null;
		PreexistingEntityIDs.Clear();
		trackedEntityID = 0u;
		CountLatch.Reset();
	}

	internal static bool TryOpenNearby(float maxDistance = 5f)
	{
		if (PlayerReader.IsMoving)
		{
			return false;
		}
		IGameObject gameObject = FindPotChest(maxDistance);
		if (gameObject == null)
		{
			return false;
		}
		if (LocalPlayerState.DistanceToObject3D(gameObject) > 5f)
		{
			return false;
		}
		var accepted = gameObject.TargetInteract();
		CountLatch.Interacted(accepted);
		return accepted;
	}

	internal static bool HasPotChest(float maxDistance = 12f)
	{
		return FindPotChest(maxDistance) != null;
	}

	internal static Vector3? GetPotChestPosition(float maxDistance = 12f)
	{
		return FindPotChest(maxDistance)?.Position;
	}

	internal static bool TrackedChestGone()
	{
		if (trackedEntityID == 0)
		{
			return false;
		}
		IGameObject gameObject = DService.Instance().ObjectTable.SearchByEntityID(trackedEntityID);
		if (gameObject != null && gameObject.IsValid())
		{
			return !gameObject.IsTargetable;
		}
		return true;
	}

	private static IGameObject? FindPotChest(float maxDistance)
	{
		if (carrotOrigin != null) ObserveCarrotSafety();
        if (trackedEntityID != 0)
		{
			IGameObject gameObject = DService.Instance().ObjectTable.SearchByEntityID(trackedEntityID);
			if (gameObject != null && gameObject.IsValid() && gameObject.IsTargetable && LooksLikeChest(gameObject))
			{
				if (carrotOrigin != null && (!IsCarrotChest(gameObject) ||
                    LocalPlayerState.DistanceToObject3D(gameObject) > maxDistance)) return null;
                return gameObject;
			}
			return null;
		}
		IPlayerCharacter playerCharacter = LocalPlayerState.Object;
		if (playerCharacter == null)
		{
			return null;
		}
		IGameObject? gameObject2;
        if (carrotOrigin != null)
        {
            ObserveCarrotSafety();
            var matches = DService.Instance().ObjectTable.Where(obj => IsNewPotChest(obj) &&
                LocalPlayerState.DistanceToObject3D(obj) <= maxDistance).ToArray();
            var owned = matches.Where(IsSelfOwned).ToArray();
            if (owned.Length == 1) gameObject2 = owned[0];
            else if (owned.Length == 0 && matches.Length == 1) gameObject2 = matches[0];
            else
            {
                if (matches.Length > 1) LogCarrot($"ambiguous; eligible={matches.Length}; selfOwned={owned.Length}; refusing arbitrary nearest chest");
                return null;
            }
        }
        else gameObject2 = DService.Instance().ObjectTable.FindNearest(playerCharacter.Position, (IGameObject obj) => IsNewPotChest(obj) && LocalPlayerState.DistanceToObject3D(obj) <= maxDistance);
		if (gameObject2 != null && gameObject2.EntityID != 0)
		{
			trackedEntityID = gameObject2.EntityID;
            carrotTrackedSelfOwned = IsSelfOwned(gameObject2);
			ObserveGrade(gameObject2);
		}
		return gameObject2;
	}

	internal static bool TryTakeOpenedGrade(out ChestGrade grade) =>
		CountLatch.TryTake((carrotOrigin == null || !carrotContested || carrotTrackedSelfOwned) && TrackedChestGone() && PlayerReader.DistanceTo(trackedPosition) <= 8f, out grade);

	internal static void ForgetTrackedChest()
	{
		trackedEntityID = 0;
		CountLatch.Reset();
	}

	private static unsafe void ObserveGrade(IGameObject obj)
	{
		trackedPosition = obj.Position;
		uint baseId = 0, sgb = 0;
		var name = obj.Name.ToString();
		try
		{
			if (obj.Address != 0)
				baseId = ((FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)obj.Address)->BaseId;
			if ((int)obj.ObjectKind == 4 && LuminaGetter.TryGetRow<Treasure>(baseId, out var treasure))
				sgb = treasure.SGB.RowId;
			else if ((int)obj.ObjectKind == 7 && LuminaGetter.TryGetRow<EObj>(baseId, out var eventObject))
				sgb = eventObject.SgbPath.RowId;
		}
		catch (Exception ex)
		{
			DLog.Debug($"[OccultPot.Count] grade-unavailable; baseId={baseId}; error={ex.Message}");
		}
		var grade = ChestGradeClassifier.Classify(sgb, name);
		CountLatch.Observe(obj.EntityID, grade);
		DLog.Debug($"[OccultPot.Count] observed; entity={obj.EntityID}; baseId={baseId}; sgb={sgb}; name={obj.Name}; grade={grade}");
	}

	private static bool IsNewPotChest(IGameObject obj)
	{
		if (!obj.IsValid() || !obj.IsTargetable || !LooksLikeChest(obj))
		{
			return false;
		}
		uint entityID = obj.EntityID;
		if (entityID == 0)
		{
			return false;
		}
		// Carrot chests are a separate source; keep the original Pot table predicate unchanged.
        if (carrotOrigin is { } origin)
            return !CarrotExistingTargetable.Contains(entityID) && IsCarrotChest(obj);
        return !PreexistingEntityIDs.Contains(entityID) && IsOnPotChestTable(obj.Position);
	}

    private static unsafe bool IsSelfOwned(IGameObject obj) => obj.Address != 0 &&
        LocalPlayerState.Object is { } self && self.EntityID != 0 &&
        ((FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)obj.Address)->OwnerId == self.EntityID;

    private static unsafe bool IsCarrotChest(IGameObject obj)
    {
        if (carrotOrigin is not { } origin || obj.Address == 0 ||
            Vector3.DistanceSquared(obj.Position, origin) > 64) return false;
        var native = (FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)obj.Address;
        var baseId = native->BaseId;
        var owner = native->OwnerId;
        var self = LocalPlayerState.Object?.EntityID ?? 0;
        var hasOwner = owner != 0 && owner != 0xE0000000;
        // Known Pot coffers must not be mistaken for a carrot reward.
        uint sgb = 0;
        if ((int)obj.ObjectKind == 4 && LuminaGetter.TryGetRow<Treasure>(baseId, out var treasure)) sgb = treasure.SGB.RowId;
        else if ((int)obj.ObjectKind == 7 && LuminaGetter.TryGetRow<EObj>(baseId, out var eobj)) sgb = eobj.SgbPath.RowId;
        var gold = ChestGradeClassifier.Classify(sgb, obj.Name.ToString()) == ChestGrade.Gold;
        var eligible = (int)obj.ObjectKind is 4 or 7 && baseId is not (2014741 or 2014742 or 2014743)
            && (baseId == 2009530 || gold);
        var ownership = hasOwner ? self != 0 && owner == self : !carrotContested;
        LogCarrot($"candidate; entity={obj.EntityID}; baseId={baseId}; kind={obj.ObjectKind}; name={obj.Name}; sgb={sgb}; owner={owner:X}; self={self:X}; position={obj.Position}; eligible={eligible}; ownership={ownership}; contested={carrotContested}");
        return eligible && ownership;
    }

    private static bool IsOnPotChestTable(Vector3 position)
	{
		IReadOnlyList<Vector3> all = OccultPotChestTables.GetAll(DService.Instance().ClientState.TerritoryType);
		if (all.Count == 0)
		{
			return false;
		}
		float num = 64f;
		foreach (Vector3 item in all)
		{
			float num2 = item.X - position.X;
			float num3 = item.Z - position.Z;
			if (num2 * num2 + num3 * num3 <= num)
			{
				return true;
			}
		}
		return false;
	}

	private static bool LooksLikeChest(IGameObject obj)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		if ((int)obj.ObjectKind != 4)
		{
			if ((int)obj.ObjectKind == 7)
			{
				return LooksLikeTreasureName(obj.Name.ToString()) || IsKnownBunny(obj);
			}
			return false;
		}
		return true;
	}

    private static unsafe bool IsKnownBunny(IGameObject obj) => obj.Address != 0 &&
        ((FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)obj.Address)->BaseId == 2009530;

	private static bool LooksLikeTreasureName(string name)
	{
		if (!name.Contains("宝箱", StringComparison.Ordinal) && !name.Contains("Coffer", StringComparison.OrdinalIgnoreCase))
		{
			return name.Contains("Treasure", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}
}
