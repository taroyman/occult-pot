using Dalamud.Game.ClientState.Conditions;
using FFXIVClientStructs.FFXIV.Client.Game.Event;
using OccultPot.Core.Adapters;
using OccultPot.Core.Data;
using OccultPot.Core.Session;
using OmenTools;
using OmenTools.Dalamud;
using OmenTools.OmenService;

namespace OccultPot.Core.Game;

internal sealed class IslandExitWorld : IIslandExitWorld
{
    private static double nextTimerErrorLog;

    internal static unsafe ExitSnapshot Read(bool roundEnded, bool hasWork)
    {
        var territory = (ushort)GameState.TerritoryType;
        var island = ZoneIds.IsSupportedIsland(territory);
        var condition = DService.Instance().Condition;
        var inDuty = condition[ConditionFlag.BoundByDuty] || condition[ConditionFlag.BoundByDuty56]
            || condition[ConditionFlag.BoundByDuty95];
        var between = PlayerReader.IsBetweenAreas();
        double? remaining = null;
        if (island && !between && PlayerReader.IsAvailable())
        {
            try
            {
                var framework = EventFramework.Instance();
                var director = framework == null ? null : framework->GetPublicContentDirector();
                if (director != null && float.IsFinite(director->ContentTimeLeft) && director->ContentTimeLeft >= 0)
                    remaining = director->ContentTimeLeft;
            }
            catch (Exception ex)
            {
                var now = Environment.TickCount64 / 1000d;
                if (now >= nextTimerErrorLog)
                {
                    nextTimerErrorLog = now + 30;
                    DLog.Error("[OccltSavior.Exit] duty-timer unavailable; no guessed emergency countdown", ex);
                }
            }
        }
        return new(territory, island, inDuty, PlayerReader.IsAvailable(), PlayerReader.IsBusy(),
            between, PlayerReader.IsInCombat(), remaining, roundEnded, hasWork);
    }

    public void ResetAttempt() => IslandLeave.Reset();
    public string TickAttempt(ExitMethod method) => IslandLeave.TickLeave(method);
    public void Log(string message) => DLog.Debug(message);
}
