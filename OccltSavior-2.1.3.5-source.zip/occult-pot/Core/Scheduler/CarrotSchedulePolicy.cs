namespace OccultPot.Core.Scheduler;

internal static class CarrotSchedulePolicy
{
    internal static bool Allow(bool active, bool eligible, double? potSeconds, float start, float stop) =>
        eligible && potSeconds.HasValue && double.IsFinite(potSeconds.Value) &&
        potSeconds.Value > (active ? stop : start);
}
