namespace OccultPot.Core.Scheduler;

internal readonly record struct TravelEstimate(int Seconds, int SwitchPenalty)
{
    internal int Score(int spawnEta) => Math.Max(Math.Max(0, spawnEta), Seconds) + SwitchPenalty;
    // Replace this provider with measured medians later; the planner only consumes this value.
    internal static TravelEstimate Default(bool currentInstance, bool sameWorld, bool sameDC) =>
        currentInstance ? new(5, 0) : sameWorld ? new(45, 25) : sameDC ? new(90, 35) : new(180, 60);
}
