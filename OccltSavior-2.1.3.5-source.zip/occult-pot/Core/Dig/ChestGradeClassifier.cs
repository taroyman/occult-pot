using OccultPot.Models;

namespace OccultPot.Core.Dig;

internal static class ChestGradeClassifier
{
    // ExportedSG rows verified against the installed CN game data.
    // EObj 2014741/2/3 explicitly name the 11500/5479/5478 models gold/silver/bronze.
    internal static ChestGrade Classify(uint sgb, string name)
    {
        var model = sgb switch
        {
            1596 or 5478 => ChestGrade.Bronze,
            1597 or 5479 => ChestGrade.Silver,
            1598 or 11500 => ChestGrade.Gold,
            _ => ChestGrade.Unknown,
        };
        var label = name.Trim() switch
        {
            "黄金财宝箱" or "黄金宝箱" => ChestGrade.Gold,
            "白银财宝箱" or "白银宝箱" => ChestGrade.Silver,
            "青铜财宝箱" or "青铜宝箱" => ChestGrade.Bronze,
            _ => ChestGrade.Unknown,
        };
        // Conflicting evidence must not silently inflate a known-grade counter.
        if (model != ChestGrade.Unknown && label != ChestGrade.Unknown && model != label)
            return ChestGrade.Unknown;
        return model != ChestGrade.Unknown ? model : label;
    }
}
