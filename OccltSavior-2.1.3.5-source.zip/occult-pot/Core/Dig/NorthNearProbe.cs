using System.Numerics;
using OccultPot.Core.Adapters;
using OccultPot.Core.Data;
using OccultPot.Core.Game;

namespace OccultPot.Core.Dig;

internal sealed partial class OccultCrescentPotRunner
{
    private PotChatEvent nearHint;
    private int nearAttempts;
    private float nearDistance, nearStepLength;
    private Vector3 nearOrigin;
    private bool nearDisabled, nearMoved, nearUsed;
    private double nearStarted, nearUsedAt, nearNextAction;

    private void ResetNearProbe()
    {
        nearAttempts = 0; nearDistance = 0;
        nearDisabled = nearMoved = nearUsed = false;
    }

    private bool TryApplyNearHint(PotChatEvent evt)
    {
        if (hooks.TerritoryID != ZoneIds.NorthHorn || !hooks.PreferTp || !hooks.UseDiveTp) return false;
        // A response only belongs to the next probe after the preceding item request.
        if (status == OccultPotStatus.NearProbe && !nearUsed)
        {
            LogDig($"near-ignore-before-item; raw={evt.RawText}");
            return true;
        }
        if (evt.Distance != HintDistance.VeryNear || evt.Direction is not { } direction)
        {
            if (status == OccultPotStatus.NearProbe)
            {
                nearHint = evt;
                FallbackNear("subsequent-hint-not-explicit-very-close");
                return true;
            }
            return false;
        }
        if (nearDisabled) return false;
        nearHint = evt;
        var meters = float.IsFinite(hooks.NearStepMeters) ? Math.Clamp(hooks.NearStepMeters, 3f, 8f) : 5f;
        var maxDistance = float.IsFinite(hooks.NearMaxDistance) ? Math.Clamp(hooks.NearMaxDistance, 3f, 96f) : 30f;
        if (nearAttempts >= Math.Clamp(hooks.NearMaxAttempts, 1, 12) || nearDistance + meters > maxDistance + 0.001f)
        {
            FallbackNear("attempt-or-total-distance-limit");
            return true;
        }
        var vector = PotHintParser.DirectionVector(direction) * meters;
        var origin = hooks.PlayerPosition;
        nearOrigin = origin; nearStepLength = meters;
        target = origin + vector; // X/Z cardinal axes; preserve current elevation.
        nearMoved = nearUsed = false;
        nearStarted = nearNextAction = hooks.NowSeconds;
        hooks.StopMove();
        hintCount++; lastHint = FormatHint(evt);
        awaitingContinuation = false;
        Enter(OccultPotStatus.NearProbe);
        LogDig($"near-plan; raw={evt.RawText}; direction={direction}; vector={vector}; origin={origin}; target={target}; attempt={nearAttempts + 1}; totalPlanned={nearDistance + meters:F1}");
        return true;
    }

    private void TickNearProbe(double now)
    {
        if (BeginOpeningIfNeeded()) return;
        if (now - nearStarted >= 30) { FallbackNear("step-timeout-30s"); return; }
        if (!hooks.PreferTp || !hooks.UseDiveTp) { FallbackNear("travel-mode-changed"); return; }
        if (!PlayerReader.IsAvailable() || PlayerReader.IsBusy()) return;
        if (!PlayerReader.HasStatus(1531u) || hooks.GetElixirCount() <= 0)
        { FallbackNear("reward-status-or-item-missing"); return; }
        if (PlayerReader.IsOnMount()) { MountActions.TryDismount(); return; }
        if (!nearMoved)
        {
            if (now < nearNextAction) return;
            nearNextAction = now + 0.5;
            if (Vector3.Distance(hooks.PlayerPosition, nearOrigin) > 1f)
            { FallbackNear("player-moved-before-dispatch"); return; }
            var moved = hooks.MoveShortStep(target);
            LogDig($"near-move; target={target}; accepted={moved}");
            if (!moved) return;
            nearMoved = true; nearAttempts++;
            nearDistance += nearStepLength;
            nearNextAction = now;
        }
        if (Vector3.Distance(hooks.PlayerPosition, target) > 1f)
        {
            if (now - nearStarted >= 15) FallbackNear("arrival-timeout-15s");
            return;
        }
        hooks.StopMove();
        if (!nearUsed)
        {
            if (now < nearNextAction) return;
            nearNextAction = now + 1;
            var recast = InventoryReader.GetElixirRecastRemaining();
            if (recast > 0.15f)
            { LogDig($"near-item; item=2003296; result=cooldown; remaining={recast:F2}"); return; }
            var accepted = hooks.TryUseElixir();
            LogDig($"near-item; item=2003296; attempt={nearAttempts}; position={hooks.PlayerPosition}; requestAccepted={accepted}; server-result=pending");
            if (!accepted) return;
            nearUsed = true; nearUsedAt = now;
            elixirSent = true; elixirUsedAt = now;
            lastTalkLine = null; // Identical direction/distance text is valid after each use.
            return;
        }
        if (now - nearUsedAt >= 8) FallbackNear("no-followup-hint-or-chest-8s");
    }

    private void FallbackNear(string reason)
    {
        hooks.StopMove();
        nearDisabled = true; // Never restart the same bounded probe budget in this chest round.
        LogDig($"near-fallback; reason={reason}; attempts={nearAttempts}; cumulative={nearDistance:F1}; raw={nearHint.RawText}");
        ApplyCandidateHint(nearHint);
    }
}
