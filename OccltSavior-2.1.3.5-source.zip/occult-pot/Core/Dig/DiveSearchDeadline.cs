namespace OccultPot.Core.Dig;

// Per treasure round, independent of phase/hint retries and all pre-entry work.
internal sealed class DiveSearchDeadline
{
    internal DateTimeOffset? SearchStartedAt { get; private set; }
    private double started;
    private bool satisfied;
    internal void Begin(double now, DateTimeOffset utcNow)
    {
        started = now; SearchStartedAt = utcNow; satisfied = false;
    }
    internal void FoundValidTarget() => satisfied = true;
    internal bool Expired(double now) => SearchStartedAt.HasValue && !satisfied && now - started >= 60;
    internal double Elapsed(double now) => SearchStartedAt.HasValue ? Math.Max(0, now - started) : 0;
}
