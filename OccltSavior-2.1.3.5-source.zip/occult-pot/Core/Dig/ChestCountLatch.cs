using OccultPot.Models;

namespace OccultPot.Core.Dig;

// One count per tracked chest: seeing a chest, using medicine or a failed interaction is not a count.
internal sealed class ChestCountLatch
{
    private uint entityId;
    private ChestGrade grade;
    private bool accepted;
    private bool counted;

    internal void Reset() { entityId = 0; grade = ChestGrade.Unknown; accepted = counted = false; }
    internal void Observe(uint id, ChestGrade value)
    {
        if (entityId != id) Reset();
        entityId = id;
        grade = value;
    }
    internal void Interacted(bool success) => accepted |= success;
    internal bool TryTake(bool gone, out ChestGrade value)
    {
        value = grade;
        if (entityId == 0 || !accepted || !gone || counted) return false;
        counted = true;
        return true;
    }
}
