using Dalamud.Game.Chat;
using OccultPot.Core.Carrot;
using System.Diagnostics;
using OccultPot.Core.Adapters;
using OccultPot.Core.Data;
using OccultPot.Core.Dig;
using OccultPot.Core.Session;
using OccultPot.Models;
using OmenTools;
using OmenTools.Dalamud;

namespace OccultPot.Core;

internal sealed class OccultPotService
{
    private readonly PotSessionOrchestrator session;
    private readonly PotDigController dig;
    private readonly Func<PluginConfiguration> getConfig;
    private readonly Action saveConfig;
    private bool digOnlyMode;
    private bool carrotOnlyMode;
    private readonly CarrotRunner carrot;
    internal ActivityHistory History => getConfig().ActivityHistory ??= new();
    private void RecordActivity(string type, string reason)
    {
        var entry = History.Record(type, reason, session?.Phase.ToString() ?? "Idle", session?.ActivityContext ?? "unknown");
        DLog.Debug($"[OccltSavior.Activity] {entry.Summary}; type={type}; state={entry.State}; {entry.Target}");
        try { saveConfig(); } catch (Exception ex) { DLog.Error("活动记录保存失败", ex); }
    }
    internal long CarrotChestsOpened => getConfig().CarrotChestsOpened;
    internal string? CarrotStatus => !session.IsExiting && (carrotOnlyMode || carrot.IsActive) ? carrot.Status : null;

    internal SessionPhase Phase => session.Phase;

    internal RuntimeStatus Status => session.Status;

    internal bool IsDigOnlyMode => digOnlyMode;

    internal string ActivityLabel => CarrotStatus != null ? "自动胡萝卜" : SessionBriefFormatter.Activity(this);

    internal string CurrentTargetLabel => CarrotStatus != null ? carrot.TargetLabel : SessionBriefFormatter.CurrentTarget(this);

    internal string NextTargetLabel => SessionBriefFormatter.NextTarget(this);

    internal bool TryGetCurrentTargetLabel(out string label) => session.TryGetCurrentTargetLabel(out label);

    internal bool TryGetNextTargetLabel(out string label) => session.TryGetNextTargetLabel(out label);

    internal string RouteSummary => session.RouteSummary;

    internal RuntimeStatus TrackerStatus => session.TrackerStatus;

    internal RuntimeStatus TrackerCatalog => session.TrackerCatalog;

    internal PotKind? ActiveKind => session.ActiveKind;

    internal bool IsSessionRunning => session.IsRunning;

    internal bool IsDigActive => dig.IsActive;

    internal bool IsRunning =>
        getConfig().Enabled && (session.IsRunning || digOnlyMode || carrotOnlyMode || dig.IsActive);

    internal bool CanSkipIsland =>
        getConfig().Enabled && session.CanSkipCurrentIsland && !digOnlyMode;

    internal bool IsPotFateCombat => session.IsPotFateCombat;

    internal OccultPotSnapshot? DigSnapshot => dig.GetSnapshot();

    internal DigStatistics Statistics => getConfig().DigStatistics ??= new();

    internal void ResetStatistics()
    {
        getConfig().DigStatistics = new();
        saveConfig();
    }

    private void OnChestOpened(bool continuation, ChestGrade grade)
    {
        Statistics.Record(continuation, grade);
        DLog.Debug($"[OccultPot.Count] counted; continuation={continuation}; grade={grade}; " +
                   $"initialGold={Statistics.InitialGold}; initialSilver={Statistics.InitialSilver}; " +
                   $"initialBronze={Statistics.InitialBronze}; continuationGold={Statistics.ContinuationGold}");
        try { saveConfig(); }
        catch (Exception ex) { DLog.Error("[OccultPot.Count] 保存计数失败，当前计数仍保留在内存", ex); }
    }

    internal OccultPotService(Func<PluginConfiguration> getConfig, Action saveConfig)
    {
        this.getConfig  = getConfig;
        this.saveConfig = saveConfig;
        carrot = new CarrotRunner(new CarrotGameWorld(), () =>
        {
            getConfig().CarrotChestsOpened++;
            try { saveConfig(); } catch (Exception ex) { DLog.Error("[OccultSavior.Carrot] 保存计数失败", ex); }
        }, RecordActivity);
        dig     = new PotDigController(OnDigStopped, () => getConfig().PreferTp, () => getConfig().UseDiveTp, () => getConfig().TpIntervalSeconds, OnChestOpened);
        session = new PotSessionOrchestrator(getConfig, dig, carrot, RecordActivity);
    }

    private void OnDigStopped(StopReason reason)
    {
        if (session.IsExiting) return; // Emergency cancellation must not disable the service.
        if (digOnlyMode && reason == StopReason.SearchTimeout)
        {
            digOnlyMode = false;
            session.RequestSearchTimeoutExit();
            return;
        }
        if (!digOnlyMode)
        {
            session.OnDigStopped(reason);
            return;
        }

        RecordActivity("Stop", "仅挖箱结束：" + reason);
        digOnlyMode           = false;
        getConfig().Enabled   = false;
        saveConfig();
    }

    internal void Tick()
    {
        session.TickTreasureCleanup();
        var config = getConfig();
        if (!config.Enabled)
            return;

        var wasExiting = session.IsExiting;
        if (session.TickExitSafety())
        {
            if (wasExiting && !session.IsExiting && digOnlyMode)
            {
                digOnlyMode = false;
                session.Start(); // Interrupted dig cannot resume on the old island; replan automatically.
            }
            return;
        }
        if (carrotOnlyMode)
        {
            var now = Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
            try { if (carrot.TryStart(now, config)) carrot.Tick(now, config); }
            catch (Exception ex) { RecordActivity("Stop", "胡萝卜异常：" + ex.Message); carrot.Cancel("异常停止"); config.Enabled = false; carrotOnlyMode = false; saveConfig(); DLog.Error("[OccultSavior.Carrot] 执行失败", ex); }
            return;
        }
        if (!digOnlyMode)
        {
            session.Tick();
            if (session.Phase == SessionPhase.Failed)
            {
                DLog.Debug($"[OccultSavior.Travel] session-disabled; reason={session.Status.Code}; enabled=false; fail-safe-policy-unchanged");
                config.Enabled = false;
                saveConfig();
            }
            return;
        }

        dig.Tick();
        if (dig.IsActive || !digOnlyMode || session.IsExiting)
            return;

        RecordActivity("Stop", "仅挖箱执行结束");
        digOnlyMode     = false;
        config.Enabled  = false;
        saveConfig();
    }

    internal void OnChatMessage(IHandleableChatMessage message) =>
        OnChatText(((IMutableChatMessage)message).Message.TextValue);

    internal void OnChatText(string text) =>
        session.OnChatMessage(text);

    internal void Start()
    {
        if (!OccultPotRuntime.RequireSupported())
            return;

        var config = getConfig();
        RecordActivity("Resume", "用户启动/恢复");
        config.NormalizeCarrot();
        carrot.Cancel("重新启动");
        carrotOnlyMode = config.RunMode == RunMode.Carrot;
        if (carrotOnlyMode)
        {
            session.Stop();
            digOnlyMode = false;
            config.Enabled = true;
            saveConfig();
            return;
        }
        config.SyncHomeWorldLock();
        digOnlyMode    = false;
        config.Enabled = true;
        session.Start();
        if (session.Phase == SessionPhase.Failed)
            config.Enabled = false;
        saveConfig();
    }

    internal void StartDigOnly()
    {
        if (!OccultPotRuntime.RequireSupported() ||
            !ZoneIds.IsSupportedIsland((ushort)DService.Instance().ClientState.TerritoryType))
            return;

        RecordActivity("Resume", "用户启动仅挖箱");
        carrot.Cancel("仅挖箱启动");
        carrotOnlyMode = false;
        session.Stop();
        var config = getConfig();
        digOnlyMode    = true;
        config.Enabled = true;
        saveConfig();
        if (dig.Start().Success)
        {
            ExternalCommands.Echo("[挖箱] 挖箱已启动");
            return;
        }

        RecordActivity("Stop", "仅挖箱启动失败");
        digOnlyMode    = false;
        config.Enabled = false;
        saveConfig();
    }

    internal void Stop()
    {
        RecordActivity("Stop", "用户停止");
        carrot.Cancel("用户停止");
        carrotOnlyMode = false;
        digOnlyMode = false;
        session.Stop();
        if (dig.IsActive)
            dig.Stop();
        getConfig().Enabled = false;
        saveConfig();
    }

    internal void Uninit()
    {
        RecordActivity("Stop", "插件卸载");
        carrot.Cancel("插件卸载");
        session.Uninit();
    }

    internal void SkipCurrentIsland()
    {
        if (!digOnlyMode && session.CanSkipCurrentIsland)
        {
            carrot.Cancel("跳过当前岛");
            session.RequestSkipIsland();
        }
    }

    internal bool ShouldKeepPotFateTarget()
    {
        if (!getConfig().Enabled || session.TreasureOwnsControl || digOnlyMode || carrotOnlyMode || carrot.IsActive || dig.IsActive)
            return false;
        return session.ShouldKeepPotFateTarget();
    }
}
