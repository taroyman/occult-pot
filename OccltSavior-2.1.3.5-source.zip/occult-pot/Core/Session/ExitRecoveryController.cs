namespace OccultPot.Core.Session;

internal enum ExitMethod { Callback, NativeDutyExit }
internal enum ExitTickResult { Idle, Waiting, Completed }

internal readonly record struct ExitSnapshot(ushort Territory, bool OnIsland, bool InDuty,
    bool Available, bool Busy, bool BetweenAreas, bool Combat, double? RemainingSeconds,
    bool RoundEnded, bool HasWork)
{
    internal bool StableOutside => Territory != 0 && !OnIsland && !InDuty && Available && !Busy && !BetweenAreas;
}

internal interface IIslandExitWorld
{
    void ResetAttempt();
    string TickAttempt(ExitMethod method);
    void Log(string message);
}

// No game clock or task queue: recovery keeps ticking even if an old queue was aborted.
internal sealed class ExitRecoveryController(IIslandExitWorld world)
{
    internal bool Active { get; private set; }
    internal bool Emergency { get; private set; }
    internal bool Recovering { get; private set; }
    internal int Attempt { get; private set; }
    internal ExitMethod Method { get; private set; }
    private double started, attemptStarted, nextAttempt, nextLog, lastTick;
    private double? outsideSince, lowTimerSince;
    private ushort timerTerritory;
    private bool sawPositiveTimer, attempting;
    private string lastResult = "not-issued";

    internal void Reset()
    {
        Active = Emergency = Recovering = attempting = sawPositiveTimer = false;
        Attempt = 0;
        Method = ExitMethod.Callback;
        lastResult = "not-issued";
        started = attemptStarted = nextAttempt = nextLog = lastTick = 0;
        outsideSince = lowTimerSince = null;
        timerTerritory = 0;
        world.ResetAttempt();
    }

    internal bool ShouldEmergency(double now, ExitSnapshot s, int thresholdMinutes)
    {
        if (!s.OnIsland || s.Territory != timerTerritory)
        {
            timerTerritory = s.Territory;
            lowTimerSince = null;
            sawPositiveTimer = false;
        }
        if (!s.OnIsland || !s.Available || s.BetweenAreas || s.RemainingSeconds is not { } seconds
            || !double.IsFinite(seconds) || seconds < 0)
        {
            lowTimerSince = null;
            return false;
        }
        if (seconds > 0) sawPositiveTimer = true;
        // Initial zero is often an uninitialised director, not an expired duty.
        if (!sawPositiveTimer || seconds >= Math.Clamp(thresholdMinutes, 1, 30) * 60)
        {
            lowTimerSince = null;
            return false;
        }
        lowTimerSince ??= now;
        return now - lowTimerSince >= 1;
    }

    internal void Begin(double now, ExitSnapshot s, bool emergency, string reason)
    {
        if (!Active)
        {
            Active = true;
            started = lastTick = now;
            nextAttempt = now;
            outsideSince = null;
            Attempt = 0;
            Recovering = attempting = false;
        }
        Emergency |= emergency; // Never clear emergency while still inside.
        Log(now, s, emergency ? "EmergencyExit" : "LeavingIsland", reason);
    }

    internal ExitTickResult Tick(double now, ExitSnapshot s)
    {
        if (!Active) return ExitTickResult.Idle;
        if (s.StableOutside)
        {
            outsideSince ??= now;
            if (now - outsideSince >= 2)
            {
                Log(now, s, "success", "stable-outside; resume-scheduler");
                Reset();
                return ExitTickResult.Completed;
            }
        }
        else outsideSince = null;

        // Independent of task queue state. A long frame stall cannot kill the exit intent.
        if (s.OnIsland && s.RoundEnded && !s.HasWork && now - lastTick >= 45)
        {
            Recovering = true;
            attempting = false;
            nextAttempt = now;
            Log(now, s, "watchdog", "LeavingIsland stalled >=45s; rearm-exit");
        }
        lastTick = now;

        if (attempting && now - attemptStarted >= (Attempt <= 2 ? 30 : 20))
        {
            attempting = false;
            Recovering = true;
            nextAttempt = now; // Attempts 3+ are spaced 20s apart, including their wait.
            Log(now, s, "timeout", $"still-inside-or-unconfirmed; lastResult={lastResult}; entering ExitRecovery; nextRetry=0s");
        }
        if (!attempting && now >= nextAttempt && s.OnIsland)
        {
            Attempt++;
            Method = Attempt <= 2 || Attempt % 2 == 0 ? ExitMethod.Callback : ExitMethod.NativeDutyExit;
            attemptStarted = now;
            attempting = true;
            nextLog = now + 10;
            world.ResetAttempt();
            lastResult = "not-issued";
            Log(now, s, "attempt", "fresh Territory/Duty/Player check; nextRetry=" + (Attempt <= 2 ? "30s" : "20s"));
        }
        // A short bounded interaction window, then silence until the next attempt.
        if (attempting && s.OnIsland && !s.BetweenAreas && s.Available && !s.Combat
            && now - attemptStarted < 8)
        {
            try { lastResult = world.TickAttempt(Method); }
            catch (Exception ex)
            {
                lastResult = $"exception:{ex.GetType().Name}:{ex.Message}";
                Recovering = true;
                // Don't throw out of the host update or retry an exception every frame.
                attempting = false;
                nextAttempt = now + 20;
                Log(now, s, "exception", $"{lastResult}; entering ExitRecovery; nextRetry=20s");
            }
        }
        if (now >= nextLog)
        {
            nextLog = now + 10;
            Log(now, s, "waiting", $"lastResult={lastResult}; nextRetry={Math.Max(0, (attempting ? attemptStarted + (Attempt <= 2 ? 30 : 20) : nextAttempt) - now):F1}s");
        }
        return ExitTickResult.Waiting;
    }

    private void Log(double now, ExitSnapshot s, string action, string reason)
    {
        try
        {
            world.Log($"[OccltSavior.Exit] {action}; attempt=#{Attempt}; method={Method}; " +
                $"Territory={s.Territory}; IsInDuty={s.InDuty}; Player.Available={s.Available}; Player.Busy={s.Busy}; " +
                $"BetweenAreas={s.BetweenAreas}; Combat={s.Combat}; elapsed={now - started:F1}s; " +
                $"attemptWait={(Attempt == 0 ? 0 : now - attemptStarted):F1}s; ExitRecovery={Recovering}; " +
                $"EmergencyExit={Emergency}; remaining={s.RemainingSeconds?.ToString("F1") ?? "unknown"}; reason={reason}");
        }
        catch { /* Diagnostics must not break recovery. */ }
    }
}
