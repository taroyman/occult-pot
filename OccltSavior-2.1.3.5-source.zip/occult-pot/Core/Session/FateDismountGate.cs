namespace OccultPot.Core.Session;

// Stop navigation, issue at most two requests three seconds apart, then observe the mount flag.
internal sealed class FateDismountGate
{
    private double? started;
    private int attempts;
    private double lastAttempt;
    internal bool Ready { get; private set; }
    internal void Reset() { started = null; attempts = 0; Ready = false; }

    internal bool Tick(double now, bool mounted, bool busy, bool navigating,
        Action stop, Action dismount, Action<int> log, out bool failed)
    {
        failed = false;
        if (Ready && !mounted) return true;
        if (Ready) Reset();
        if (!started.HasValue) { started = now; stop(); return false; }
        var elapsed = now - started.Value;
        if (!navigating && !mounted && !busy) { Ready = true; return true; }
        if (elapsed >= 10 || attempts == 2 && now - lastAttempt >= 3)
        { failed = true; return false; }
        if (navigating) { stop(); return false; }
        if (mounted && !busy && (attempts == 0 || attempts == 1 && now - lastAttempt >= 3))
        {
            attempts++;
            lastAttempt = now;
            dismount();
            log(attempts);
        }
        return false;
    }
}
