using OccultPot.Core.Adapters;
using OccultPot.Core.Game;
using OccultPot.Models;

namespace OccultPot.Core.Session;

internal sealed partial class PotSessionOrchestrator
{
    private readonly ExitRecoveryController exit = new(new IslandExitWorld());
    private bool standaloneExit;
    internal bool IsExiting => exit.Active || phase is SessionPhase.WaitLeave or SessionPhase.ExitRecovery or SessionPhase.EmergencyExit;
    private static double ExitNow => Environment.TickCount64 / 1000d;
    internal void RequestSearchTimeoutExit()
    {
        route.Build(getConfig());
        targetTerritory = (ushort)OmenTools.OmenService.GameState.TerritoryType;
        committedWorldID = OccultPot.Core.Data.CnWorldCatalog.CurrentWorldID;
        RememberSkippedIsland();
        afterLeave = AfterLeave.Advance;
        RecordActivity("Abort", "DiveTP 搜索超时，退岛重新规划");
        BeginLeave(RuntimeStatus.Literal("搜索超时，退岛重新规划"));
    }
    private void QuiesceForExit()
    {
        treasure.Cancel(ExitNow, "退出岛，取消 DR 并恢复职业");
        taskHelper.Abort();
        find.Stop();
        carrot.Cancel("退出岛，暂停任务");
        carrotOwnsMovement = false;
        BmrAi.ForceOff();
        vnav.Stop();
        if (dig.IsActive) dig.Stop();
        activeLayout = null;
        fateDismount.Reset();
    }

    private void BeginLeave(RuntimeStatus status)
    {
        if (IsExiting) return; // Repeated requests must not reset recovery budgets.
        standaloneExit = false;
        RecordActivity("Abort", $"退岛：{status.Code} {string.Join(", ", status.Args ?? [])}");
        Enter(SessionPhase.WaitLeave, status);
        QuiesceForExit();
        exit.Begin(ExitNow, IslandExitWorld.Read(true, false), false, status.Code.ToString());
    }

    // Called before every service mode, including standalone carrot/dig.
    internal bool TickExitSafety()
    {
        var now = ExitNow;
        var snapshot = IslandExitWorld.Read(IsExiting, dig.IsActive || carrot.IsActive || phase == SessionPhase.WaitFight);
        if (!exit.Emergency && exit.ShouldEmergency(now, snapshot, getConfig().EmergencyExitThresholdMinutes))
        {
            standaloneExit = !IsRunning;
            if (!IsExiting) afterLeave = AfterLeave.Advance;
            RecordActivity("Abort", "EmergencyExit：任务时间即将结束");
            Enter(SessionPhase.EmergencyExit, RuntimeStatus.Literal("任务时间即将结束，紧急退岛"));
            QuiesceForExit();
            snapshot = IslandExitWorld.Read(true, false);
            exit.Begin(now, snapshot, true,
                $"RemainingDutyTime={snapshot.RemainingSeconds:F1}s < threshold={Math.Clamp(getConfig().EmergencyExitThresholdMinutes, 1, 30) * 60}s");
        }
        // Watchdog also restores exit intent if a queued task/phase survived without its controller.
        if (!exit.Active && IsExiting && (snapshot.StableOutside || (snapshot.OnIsland && !snapshot.HasWork && TimedOut(45))))
            exit.Begin(now, snapshot, phase == SessionPhase.EmergencyExit, snapshot.StableOutside
                ? "watchdog: outside exit phase lacks controller; verify completion"
                : "watchdog: LeavingIsland >=45s; no active work; rearm");
        if (!exit.Active) return IsExiting;

        var result = exit.Tick(now, snapshot);
        if (result == ExitTickResult.Completed)
        {
            RecordActivity("Resume", "退岛完成，恢复调度");
            var resume = afterLeave;
            afterLeave = AfterLeave.Advance;
            if (standaloneExit)
            {
                standaloneExit = false;
                Enter(SessionPhase.Idle, RuntimeStatus.Literal("已退岛，等待原模式继续"));
            }
            else switch (resume)
            {
                case AfterLeave.ResumeEnsureWorld:
                    Enter(SessionPhase.EnsureWorld, RuntimeStatus.Of(RuntimeStatusCode.WorldTravel_AfterLeave));
                    break;
                case AfterLeave.ResumeIslandVisit:
                    BeginIslandVisit();
                    break;
                default:
                    AdvanceAfterLeave();
                    break;
            }
            return true; // Don't run an old standalone task in this same frame.
        }
        Enter(exit.Emergency ? SessionPhase.EmergencyExit : exit.Recovering ? SessionPhase.ExitRecovery : SessionPhase.WaitLeave,
            RuntimeStatus.Literal($"{(exit.Emergency ? "紧急退岛" : exit.Recovering ? "退岛恢复" : "等待退岛")} · 第 {exit.Attempt} 次 · {exit.Method}"));
        return true;
    }

    private bool TryRecoverExitFailure(RuntimeStatus status)
    {
        if (IsExiting || status.Code == RuntimeStatusCode.Leave_Timeout)
        {
            if (!exit.Active)
            {
                Enter(SessionPhase.ExitRecovery, status);
                QuiesceForExit();
                exit.Begin(ExitNow, IslandExitWorld.Read(true, false), false, $"intercepted Fail({status.Code})");
            }
            return true;
        }
        return false;
    }
}
