namespace OccultPot.Models;

public sealed record ActivityEntry(DateTimeOffset At, string Type, string Reason, string State, string Target)
{
    public string Summary => $"[{At.LocalDateTime:HH:mm:ss}] {Type switch { "Stop" => "插件停止", "Pause" => "插件暂停", "Abort" => "任务中止", _ => "插件恢复" }}：{Reason}";
}

public sealed class ActivityHistory
{
    public List<ActivityEntry> Entries = [];
    public ActivityEntry? LastPause;
    public ActivityEntry? LastStop;
    public ActivityEntry? LastPauseOrStop => LastStop is null ? LastPause : LastPause is null || LastStop.At >= LastPause.At ? LastStop : LastPause;

    public ActivityEntry Record(string type, string reason, string state, string target, DateTimeOffset? at = null)
    {
        var entry = new ActivityEntry(at ?? DateTimeOffset.Now, type, reason, state, target);
        Entries ??= [];
        Entries.Add(entry);
        while (Entries.Count > 10) Entries.RemoveAt(0);
        if (type == "Pause") LastPause = entry;
        if (type == "Stop") LastStop = entry;
        return entry;
    }
}
