namespace OccultPot.Models;

public enum ChestGrade { Unknown, Bronze, Silver, Gold }

public sealed class DigStatistics
{
    public long InitialGold;
    public long InitialSilver;
    public long InitialBronze;
    public long ContinuationGold;
    public long InitialUnknown;
    public long ContinuationOther;

    public void Record(bool continuation, ChestGrade grade)
    {
        if (continuation)
        {
            if (grade == ChestGrade.Gold) ContinuationGold++;
            else ContinuationOther++;
            return;
        }
        switch (grade)
        {
            case ChestGrade.Gold: InitialGold++; break;
            case ChestGrade.Silver: InitialSilver++; break;
            case ChestGrade.Bronze: InitialBronze++; break;
            default: InitialUnknown++; break;
        }
    }
}
