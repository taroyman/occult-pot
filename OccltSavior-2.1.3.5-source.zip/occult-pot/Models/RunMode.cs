namespace OccultPot.Models;

// Preserve legacy value 2: old Mixed configurations must never opt into DR.
public enum RunMode { Pot = 0, Carrot = 1, Mixed = 2, AutoPotTreasure = 3 }

internal static class RunModePolicy
{
    internal static bool UsesTreasure(RunMode mode) => mode == RunMode.AutoPotTreasure;
}
