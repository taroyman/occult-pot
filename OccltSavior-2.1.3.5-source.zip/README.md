# 新月岛拯救者 / Occlt Savior 2.1.3.5

基于本机交付的完整 2.1.3.4 源码；国服 Dalamud API 15、Windows x64、.NET 10。主程序集 `OccltSavior.dll`，命令 `/ocsa`。

## 安装

1. 对旧版执行 `/ocsa stop`，然后停用旧版。
2. 解压 `OccltSavior-2.1.3.5-api15.zip`，保留同目录全部 DLL 和 JSON。
3. 在 Dalamud Dev Plugin Locations 添加解压目录中的 `OccltSavior.dll`，仅启用这一份，确认版本 2.1.3.5。
4. `/ocsa` 打开窗口，在停止状态选择运行模式。跑刀需启用 Daily Routines 的区域传送与自动寻宝功能，并解锁自由人和魔寻宝；其他原有依赖保持不变。

未修改游戏安装目录或替换已加载插件。原配置、统计、暂停/停止历史保留。旧 `TreasureAutomationEnabled` 字段不再启用寻宝，升级后必须主动选择“自动挖罐跑刀”。旧 Mixed 数值 2 继续转换为普通挖罐加空闲胡萝卜；新模式保存为数值 3，避免旧配置误开跑刀。

## 三种运行模式

| 模式 | 行为 |
|---|---|
| 自动挖罐 | 原有挖罐流程；不会触发自由人探测、魔寻宝或 DR 自动寻宝。 |
| 自动胡萝卜 | 原有胡萝卜流程保持不变。 |
| 自动挖罐跑刀 | 每次岛屿访问先记录辅助职业，切自由人并使用一次魔寻宝；根据铜箱数决定是否启动 DR 两环，结束后恢复职业并继续挖罐。 |

`/ocsa dig` 仍是原有直接挖箱入口。原有挖罐等待时胡萝卜选项、配置的常规职业切换和岛内导航继续沿用；本次隔离的是魔寻宝和 `/pdr ptreasure` 前置联动。

## 跑刀流程

聊天解析只依赖“当前区域”“银宝箱”“铜宝箱”及数字，支持数量顺序改变、全角数字、空格和常见标点。只接收本次等待窗口内第一条有效结果，不用远距离 ObjectTable 数箱子。默认 `BronzeTreasureThreshold=30`，采用 `>=`；小于阈值不传送、不启动寻宝，恢复原辅助职业后继续挖罐。

| 岛区 | 外环预备点 | 内环预备点 |
|---|---|---|
| 南岛 | 放浪神圣域遗迹 | 石塔水沼 |
| 北岛 | 沉没圣堂前 | 妖火渔村 |

每环通过现有 `/pdr ptp 预备点名称` 协议与 IslandAethernet 落点数据传送。必须在指定落点 50 米内，且距离该岛据点大于 90 米、可操作状态稳定 2 秒，才发送 `/pdr ptreasure 外环` 或 `/pdr ptreasure 内环`。已在正确预备点时复用当前位置。每环各有一次重试；命令发送成功不代表传送成功。

每环发送寻宝命令后清空 `HasLeftCamp`，随后实际观察到角色距据点大于 90 米才置为 true；之后回到据点 80 米内并稳定 2 秒，判定完成。外环完成先释放 DR 路线状态，再准备内环。内环完成发送 abort 清理路线状态并恢复原职业。不监听 TTS 或亚返回施法。

整个探测/准备/跑刀/恢复阶段持有独占调度权。进入时取消本插件移动与任务队列、关闭 BMR；期间不执行挖罐、胡萝卜、跨服调度或本插件移动。EmergencyExit 仍有最高优先级，会先取消寻宝再按原退岛链路处理。

## 超时与回退

| 环节 | 上限与处理 |
|---|---|
| 切自由人 | 15 秒；失败则恢复原职业并继续挖罐。 |
| 等待施放条件 | 10 秒；魔寻宝只请求使用一次。 |
| 等待魔寻宝聊天 | 8 秒；超时记录原因并回退。这与 FATE 后原有约 8 秒等待无关。 |
| 每环预备传送 | 每次 20 秒，最多两次；仍失败则回退。 |
| 命令后离营观察 | 45 秒未观察到离营则 abort 并回退。 |
| 每环运行 | 最长 15 分钟；超时 abort 并回退。 |
| 原辅助职业恢复 | 前台最多 20 秒；被游戏状态阻挡时保留原职业，每 2 秒后台重试，同时释放普通挖罐流程。 |

`/pdr` 未注册直接回退；命令拒绝/异常及超时均记录原因，保持插件 Enabled。`ProcessCommand` 返回 true 仅代表命令已分发，不能证明 DR 子功能已启用；无返回据点进展时由该环最长时限兜底。停止、卸载和紧急退出都会尝试 abort 与职业恢复；卸载后无法继续后台重试。

## 保留与验证

保留 2.1.3.4 的 60 秒 DiveTP 搜罐期限、ETA 选罐与暂停/停止历史；保留 2.1.3.3 的 ExitRecovery/watchdog/EmergencyExit 和 2.1.3.2 的黄金箱开启、北岛“很近”短步进。

FATE 后约 8 秒等待完全未改；未处理 PR、KeitaPotTracker/TLS 或网络问题。

编译与测试证据见 `验证结果.txt`、`2.1.3.5-测试清单.md` 和源码包 `verification/`。自动测试验证生产状态机和模拟游戏边界；本次未在游戏客户端执行真实 DR 路线、技能、传送或 Dev Plugin 加载验证。

## 源码构建

安装 .NET 10 SDK，使用本机国服 API 15 程序集和 Dev 包依赖：

```powershell
dotnet build ./occult-pot/OccltSavior.Dev.csproj -c Release -p:OccultPotDependencyDir="Dev包解压后的绝对目录"
dotnet run --project ./regression/Regression.csproj -c Release
dotnet run --project ./carrot-tests/CarrotTests.csproj -c Release
dotnet run --project ./exit-tests/ExitTests.csproj -c Release
```

`DALAMUD_HOME` 默认 `%APPDATA%/XIVLauncherCN/addon/Hooks/dev`，Dev 构建输出 `occult-pot/bin/Dev`。实际编译使用独立 Dev 工程；原 `OccltSaviorPlugin.csproj` 仍需同级 OmenTools / DailyRoutines.CodeAnalysis 源码。第三方声明见 THIRD-PARTY-NOTICES.md。
