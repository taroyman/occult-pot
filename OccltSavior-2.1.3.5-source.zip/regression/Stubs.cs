using System.Numerics;
using OccultPot.Models;

// Only the game/environment boundary is replaced; the runner/parser/tables are linked production sources.
namespace OccultPot.Core.Game
{
    internal static class PlayerReader
    {
        internal static bool Reward = true, Busy, Available = true, Mounted;
        internal static bool HasStatus(uint id) => id == 1531 && Reward;
        internal static bool IsBusy() => Busy;
        internal static bool IsAvailable() => Available;
        internal static bool IsOnMount() => Mounted;
        internal static bool Combat, BetweenAreas;
        internal static bool IsInCombat() => Combat;
        internal static bool IsBetweenAreas() => BetweenAreas;
        internal static float DistanceTo(Vector3 target) => target.Length();
    }
    internal static class InventoryReader
    {
        internal static float Recast;
        internal static float GetElixirRecastRemaining() => Recast;
    }
    internal static class TreasureChestInteractor
    {
        internal static void ClearSnapshot() { }
    }
}
namespace OccultPot.Core.Adapters
{
    internal static class ExternalCommands
    {
        internal static void Echo(string text) { }
        internal static List<string> Sent = [];
        internal static bool Run(string text) { Sent.Add(text); return true; }
    }
}
namespace OmenTools.Extensions
{
    internal static class IConditionExtension
    {
        internal static bool get_IsAbleToMount(OmenTools.DService.Conditions c) => false;
    }
}
namespace OmenTools
{
    internal sealed class DService
    {
        private static readonly DService Value = new();
        internal static DService Instance() => Value;
        internal Conditions Condition { get; } = new();
        internal GameGui GameGUI { get; } = new();
        internal sealed class GameGui
        {
            internal AddonPtr GetAddonByName(string name) => new(FFXIVClientStructs.FFXIV.Component.GUI.AtkUnitBase.Get(name));
        }
        internal record struct AddonPtr(nint Address);
        internal sealed class Conditions { internal bool IsCasting => OccultPot.Core.Game.PlayerReader.Busy; }
    }
}
namespace OmenTools.Dalamud
{
    internal static class DLog
    {
        internal static List<string> Lines = [];
        internal static void Debug(string text) => Lines.Add(text);
        internal static void Error(string text, Exception ex) => Lines.Add(text);
    }
}
namespace OccultPot.Core.Dig
{
    internal sealed class OccultPotHooks
    {
        private readonly Action<StopReason>? onStopped;
        internal OccultPotHooks(Action<StopReason>? onStopped = null, Func<bool>? preferTp = null,
            Func<bool>? useDiveTp = null, Func<float>? tpIntervalSeconds = null, Action<bool,ChestGrade>? onChestOpened = null)
        {
            this.onStopped = onStopped;
            PreferTp = preferTp?.Invoke() ?? true;
            UseDiveTp = useDiveTp?.Invoke() ?? true;
        }
        internal void ConfigureChestTable(PotKind? kind) => RerollOnly = false;
        internal bool PreferTp = true, ChestVisible, Gone, OpenSucceeds, UseSucceeds = true, RerollOnly;
        internal double NowSeconds;
        internal double SearchNowSeconds => NowSeconds;
        internal string SearchContext => "DC=test; World=1; Territory=1252; Instance=test-1";
        internal uint TerritoryID = 1252;
        internal Vector3 PlayerPosition { get; set; } = Vector3.Zero;
        internal bool UseDiveTp = true, NearMoveAccept = true, NearArrive;
        internal float NearStepMeters = 5, NearMaxDistance = 30;
        internal int NearMaxAttempts = 6;
        internal List<Vector3> ShortTargets = [];
        internal bool MoveShortStep(Vector3 p) { if (!NearMoveAccept) return false; ShortTargets.Add(p); if (NearArrive) PlayerPosition = p; return true; }
        internal int Uses, UseAttempts, Moves, OpenAttempts, Snapshots;
        internal int ElixirCount = 1;
        internal int GetElixirCount() => ElixirCount;
        internal List<StopReason> Stops = [];
        internal uint ChestId = 1;
        internal ChestGrade Grade = ChestGrade.Gold;
        internal DigStatistics Counts = new();
        private readonly ChestCountLatch countLatch = new();
        internal void Tick() { }
        internal void StopMove() { }
        internal void OnStopped(StopReason reason) { Stops.Add(reason); onStopped?.Invoke(reason); }
        internal void SnapshotExistingChests() { Snapshots++; Gone = false; countLatch.Reset(); }
        internal void PreferRerollChests() => RerollOnly = true;
        internal IReadOnlyList<Vector3> GetChestTable(uint id) => OccultPotChestTables.GetPositions(id, PotKind.North, RerollOnly);
        internal bool HasPotChest(float range) => ChestVisible;
        internal Vector3? NearbyPotChestPosition(float range)
        {
            if (!ChestVisible) return null;
            countLatch.Observe(ChestId, Grade);
            return new Vector3(1, 0, 0);
        }
        internal bool TrackedChestGone() => Gone;
        internal bool TryOpenPotChest(float range) { OpenAttempts++; var ok = ChestVisible && OpenSucceeds; countLatch.Interacted(ok); return ok; }
        internal bool RecordOpenedChest(bool continuation)
        {
            if (!countLatch.TryTake(Gone, out var grade)) return false;
            Counts.Record(continuation, grade);
            return true;
        }
        internal void ForgetUnconfirmedChest() { countLatch.Reset(); Gone = false; }
        internal bool MoveTo(Vector3 position) { Moves++; return true; }
        internal bool MoveToInteract(Vector3 position) => true;
        internal bool IsNavigating() => false;
        internal bool TryUseElixir()
        {
            UseAttempts++;
            if (!UseSucceeds || OccultPot.Core.Game.InventoryReader.Recast > 0.15f) return false;
            Uses++;
            return true;
        }
    }
}
namespace FFXIVClientStructs.FFXIV.Client.Game
{
    internal enum ActionType { GeneralAction }
    internal unsafe struct ActionManager
    {
        private static readonly nint Address = System.Runtime.InteropServices.Marshal.AllocHGlobal(1);
        internal static bool Ready = true, Throw, Accept = true;
        internal static int Calls;
        internal static uint LastAction;
        internal static ActionManager* Instance() => Ready ? (ActionManager*)Address : null;
        internal bool UseAction(ActionType type, uint id)
        {
            Calls++; LastAction = id;
            if (Throw) throw new NullReferenceException("simulated unavailable native service");
            return Accept;
        }
    }
}
