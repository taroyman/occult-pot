using OccultPot.Core.Dig;
using OccultPot.Core.Game;
using OmenTools.Dalamud;
using OccultPot.Core.Adapters;
using OccultPot.Core.Data;
using OccultPot.Models;
using OmenTools.OmenService;
using OmenTools.Interop.Game.AddonEvent;
using FFXIVClientStructs.FFXIV.Client.UI.Info;
using FFXIVClientStructs.FFXIV.Component.GUI;

var failures = 0;
var passed = 0;
void Check(bool condition, string message = "unexpected result") { if (!condition) throw new Exception(message); }
void Run(string name, Action action)
{
    PlayerReader.Reward = true; PlayerReader.Busy = false; PlayerReader.Available = true;
    PlayerReader.Mounted = false; InventoryReader.Recast = 0; DLog.Lines.Clear();
    PlayerReader.Combat = false; PlayerReader.BetweenAreas = false;
    try { action(); passed++; Console.WriteLine($"PASS {name}"); }
    catch (Exception ex) { failures++; Console.WriteLine($"FAIL {name}: {ex.Message}"); }
}
(OccultCrescentPotRunner r, OccultPotHooks h) NewChest(bool acceptInteraction = true)
{
    var h = new OccultPotHooks();
    var r = new OccultCrescentPotRunner(h);
    Check(r.Start().Success, "start failed");
    h.ChestVisible = true;
    r.EnqueueChat("发现了财宝");
    Tick(r, h, 0);
    Check(r.Status == OccultPotStatus.OpeningChest, "not opening");
    h.OpenSucceeds = acceptInteraction;
    Tick(r, h, 0.4);
    return (r, h);
}
void Tick(OccultCrescentPotRunner r, OccultPotHooks h, double time) { h.NowSeconds = time; r.Tick(time); }
void Gone(OccultCrescentPotRunner r, OccultPotHooks h, double time = 1)
{
    h.ChestVisible = false; h.Gone = true; Tick(r, h, time);
}
(OccultCrescentPotRunner r, OccultPotHooks h) Continuation()
{
    var (r, h) = NewChest(); Gone(r, h); Tick(r, h, 3.01);
    Check(r.Status == OccultPotStatus.WaitingMedicine, "did not enter continuation");
    Check(h.RerollOnly && h.Stops.Count == 0, "continuation ended session");
    return (r, h);
}

Run("1531 overrides Farewell and LureExhausted", () => {
    var (r, h) = NewChest();
    r.EnqueueChat("有缘再会"); r.EnqueueChat("撒娇罐耗尽了力量");
    Gone(r, h); Tick(r, h, 3.01);
    Check(r.Status == OccultPotStatus.WaitingMedicine && h.RerollOnly && h.Stops.Count == 0, "premature completion");
    Tick(r, h, 3.02); Check(h.Uses == 1, "no second elixir");
});
Run("full 2-second settle applies before continuation", () => {
    var (r, h) = NewChest(); Gone(r, h); Tick(r, h, 2.99);
    Check(r.Status == OccultPotStatus.OpeningChest && h.Uses == 0 && h.Stops.Count == 0, "settle skipped");
    Tick(r, h, 3.01); Check(h.RerollOnly, "no continuation after settle");
});
Run("late 1531 wins during settle with Farewell", () => {
    var (r, h) = NewChest(); PlayerReader.Reward = false; r.EnqueueChat("有缘再会");
    Gone(r, h); Tick(r, h, 2.5); Check(h.Stops.Count == 0, "early finish");
    PlayerReader.Reward = true; Tick(r, h, 3.01); Check(h.RerollOnly, "lost late status");
});
Run("no continuation text needed for active second elixir", () => {
    var (r, h) = Continuation(); Tick(r, h, 3.02);
    Check(h.Uses == 1, "still waiting for text or 8 seconds");
});
Run("first chest still visible and interaction fails", () => {
    var (r, h) = NewChest(false); Tick(r, h, 1); Tick(r, h, 4); Tick(r, h, 25);
    Check(r.Status == OccultPotStatus.OpeningChest && h.Uses == 0 && !h.RerollOnly && h.Stops.Count == 0, "visible chest treated as opened");
});
Run("successful interaction waits for disappearance", () => {
    var (r, h) = NewChest(); h.OpenSucceeds = true;
    Tick(r, h, 1); Tick(r, h, 4); Check(!h.RerollOnly && h.Stops.Count == 0, "interact is not disappearance");
    Gone(r, h, 5); Tick(r, h, 7.01); Check(h.RerollOnly, "no continuation");
});
Run("chest reappearance restarts settle", () => {
    var (r, h) = NewChest(); Gone(r, h); h.ChestVisible = true; Tick(r, h, 2);
    Gone(r, h, 3); Tick(r, h, 4); Check(!h.RerollOnly, "old disappearance reused");
    Tick(r, h, 5.01); Check(h.RerollOnly, "new settle not completed");
});
Run("busy and unavailable player cannot use second elixir", () => {
    var (r, h) = Continuation(); PlayerReader.Busy = true; Tick(r, h, 3.1); Tick(r, h, 10);
    Check(h.Uses == 0, "used while busy"); PlayerReader.Busy = false; PlayerReader.Available = false;
    Tick(r, h, 11); Check(h.Uses == 0, "used while unavailable");
    PlayerReader.Available = true; Tick(r, h, 12); Check(h.Uses == 1, "did not recover");
});
Run("prior elixir cooldown is not a second use", () => {
    var (r, h) = Continuation(); InventoryReader.Recast = 6;
    Tick(r, h, 3.1); Tick(r, h, 5);
    Check(r.Status == OccultPotStatus.WaitingMedicine && h.Uses == 0, "old cooldown advanced phase");
    InventoryReader.Recast = 0; Tick(r, h, 6.3); Check(h.Uses == 1, "no use after cooldown");
});
Run("no status completes exactly once after settle", () => {
    var (r, h) = NewChest(); PlayerReader.Reward = false; Gone(r, h); Tick(r, h, 2.99);
    Check(h.Stops.Count == 0, "early completion"); Tick(r, h, 3.01); Tick(r, h, 10);
    Check(r.Status == OccultPotStatus.Completed && h.Stops.SequenceEqual(new[] { StopReason.Completed }), "callback count/reason wrong");
});
Run("auxiliary text grants bounded extra status grace", () => {
    var (r, h) = NewChest(); PlayerReader.Reward = false;
    r.EnqueueChat("更多的圣灵药，再帮你找一次"); Gone(r, h); Tick(r, h, 3.01);
    Check(h.Stops.Count == 0 && h.Uses == 0, "ignored hint grace");
    PlayerReader.Reward = true; Tick(r, h, 4); Check(h.RerollOnly && r.Status == OccultPotStatus.WaitingMedicine, "late reward not accepted");
});
Run("stale auxiliary text alone cannot cause infinite continuation", () => {
    var (r, h) = NewChest(); PlayerReader.Reward = false;
    r.EnqueueChat("第二处财宝"); Gone(r, h); Tick(r, h, 3.01); Tick(r, h, 5.01);
    Check(r.Status == OccultPotStatus.Completed && h.Uses == 0, "continued on text alone");
});
Run("status disappears before second elixir", () => {
    var (r, h) = Continuation(); PlayerReader.Reward = false; Tick(r, h, 3.1); Tick(r, h, 5.2);
    Check(h.Uses == 0 && r.Status == OccultPotStatus.Completed, "used without status or got stuck");
});
Run("transient status loss before second elixir recovers", () => {
    var (r, h) = Continuation(); PlayerReader.Reward = false; Tick(r, h, 3.1);
    PlayerReader.Reward = true; Tick(r, h, 4); Check(h.Uses == 1 && h.Stops.Count == 0, "transient loss ended run");
});
Run("second direction hint scans only last 20 points including fallback", () => {
    var (r, h) = Continuation(); Tick(r, h, 3.02);
    r.EnqueueChat("财宝在正东方向，很近"); Tick(r, h, 3.1);
    var reroll = OccultPotChestTables.GetPositions(h.TerritoryID, null, true);
    Check(r.Status == OccultPotStatus.WaitingChest && h.Moves > 0, "scan not started");
    Check(reroll.Contains(r.GetSnapshot().TargetPosition), "fallback escaped reroll table");
    Check(r.GetSnapshot().RemainingCandidates <= 20, "too many continuation candidates");
    Check(DLog.Lines.Any(x => x.Contains("continuation-direction-hint")) && DLog.Lines.Any(x => x.Contains("continuation-scan")), "missing hint/scan log");
});
Run("rejected second use retries without ContinuationReady", () => {
    var (r, h) = Continuation(); Tick(r, h, 3.02);
    r.EnqueueChat("打开第一个财宝后才能用圣灵药"); Tick(r, h, 3.1);
    Check(h.Uses == 1, "retry spam"); Tick(r, h, 4.3); Check(h.Uses == 2, "no retry");
});
Run("missing reply retries second elixir with bounded timeout", () => {
    var (r, h) = Continuation(); Tick(r, h, 3.02); Tick(r, h, 4.3);
    Check(r.Status == OccultPotStatus.WaitingHint && h.Uses == 1, "not waiting for hint");
    Tick(r, h, 5); Check(h.Uses == 1, "retry too early"); Tick(r, h, 8.1); Check(h.Uses == 2, "no retry after missing reply");
    Tick(r, h, 65); Check(r.Status == OccultPotStatus.Failed && h.Stops.Count == 1, "missing-hint watchdog lost");
});
Run("unavailable elixir fails with original watchdog", () => {
    var (r, h) = Continuation(); h.UseSucceeds = false; Tick(r, h, 3.1); Tick(r, h, 64);
    Check(r.Status == OccultPotStatus.Failed && h.Uses == 0, "elixir timeout lost");
});
Run("second chest completes only after its own settle", () => {
    var (r, h) = Continuation(); Tick(r, h, 3.02);
    r.EnqueueChat("财宝在西北方向，很远"); Tick(r, h, 3.1);
    h.ChestVisible = true; r.EnqueueChat("发现了财宝"); Tick(r, h, 4); Tick(r, h, 4.4);
    PlayerReader.Reward = false; r.EnqueueChat("有缘再会"); Gone(r, h, 5); Tick(r, h, 6.99);
    Check(h.Stops.Count == 0, "second chest ended early"); Tick(r, h, 7.01);
    Check(r.Status == OccultPotStatus.Completed && h.Stops.Count == 1, "second chest did not finish");
});
Run("normal first-round direction and use remain functional", () => {
    var h = new OccultPotHooks(); var r = new OccultCrescentPotRunner(h); r.Start(); Tick(r, h, 0);
    Check(h.Uses == 1, "first use missing"); r.EnqueueChat("财宝在正东方向，很远"); Tick(r, h, 0.1);
    Check(r.Status == OccultPotStatus.WaitingChest && !h.RerollOnly && h.Moves > 0, "normal scan changed");
});
Run("territory change still stops safely", () => {
    var (r, h) = Continuation(); h.TerritoryID = 1346; Tick(r, h, 3.1);
    Check(r.Status == OccultPotStatus.Failed && h.Stops.SequenceEqual(new[] { StopReason.TerritoryChanged }), "territory guard lost");
});
Run("both island tables keep exact last 20 points", () => {
    foreach (var id in new uint[] { 1252, 1346 })
    {
        var all = OccultPotChestTables.GetAll(id); var reroll = OccultPotChestTables.GetPositions(id, null, true);
        Check(all.Count == 80 && reroll.SequenceEqual(all.Skip(60)), "table slice changed");
    }
});
Run("diagnostic logs contain state and item id", () => {
    var (r, h) = Continuation(); Tick(r, h, 3.02);
    Check(DLog.Lines.Any(x => x.Contains("chest-opened-or-gone")), "missing chest log");
    Check(DLog.Lines.Any(x => x.Contains("item=2003296") && x.Contains("status1531=True")
        && x.Contains("farewellPending=") && x.Contains("lureExhausted=") && x.Contains("awaitingContinuation=")
        && x.Contains("continuationReady=")), "missing state diagnostics");
});
Run("count classifier reads CN treasure and event-object models", () => {
    foreach (var id in new uint[] {1596,5478}) Check(ChestGradeClassifier.Classify(id, "宝箱") == OccultPot.Models.ChestGrade.Bronze, "bronze");
    foreach (var id in new uint[] {1597,5479}) Check(ChestGradeClassifier.Classify(id, "宝箱") == OccultPot.Models.ChestGrade.Silver, "silver");
    foreach (var id in new uint[] {1598,11500}) Check(ChestGradeClassifier.Classify(id, "宝箱") == OccultPot.Models.ChestGrade.Gold, "gold");
    Check(ChestGradeClassifier.Classify(0,"黄金财宝箱") == OccultPot.Models.ChestGrade.Gold, "named gold");
    Check(ChestGradeClassifier.Classify(0,"白银财宝箱") == OccultPot.Models.ChestGrade.Silver, "named silver");
    Check(ChestGradeClassifier.Classify(0,"青铜财宝箱") == OccultPot.Models.ChestGrade.Bronze, "named bronze");
});
Run("unknown or conflicting grade is never guessed as gold", () => {
    Check(ChestGradeClassifier.Classify(99999,"宝箱") == OccultPot.Models.ChestGrade.Unknown, "unknown model");
    Check(ChestGradeClassifier.Classify(5478,"黄金财宝箱") == OccultPot.Models.ChestGrade.Unknown, "conflict");
});
Run("unopened or failed interaction does not count", () => {
    var latch = new ChestCountLatch(); latch.Observe(5, OccultPot.Models.ChestGrade.Gold);
    Check(!latch.TryTake(true, out _), "just seeing counted");
    latch.Interacted(false); Check(!latch.TryTake(true, out _), "failed interaction counted");
    latch.Interacted(true); Check(!latch.TryTake(false, out _), "still-visible chest counted");
    Check(latch.TryTake(true, out _), "opened chest missing");
    Check(!latch.TryTake(true, out _), "duplicate count");
});
Run("new chest and snapshot cannot inherit prior interaction", () => {
    var latch = new ChestCountLatch(); latch.Observe(5, OccultPot.Models.ChestGrade.Gold); latch.Interacted(true);
    latch.Observe(6, OccultPot.Models.ChestGrade.Silver); Check(!latch.TryTake(true, out _), "new id inherited acceptance");
    latch.Interacted(true); latch.Reset(); Check(!latch.TryTake(true, out _), "snapshot inherited count");
});
Run("initial gold silver bronze and continuation gold stay separate", () => {
    var counts = new OccultPot.Models.DigStatistics();
    foreach(var g in new[]{OccultPot.Models.ChestGrade.Gold,OccultPot.Models.ChestGrade.Silver,OccultPot.Models.ChestGrade.Bronze}) counts.Record(false,g);
    counts.Record(true,OccultPot.Models.ChestGrade.Gold); counts.Record(true,OccultPot.Models.ChestGrade.Unknown);
    Check(counts.InitialGold==1 && counts.InitialSilver==1 && counts.InitialBronze==1 && counts.ContinuationGold==1 && counts.ContinuationOther==1, "wrong bucket");
});
Run("statistics survive JSON roundtrip and empty old config", () => {
    var options = new System.Text.Json.JsonSerializerOptions {IncludeFields=true};
    var counts = new OccultPot.Models.DigStatistics { InitialGold=7, InitialSilver=8, InitialBronze=9, ContinuationGold=10 };
    var saved = System.Text.Json.JsonSerializer.Serialize(counts,options);
    var loaded = System.Text.Json.JsonSerializer.Deserialize<OccultPot.Models.DigStatistics>(saved,options)!;
    Check(loaded.InitialGold==7 && loaded.InitialSilver==8 && loaded.InitialBronze==9 && loaded.ContinuationGold==10, "lost persistence");
    Check(System.Text.Json.JsonSerializer.Deserialize<OccultPot.Models.DigStatistics>("{}",options)!.InitialGold==0, "old config incompatible");
});
Run("runner counts first chest then continuation once each", () => {
    var (r,h)=NewChest(); h.Grade=OccultPot.Models.ChestGrade.Silver; h.OpenSucceeds=true; Tick(r,h,1);
    Gone(r,h,2); Tick(r,h,3.9); Check(h.Counts.InitialSilver==0,"counted before settle");
    Tick(r,h,4.01); Check(h.Counts.InitialSilver==1 && h.Counts.ContinuationGold==0,"first bucket wrong");
    Tick(r,h,4.02); r.EnqueueChat("财宝在西北方向，很远"); Tick(r,h,4.1);
    h.ChestId=2; h.Grade=OccultPot.Models.ChestGrade.Gold; h.ChestVisible=true; r.EnqueueChat("发现了财宝"); Tick(r,h,5); Tick(r,h,5.5);
    PlayerReader.Reward=false; Gone(r,h,6); Tick(r,h,8.01); Tick(r,h,9);
    Check(h.Counts.InitialSilver==1 && h.Counts.ContinuationGold==1,"continuation duplicate or wrong bucket");
});
Run("runner completion without accepted interaction adds no count", () => {
    var (r,h)=NewChest(false); PlayerReader.Reward=false; Gone(r,h); Tick(r,h,3.01);
    Check(h.Counts.InitialGold==0 && h.Counts.InitialUnknown==0,"despawn falsely counted");
});
void ResetMountThrottle()
{
    typeof(OccultPot.Core.Adapters.MountActions).GetField("nextDismountUTC",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static)!.SetValue(null,default(DateTime));
    FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Calls=0;
    FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Ready=true;
    FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Throw=false;
    FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Accept=true;
}
Run("dismount uses game action 23 and throttles repeated ticks", () => {
    ResetMountThrottle(); PlayerReader.Mounted=true;
    Check(OccultPot.Core.Adapters.MountActions.TryDismount(),"action not accepted");
    for(var i=0;i<20;i++) OccultPot.Core.Adapters.MountActions.TryDismount();
    Check(FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Calls==1 && FFXIVClientStructs.FFXIV.Client.Game.ActionManager.LastAction==23,"wrong action or repeated flood");
});
Run("dismount tolerates missing or throwing action service", () => {
    ResetMountThrottle(); PlayerReader.Mounted=true; FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Ready=false;
    Check(!OccultPot.Core.Adapters.MountActions.TryDismount(),"null manager accepted");
    ResetMountThrottle(); FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Throw=true;
    Check(!OccultPot.Core.Adapters.MountActions.TryDismount(),"throw escaped");
    Check(DLog.Lines.Count(x=>x.Contains("下坐骑动作"))<=1,"error flood");
});
Run("dismount skips busy unavailable and unmounted players", () => {
    ResetMountThrottle(); Check(!OccultPot.Core.Adapters.MountActions.TryDismount(),"unmounted request");
    PlayerReader.Mounted=true; PlayerReader.Busy=true; Check(!OccultPot.Core.Adapters.MountActions.TryDismount(),"busy request");
    PlayerReader.Busy=false; PlayerReader.Available=false; Check(!OccultPot.Core.Adapters.MountActions.TryDismount(),"unavailable request");
    Check(FFXIVClientStructs.FFXIV.Client.Game.ActionManager.Calls==0,"should not use native action");
});
const long planNow = 100000;
RemoteIslandSnapshot Row(CnDataCenterKind dc, ushort territory, int elapsed, bool dead = false) =>
    new(dc, territory, planNow, planNow - elapsed, 0, dead ? planNow - 1 : 0, 0);
List<(CnDataCenterKind Kind, uint WorldID)> worlds = [(CnDataCenterKind.Chocobo, 1), (CnDataCenterKind.Moogle, 2)];
Run("26-minute current crowd timer loses to 15-minute other DC", () => {
    RemoteIslandSnapshot[] rows = [Row(CnDataCenterKind.Chocobo,1252,240), Row(CnDataCenterKind.Moogle,1252,900)];
    Check(OccultTrackerPlanner.TryPickVisit(rows,worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v),"missing target");
    Check(v.DC==CnDataCenterKind.Moogle && v.WaitSeconds==900 && v.Kind==PotKind.South,"stayed or wrong side");
    Check(OccultTrackerPlanner.TryPickVisit(rows,[worlds[0]],1,1252,planNow,CnDataCenterKind.Chocobo,out var current,onlyTerritory:1252),"missing current timer");
    Check(current.WaitSeconds==1560 && current.Kind==PotKind.South && !current.Alive,"26-minute timer mismatch");
});
Run("26-minute completed pot loses to 15-minute other island in same DC", () => {
    RemoteIslandSnapshot[] rows = [Row(CnDataCenterKind.Chocobo,1252,240,true), Row(CnDataCenterKind.Chocobo,1346,900)];
    Check(OccultTrackerPlanner.TryPickVisit(rows,worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v),"missing target");
    Check(v.Territory==1346 && v.WaitSeconds==900,"wrong island");
});
Run("3-minute current timer beats 1-minute remote timer plus 5-minute travel", () => {
    RemoteIslandSnapshot[] rows = [Row(CnDataCenterKind.Chocobo,1252,1620),Row(CnDataCenterKind.Moogle,1252,1740)];
    Check(OccultTrackerPlanner.TryPickVisit(rows,worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v) && v.DC==CnDataCenterKind.Chocobo && v.WaitSeconds==180,"ignored travel time");
});
Run("local running FATE beats future remote timer", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Moogle,1252,1740)],worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v,localRunningKind:PotKind.North),"no running FATE");
    Check(v.DC==CnDataCenterKind.Chocobo && v.Alive && v.WaitSeconds==0,"abandoned live FATE");
});
Run("next-target exclusion applies even to local running FATE", () => {
    Check(OccultTrackerPlanner.TryPickVisit([],[worlds[0]],1,1252,planNow,CnDataCenterKind.Chocobo,out var v,
        excludePotTerritory:1252,excludePotKind:PotKind.North,excludePotDC:CnDataCenterKind.Chocobo,
        localRunningKind:PotKind.North,localNorthSpawn:planNow-240),"missing next target");
    Check(v.Kind==PotKind.South && !v.Alive && v.WaitSeconds==1560,$"next target duplicates live current: {v}");
});
Run("early local crowd window stays for brief observation", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Chocobo,1252,60),Row(CnDataCenterKind.Moogle,1252,900)],worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v),"no target");
    Check(v.DC==CnDataCenterKind.Chocobo && v.WaitSeconds==0 && v.Kind==PotKind.North && !v.Alive,"wrong early-window behavior");
});
Run("next-target exclusion also applies after crowd window advances side", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Chocobo,1252,240)],[worlds[0]],1,1252,planNow,CnDataCenterKind.Chocobo,out var v,
        excludePotTerritory:1252,excludePotKind:PotKind.South,excludePotDC:CnDataCenterKind.Chocobo),"missing later target");
    Check(v.Kind==PotKind.North && v.WaitSeconds==3360,"repeated selected future pot");
});
Run("known death immediately advances side even inside early window", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Chocobo,1252,240,true)],[worlds[0]],1,1252,planNow,CnDataCenterKind.Chocobo,out var v),"no target");
    Check(v.Kind==PotKind.South && v.WaitSeconds==1560 && !v.Alive,"resurrected completed pot");
});
Run("missing current data does not hide known remote candidate", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Moogle,1252,900)],worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v) && v.DC==CnDataCenterKind.Moogle,"known remote not chosen");
    Check(!OccultTrackerPlanner.TryPickVisit([],worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out _),"invented unknown timer");
});
Run("local observed phase survives stale incompatible remote island", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Chocobo,1252,1200)], [worlds[0]],1,1252,planNow,CnDataCenterKind.Chocobo,out var v,localNorthSpawn:planNow-240),"no local prediction");
    Check(v.WaitSeconds==1560 && v.Kind==PotKind.South,"mixed island phases");
});
Run("matching ETA keeps current island", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Chocobo,1252,900),Row(CnDataCenterKind.Moogle,1252,900)],worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v) && v.DC==CnDataCenterKind.Chocobo,"unnecessary travel");
});
void ResetParty()
{
    PartyInviteActions.Reset(); LocalPlayerState.IsInAnyParty=true;
    InfoProxyPartyMember.Ready=true; InfoProxyPartyMember.Throw=false; InfoProxyPartyMember.Accept=true; InfoProxyPartyMember.Calls=0;
    AddonSelectYesnoEvent.Text=""; AddonSelectYesnoEvent.Clicks=0;
    PartyInviteActions.LeaveOnce();
}
Run("party waits for combat and zoning to end before direct LeaveParty", () => {
    ResetParty(); PlayerReader.Combat=true; PartyInviteActions.TickLeave();
    PlayerReader.Combat=false; PlayerReader.BetweenAreas=true; PartyInviteActions.TickLeave();
    PlayerReader.BetweenAreas=false; PlayerReader.Busy=true; PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==0,"leave during blocked state");
    PlayerReader.Busy=false; PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==1,"pending leave lost");
});
Run("accepted party leave remains pending until party state clears and throttles", () => {
    ResetParty(); PartyInviteActions.TickLeave();
    for(var i=0;i<50;i++) PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==1,"leave flood");
    LocalPlayerState.IsInAnyParty=false; PartyInviteActions.TickLeave();
    LocalPlayerState.IsInAnyParty=true; PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==1,"left new party after completion");
});
Run("party null or throwing interface does not escape framework tick", () => {
    ResetParty(); InfoProxyPartyMember.Ready=false; PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==0,"null interface called");
    ResetParty(); InfoProxyPartyMember.Throw=true; PartyInviteActions.TickLeave(); PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==1 && DLog.Lines.Count==1,"exception flood");
});
Run("party reset cancels pending leave", () => {
    ResetParty(); PartyInviteActions.Reset(); PartyInviteActions.TickLeave();
    Check(InfoProxyPartyMember.Calls==0,"reset still leaves party");
});
void ResetLeave()
{
    IslandLeave.Reset(); AtkUnitBase.Reset(); GameState.TerritoryType=1252;
    AddonSelectYesnoEvent.Text=""; AddonSelectYesnoEvent.Clicks=0;
}
Run("duty leave opens ready ToDoList and throttles", () => {
    ResetLeave(); AtkUnitBase.Add("_ToDoList",1);
    IslandLeave.TickLeave(); IslandLeave.TickLeave();
    Check(AtkUnitBase.Calls.SequenceEqual(new[] {(1,23,true)}),"wrong callback or flood");
});
Run("duty leave uses menu then confirms only exit-duty prompt", () => {
    ResetLeave(); AtkUnitBase.Add("ContentsFinderMenu",2); AtkUnitBase.Add("_ToDoList",1);
    IslandLeave.TickLeave(); Check(AtkUnitBase.Calls.SequenceEqual(new[] {(2,0,true)}),"wrong menu callback");
    AddonSelectYesnoEvent.Text="确定要离开小队吗？"; IslandLeave.TickLeave();
    Check(AddonSelectYesnoEvent.Clicks==0,"clicked party prompt");
    AddonSelectYesnoEvent.Text="确定要退出任务吗？"; PlayerReader.Busy=true; IslandLeave.TickLeave();
    Check(AddonSelectYesnoEvent.Clicks==1,"could not confirm expected prompt while occupied");
});
Run("duty leave ignores unavailable addons and unrequested confirmation", () => {
    ResetLeave(); AtkUnitBase.Add("ContentsFinderMenu",2,ready:false); AtkUnitBase.Add("_ToDoList",1,visible:false);
    AddonSelectYesnoEvent.Text="确定要退出任务吗？"; IslandLeave.TickLeave();
    Check(AtkUnitBase.Calls.Count==0 && AddonSelectYesnoEvent.Clicks==0,"used unavailable addon or unsolicited popup");
});
Run("duty leave refuses combat and non-island territory", () => {
    ResetLeave(); AtkUnitBase.Add("ContentsFinderMenu",2); PlayerReader.Combat=true; IslandLeave.TickLeave();
    PlayerReader.Combat=false; GameState.TerritoryType=100; IslandLeave.TickLeave();
    Check(AtkUnitBase.Calls.Count==0,"left during combat or unrelated duty");
});
Run("continuation words before first box do not select reroll table", () => {
    var h = new OccultPotHooks(); var r = new OccultCrescentPotRunner(h); r.Start();
    r.EnqueueChat("更多的圣灵药，再帮你找一次");
    r.EnqueueChat("第二处财宝");
    r.EnqueueChat("财宝在正东方向，很远"); Tick(r,h,1);
    Check(!h.RerollOnly && h.Counts.ContinuationGold==0 && r.Status==OccultPotStatus.WaitingChest,"text switched first box to continuation");
    Check(DLog.Lines.Count(x=>x.Contains("ignored-unverified-continuation-text"))==2,"missing rejection evidence");
});
Run("continuation words while first box is still visible cannot advance round", () => {
    var (r,h)=NewChest(); r.EnqueueChat("更多的圣灵药，再帮你找一次"); r.EnqueueChat("第二处财宝");
    Tick(r,h,2); Tick(r,h,10);
    Check(!h.RerollOnly && h.Counts.InitialGold==0 && r.Status==OccultPotStatus.OpeningChest,"visible first box advanced");
});
Run("unaccepted box disappearance plus 1531 and words is not continuation", () => {
    var (r,h)=NewChest(false); r.EnqueueChat("第二处财宝"); r.EnqueueChat("有缘再会");
    Gone(r,h); Tick(r,h,3.01);
    Check(!h.RerollOnly && h.Counts.InitialGold==0 && h.Stops.Count==0,"unconfirmed box accepted");
    r.EnqueueChat("财宝在西北方向，很远"); Tick(r,h,3.1);
    Check(r.Status==OccultPotStatus.WaitingChest && !h.RerollOnly,"first hunt did not recover");
});
Run("false treasure-found text cannot block first-box direction hints", () => {
    var h=new OccultPotHooks(); var r=new OccultCrescentPotRunner(h); r.Start();
    r.EnqueueChat("发现了财宝"); r.EnqueueChat("财宝在正东方向，很远"); Tick(r,h,1);
    Check(r.Status==OccultPotStatus.WaitingChest && r.GetSnapshot().HintCount==1 && !h.RerollOnly,"text entered empty opening state");
});
Run("farewell without a tracked chest cannot establish an opened box", () => {
    var h=new OccultPotHooks(); var r=new OccultCrescentPotRunner(h); r.Start();
    r.EnqueueChat("有缘再会"); r.EnqueueChat("撒娇罐耗尽了力量"); Tick(r,h,1); Tick(r,h,4);
    Check(!h.RerollOnly && h.Counts.InitialGold==0 && h.Stops.Count==0,"text established a phantom chest");
});
Run("second direction requires an actual second elixir request", () => {
    var (r,h)=Continuation(); h.UseSucceeds=false;
    r.EnqueueChat("财宝在正东方向，很远"); Tick(r,h,3.1);
    Check(r.Status==OccultPotStatus.WaitingMedicine && h.Moves==0,"stale direction began second scan");
    h.UseSucceeds=true; Tick(r,h,4.4); r.EnqueueChat("财宝在正东方向，很远"); Tick(r,h,4.5);
    Check(r.Status==OccultPotStatus.WaitingChest && h.Moves>0,"fresh second hint rejected");
});
Run("ordinary TP round stops at 180 seconds even when hints reset phase", () => {
    var h=new OccultPotHooks { UseDiveTp=false }; var r=new OccultCrescentPotRunner(h); r.Start();
    for(var i=0;i<6;i++) { r.EnqueueChat(i%2==0?"财宝在正东方向，很远":"财宝在西北方向，很远"); Tick(r,h,i*30); }
    Tick(r,h,179.99); Check(h.Stops.Count==0,"timeout before deadline");
    Tick(r,h,180); Tick(r,h,181);
    Check(r.Status==OccultPotStatus.Failed && h.Stops.SequenceEqual(new[]{StopReason.SearchTimeout}),"deadline reset or duplicate stop");
    Check(h.Counts.InitialGold==0 && h.Counts.ContinuationGold==0,"timeout counted a box");
});
Run("TP opening failure cannot stay indefinitely past three minutes", () => {
    var (r,h)=NewChest(false); PlayerReader.Busy=true; Tick(r,h,180);
    Check(h.Stops.SequenceEqual(new[]{StopReason.SearchTimeout}) && !h.RerollOnly,"busy or visible box bypassed timeout");
});
Run("ordinary TP continuation has its own deadline without hint resets", () => {
    var (r,h)=Continuation(); h.UseDiveTp=false; Tick(r,h,3.02);
    for(var i=0;i<6;i++) { r.EnqueueChat(i%2==0?"财宝在正东方向，很远":"财宝在西北方向，很远"); Tick(r,h,3.1+i*30); }
    Tick(r,h,182.99); Check(h.Stops.Count==0,"first round's deadline leaked");
    Tick(r,h,183.02); Check(h.Stops.SequenceEqual(new[]{StopReason.SearchTimeout}),"continuation deadline absent");
    Check(h.Counts.InitialGold==1 && h.Counts.ContinuationGold==0,"wrong count on second timeout");
});
Run("walking mode keeps its existing timeout behavior", () => {
    var h=new OccultPotHooks {PreferTp=false}; var r=new OccultCrescentPotRunner(h); r.Start();
    for(var i=0;i<7;i++) { r.EnqueueChat(i%2==0?"财宝在正东方向，很远":"财宝在西北方向，很远"); Tick(r,h,i*30); }
    Check(h.Stops.Count==0,"TP limit applied to walking mode");
});
Run("timeout skip prevents immediately selecting the same island", () => {
    Check(OccultTrackerPlanner.TryPickVisit([Row(CnDataCenterKind.Chocobo,1252,1740),Row(CnDataCenterKind.Moogle,1252,900)],worlds,1,1252,planNow,CnDataCenterKind.Chocobo,out var v,
        excludeTerritory:1252,excludeDC:CnDataCenterKind.Chocobo) && v.DC==CnDataCenterKind.Moogle,"reselected abandoned island");
});
OccultPotHooks ControllerHooks(PotDigController c) => (OccultPotHooks)typeof(PotDigController).GetField("hooks",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance)!.GetValue(c)!;
Run("stale inactive chat does not leak into a new dig session", () => {
    var c=new PotDigController(null,null,null,null); var h=ControllerHooks(c);
    c.OnChatText("财宝在正东方向，很远"); c.OnChatText("第二处财宝"); h.NowSeconds=6;
    c.Start(); c.Tick(); Check(c.GetSnapshot()!.Value.HintCount==0 && !h.RerollOnly,"stale text replayed");
});
Run("fresh pre-start direction hint is retained", () => {
    var c=new PotDigController(null,null,null,null); var h=ControllerHooks(c);
    c.OnChatText("财宝在正东方向，很远"); h.NowSeconds=1; c.Start(); c.Tick();
    Check(c.GetSnapshot()!.Value.HintCount==1,"lost initial elixir response");
});
Run("stop clears pending pre-start messages", () => {
    var c=new PotDigController(null,null,null,null);
    c.OnChatText("财宝在正东方向，很远"); c.Stop(); c.Start(); c.Tick();
    Check(c.GetSnapshot()!.Value.HintCount==0,"stopped session text replayed");
});

Run("zero candidates with 1531 retries initial elixir after cooldown", () => {
    var h = new OccultPotHooks(); var r = new OccultCrescentPotRunner(h); r.Start(true);
    Tick(r,h,4.9); Check(h.Uses == 0, "resent too early");
    Tick(r,h,5); Check(h.Uses == 1 && r.GetSnapshot().RemainingCandidates == 0, "no use at zero candidates");
    Tick(r,h,5.1); Check(h.Uses == 1, "spam");
    r.EnqueueChat("财宝在正东方向，很近"); Tick(r,h,5.2);
    Check(r.Status == OccultPotStatus.WaitingChest && h.Moves > 0, "fresh hint did not resume search");
});
Run("exhausted candidate reveal path still uses elixir", () => {
    var h = new OccultPotHooks(); var r = new OccultCrescentPotRunner(h); r.Start(true);
    typeof(OccultCrescentPotRunner).GetField("status", System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance)!.SetValue(r,OccultPotStatus.WaitingChest);
    Tick(r,h,5); Check(h.Uses == 1 && h.Stops.Count == 0, "exhausted branch blocked use");
});
Run("zero candidates respects eligibility inventory busy availability and cooldown", () => {
    var h = new OccultPotHooks(); var r = new OccultCrescentPotRunner(h); r.Start(true);
    h.ElixirCount=0; Tick(r,h,5); h.ElixirCount=1; PlayerReader.Busy=true; Tick(r,h,6);
    PlayerReader.Busy=false; PlayerReader.Available=false; Tick(r,h,7);
    PlayerReader.Available=true; InventoryReader.Recast=3; Tick(r,h,8);
    InventoryReader.Recast=0; PlayerReader.Reward=false; Tick(r,h,9);
    Check(h.Uses==0,"invalid item use"); PlayerReader.Reward=true; Tick(r,h,10); Check(h.Uses==1,"did not recover");
});
Run("actual chest overrides zero-candidate medicine recovery", () => {
    var h=new OccultPotHooks(); var r=new OccultCrescentPotRunner(h); r.Start(true); h.ChestVisible=true;
    Tick(r,h,5); Check(r.Status==OccultPotStatus.OpeningChest && h.Uses==0,"used instead of opening");
});
Run("zero candidates does not extend 180-second TP deadline", () => {
    var h=new OccultPotHooks(); var r=new OccultCrescentPotRunner(h); r.Start(true);
    for(int t=5;t<60;t+=5)Tick(r,h,t);
    Tick(r,h,180); Check(h.Stops.Contains(StopReason.SearchTimeout),"deadline extended");
});
Run("FATE gate stops nav before dismount and waits for actual flag", () => {
    var g=new OccultPot.Core.Session.FateDismountGate();var events=new List<string>();
    bool T(double t,bool mounted,bool nav) => g.Tick(t,mounted,false,nav,()=>events.Add("stop"),()=>events.Add("dismount"),_=>{},out _);
    Check(!T(0,true,true)&&events.SequenceEqual(new[]{"stop"}),"no initial stop");
    Check(!T(.1,true,true)&&!events.Contains("dismount"),"dismount before nav stopped");
    Check(!T(.2,true,false)&&events.Last()=="dismount"&&!g.Ready,"request treated as confirmation");
    Check(T(.3,false,false)&&g.Ready,"actual flag did not permit combat");
});
Run("FATE gate retries once and then fails without combat", () => {
    var g=new OccultPot.Core.Session.FateDismountGate();int sends=0;
    foreach(var t in new[]{0,.1,1,2,3.1,4,5})g.Tick(t,true,false,false,()=>{},()=>sends++,_=>{},out _);
    Check(!g.Tick(6.2,true,false,false,()=>{},()=>sends++,_=>{},out var failed)&&failed&&sends==2&&!g.Ready,"retry/timeout wrong");
});
Run("FATE gate reset and remount invalidate combat permission", () => {
    var g=new OccultPot.Core.Session.FateDismountGate();
    g.Tick(0,false,false,false,()=>{},()=>{},_=>{},out _);g.Tick(.1,false,false,false,()=>{},()=>{},_=>{},out _);
    Check(g.Ready,"not ready"); Check(!g.Tick(.2,true,false,false,()=>{},()=>{},_=>{},out _)&&!g.Ready,"remount ignored");
    g.Reset();Check(!g.Ready,"reset ignored");
});
Run("stable wait positions persist across calls and differ across characters", () => {
    var center=new System.Numerics.Vector3(200,111,-215);
    var positions=Enumerable.Range(0,200).Select(i=>StablePotStand.Candidate(center,"角色"+i,1,1976,0)).ToArray();
    Check(positions.Distinct().Count()==200,"character collisions");
    for(int i=0;i<200;i++) {var p=positions[i];Check(p==StablePotStand.Candidate(center,"角色"+i,1,1976,0),"unstable");Check(StablePotStand.IsSafeProjection(center,p,p),"radius outside 5-15m");}
    Check(positions[0]!=StablePotStand.Candidate(center,"角色0",2,1976,0),"home world ignored");
});
Run("unsafe projected stands and incomplete detour paths rejected", () => {
    var z=System.Numerics.Vector3.Zero;var end=new System.Numerics.Vector3(10,0,0);
    Check(!StablePotStand.IsSafeProjection(z,end,new(10,10,0)),"unsafe height");
    Check(!StablePotStand.IsSafeProjection(z,end,new(30,0,0)),"projection too far");
    Check(!StablePotStand.IsSafePath(z,end,[]),"empty path");
    Check(!StablePotStand.IsSafePath(z,end,[new(5,0,0)]),"partial path");
    Check(!StablePotStand.IsSafePath(z,end,[new(100,0,0),end]),"long detour");
    Check(StablePotStand.IsSafePath(z,end,[z,end]),"safe path rejected");
});
Run("FATE retry interval starts at actual first request", () => {
    var g=new OccultPot.Core.Session.FateDismountGate();int sends=0;
    g.Tick(0,true,true,false,()=>{},()=>sends++,_=>{},out _);
    g.Tick(2,true,false,false,()=>{},()=>sends++,_=>{},out _);
    g.Tick(3,true,false,false,()=>{},()=>sends++,_=>{},out _);Check(sends==1,"retry before three seconds");
    g.Tick(5,true,false,false,()=>{},()=>sends++,_=>{},out _);Check(sends==2,"missing retry");
    Check(!g.Tick(8,true,false,false,()=>{},()=>sends++,_=>{},out var failed)&&failed,"no bounded timeout");
});
Run("FATE busy/navigation stall is bounded without dismount spam", () => {
    var g=new OccultPot.Core.Session.FateDismountGate();int sends=0;
    g.Tick(0,true,true,true,()=>{},()=>sends++,_=>{},out _);
    g.Tick(9,true,true,true,()=>{},()=>sends++,_=>{},out _);
    Check(!g.Tick(10,true,true,true,()=>{},()=>sends++,_=>{},out var failed)&&failed&&sends==0,"unbounded busy wait");
});
Run("zero-candidate continuation also retries after the first request", () => {
    var(r,h)=Continuation();Tick(r,h,3.02);Tick(r,h,4.3);Check(h.Uses==1,"initial continuation use missing");
    Tick(r,h,8.02);Check(h.Uses==2&&r.GetSnapshot().RemainingCandidates==0,"continuation stuck at zero candidates");
});

(OccultCrescentPotRunner r, OccultPotHooks h) Near(string hint = "财宝在正东方向，离这里很近", bool arrive = true)
{
    var h = new OccultPotHooks { TerritoryID = 1346, NearArrive = arrive, PlayerPosition = new(100, 27, 100) };
    var r = new OccultCrescentPotRunner(h); Check(r.Start(true).Success, "start failed");
    r.EnqueueChat(hint); Tick(r,h,1); return (r,h);
}
Run("north explicit very close uses current position plus 5m and immediate item",()=>{
 var(r,h)=Near();Check(h.ShortTargets.Count==1&&h.Moves==0&&h.Uses==1,"wrong movement/item path");
 Check(System.Numerics.Vector3.Distance(h.ShortTargets[0],new(105,27,100))<.001,"wrong current-position target");
 Check(DLog.Lines.Any(l=>l.Contains("raw=")&&l.Contains("vector="))&&DLog.Lines.Any(l=>l.Contains("near-item")),"missing diagnostics");
});
Run("all eight short step vectors normalized with FFXIV axes",()=>{
 var labels=new[]{"正北","东北","正东","东南","正南","西南","正西","西北"};
 var expected=new[]{new System.Numerics.Vector3(0,0,-1),new(1,0,-1),new(1,0,0),new(1,0,1),new(0,0,1),new(-1,0,1),new(-1,0,0),new(-1,0,-1)};
 for(int i=0;i<8;i++){PotHintParser.TryParseDirection(labels[i],out var d);Check(System.Numerics.Vector3.Distance(PotHintParser.DirectionVector(d),System.Numerics.Vector3.Normalize(expected[i]))<.001,"direction error");}
});
Run("very close English parser preserves clear distance requirement",()=>{
 foreach(var direction in new[]{"north","north-east","northwest","south west","south","east","west"}){
 Check(PotHintParser.TryParseChat($"The treasure is very close to the {direction}.",out var e)&&e.Distance==HintDistance.VeryNear,"English parse failed");}
 Check(!PotHintParser.TryParseChat("The treasure is close to the east.",out _),"weak English hint enabled");
});
Run("south island close hint retains candidate-table path",()=>{
 var h=new OccultPotHooks{TerritoryID=1252};var r=new OccultCrescentPotRunner(h);r.Start(true);r.EnqueueChat("财宝在正东方向，离这里很近");Tick(r,h,1);
 Check(h.ShortTargets.Count==0&&r.Status==OccultPotStatus.WaitingChest&&h.Moves>0,"south changed");
});
Run("ordinary distance and unknown distance never short step",()=>{
 foreach(var distance in new[]{"不远","稍远","很远",""}){var(r,h)=Near("财宝在正东方向，"+distance);Check(h.ShortTargets.Count==0,"ordinary hint used short step");}
});
Run("walking and coordinate-TP modes do not force DiveTP",()=>{
 foreach(var walking in new[]{true,false}){var h=new OccultPotHooks{TerritoryID=1346,PreferTp=!walking,UseDiveTp=walking};var r=new OccultCrescentPotRunner(h);r.Start(true);r.EnqueueChat("财宝在正东方向很近");Tick(r,h,1);Check(h.ShortTargets.Count==0,"travel preference ignored");}
});
Run("3m minimum issues movement instead of treating origin as arrived",()=>{
 var h=new OccultPotHooks{TerritoryID=1346,NearStepMeters=3,NearArrive=true};var r=new OccultCrescentPotRunner(h);r.Start(true);r.EnqueueChat("财宝在正东方向很近");Tick(r,h,1);
 Check(h.ShortTargets.Count==1&&Math.Abs(h.ShortTargets[0].Length()-3)<.001&&h.Uses==1,"3m step skipped");
});
Run("step length clamps at 8m",()=>{
 var h=new OccultPotHooks{TerritoryID=1346,NearStepMeters=100,NearArrive=true};var r=new OccultCrescentPotRunner(h);r.Start(true);r.EnqueueChat("财宝在东北方向很近");Tick(r,h,1);
 Check(Math.Abs(h.ShortTargets[0].Length()-8)<.001,"length unbounded");
});
Run("arrival must be observed before item and move sends once",()=>{
 var(r,h)=Near(arrive:false);Check(h.Uses==0,"used before arrival");Tick(r,h,2);Check(h.ShortTargets.Count==1,"repeated move");h.PlayerPosition=h.ShortTargets[0];Tick(r,h,3);Check(h.Uses==1,"no item at arrival");
});
Run("short step cooldown waits without advancing distant candidates",()=>{
 InventoryReader.Recast=3;var(r,h)=Near();Tick(r,h,3);Check(h.Uses==0&&h.Moves==0&&h.ShortTargets.Count==1,"cooldown advances");InventoryReader.Recast=0;Tick(r,h,4);Check(h.Uses==1,"cooldown never resumes");
});
Run("identical next hint advances again from new player position",()=>{
 var(r,h)=Near();Check(r.EnqueueChat("财宝在正东方向，离这里很近"),"identical hint deduped");Tick(r,h,2);Check(h.ShortTargets.Count==2&&Math.Abs(h.ShortTargets[1].X-110)<.001&&h.Uses==2,"second step failed");
});
Run("subsequent changed direction turns local probe",()=>{
 var(r,h)=Near();r.EnqueueChat("财宝在正北方向很近");Tick(r,h,2);Check(System.Numerics.Vector3.Distance(h.ShortTargets[1],new(105,27,95))<.001,"did not turn");
});
Run("hint arriving before current item cannot move the pending target",()=>{
 var(r,h)=Near(arrive:false);r.EnqueueChat("财宝在正北方向很近");Tick(r,h,2);Check(h.ShortTargets.Count==1&&h.Uses==0,"stale hint moved");
});
Run("attempt cap falls back and cannot reenter for this round",()=>{
 var(r,h)=Near();h.NearMaxAttempts=2;r.EnqueueChat("财宝在正东方向，离这里很近");Tick(r,h,2);r.EnqueueChat("财宝在正东方向，离这里很近");Tick(r,h,3);
 Check(h.ShortTargets.Count==2&&h.Moves>0&&r.Status!=OccultPotStatus.NearProbe,"cap failed");r.EnqueueChat("财宝在正北方向很近");Tick(r,h,4);Check(h.ShortTargets.Count==2,"budget reset by hint");
});
Run("cumulative cap independent of attempts and direction",()=>{
 var(r,h)=Near();h.NearMaxDistance=9;r.EnqueueChat("财宝在正北方向很近");Tick(r,h,2);Check(h.ShortTargets.Count==1&&h.Moves>0,"distance exceeded");
});
Run("followup becoming far falls back immediately",()=>{
 var(r,h)=Near();r.EnqueueChat("财宝在正北方向很远");Tick(r,h,2);Check(h.ShortTargets.Count==1&&r.Status!=OccultPotStatus.NearProbe,"far hint stayed probing");
});
Run("no response falls back with cause after eight seconds",()=>{
 var(r,h)=Near();Tick(r,h,9);Check(r.Status!=OccultPotStatus.NearProbe&&DLog.Lines.Any(l=>l.Contains("no-followup-hint-or-chest-8s")),"missing fallback");
});
Run("unarrived step expires without consuming medicine",()=>{
 var(r,h)=Near(arrive:false);Tick(r,h,16);Check(h.Uses==0&&h.ShortTargets.Count==1&&r.Status!=OccultPotStatus.NearProbe,"arrival timeout failed");
});
Run("busy probe has bounded deadline",()=>{
 var(r,h)=Near(arrive:false);PlayerReader.Busy=true;Tick(r,h,31);Check(r.Status!=OccultPotStatus.NearProbe,"busy loop stuck");
});
Run("visible chest interrupts probing before another jump",()=>{
 var(r,h)=Near();h.ChestVisible=true;Tick(r,h,2);Check(r.Status==OccultPotStatus.OpeningChest&&h.ShortTargets.Count==1,"chest ignored");
});
Run("stopping probe prevents subsequent commands",()=>{
 var(r,h)=Near(arrive:false);r.Stop();Tick(r,h,5);Check(h.ShortTargets.Count==1&&h.Uses==0,"stop leaked action");
});
Run("territory change aborts probe and original 180-second limit remains",()=>{
 var(r,h)=Near(arrive:false);h.TerritoryID=1252;Tick(r,h,2);Check(r.Status==OccultPotStatus.Failed,"zone not aborted");
 var(r2,h2)=Near();Tick(r2,h2,180);Check(h2.Stops.Contains(StopReason.SearchTimeout),"deadline changed");
});
Run("rejected item logs false and retries in place",()=>{
 var(r,h)=Near(arrive:false);h.PlayerPosition=h.ShortTargets[0];h.UseSucceeds=false;Tick(r,h,2);Tick(r,h,3);Check(h.Uses==0&&h.Moves==0,"rejected item moved away");h.UseSucceeds=true;Tick(r,h,4);Check(h.Uses==1,"no retry");
});
Run("production TP navigator uses tight arrival radius for 3m short step",()=>{
 LocalPlayerState.Position=System.Numerics.Vector3.Zero;LocalPlayerState.Object=new();ExternalCommands.Sent.Clear();
 var tp=new TpNavigator();Check(tp.MoveTo(new(3,0,0),0,5,true,.75f),"no send");Check(ExternalCommands.Sent.Count==1&&ExternalCommands.Sent[0]=="/xsz-divetp 3 0 0","3m was treated as arrived");
 Check(!tp.MoveTo(new(6,0,0),1,5,true,.75f)&&ExternalCommands.Sent.Count==1,"ignored cooldown");
 Check(tp.MoveTo(new(6,0,0),5,5,true,.75f)&&ExternalCommands.Sent.Count==2,"cooldown did not clear");
});
Run("ordinary TP navigator retains original 3m arrival tolerance",()=>{
 LocalPlayerState.Position=System.Numerics.Vector3.Zero;ExternalCommands.Sent.Clear();var tp=new TpNavigator();
 Check(tp.MoveTo(new(3,0,0),0)&&ExternalCommands.Sent.Count==0,"ordinary travel changed");
});
Run("near probing in a party still sends DiveTP",()=>{
 LocalPlayerState.Position=System.Numerics.Vector3.Zero;LocalPlayerState.IsInAnyParty=true;ExternalCommands.Sent.Clear();var tp=new TpNavigator();
 Check(tp.MoveTo(new(5,0,0),0,5,true,.75f)&&ExternalCommands.Sent.Single().StartsWith("/xsz-divetp"),"party DiveTP blocked");LocalPlayerState.IsInAnyParty=false;
});

Run("fallback uses guarded native normal exit once per attempt", () => {
    ResetLeave();
    FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Calls=0;
    IslandLeave.TickLeave(OccultPot.Core.Session.ExitMethod.NativeDutyExit);
    IslandLeave.TickLeave(OccultPot.Core.Session.ExitMethod.NativeDutyExit);
    Check(FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Calls==1,"native repeated");
    Check(!FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Forced,"forced exit used");
});
Run("fallback respects game refusal and does not confirm unrelated dialog", () => {
    ResetLeave();
    FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Calls=0;
    FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Permitted=false;
    IslandLeave.TickLeave(OccultPot.Core.Session.ExitMethod.NativeDutyExit);
    Check(FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Calls==0,"ignored game refusal");
    FFXIVClientStructs.FFXIV.Client.Game.Event.EventFramework.Permitted=true;
    ResetLeave();
    IslandLeave.TickLeave(OccultPot.Core.Session.ExitMethod.NativeDutyExit);
    AddonSelectYesnoEvent.Text="确定要退出小队吗？";
    IslandLeave.TickLeave(OccultPot.Core.Session.ExitMethod.NativeDutyExit);
    Check(AddonSelectYesnoEvent.Clicks==0,"confirmed unrelated popup");
});

Run("DiveTP hard deadline at 60 survives hint resets and busy player",()=>{
 var h=new OccultPotHooks { NowSeconds=10000, UseDiveTp=true };var r=new OccultCrescentPotRunner(h);r.Start();
 for(int i=0;i<6;i++){r.EnqueueChat(i%2==0?"财宝在正东方向很远":"财宝在西北方向很远");Tick(r,h,10000+i*10);}
 PlayerReader.Busy=true;Tick(r,h,10059.99);Check(h.Stops.Count==0,"deadline included pre-start time");
 Tick(r,h,10060);Tick(r,h,10061);Check(h.Stops.SequenceEqual(new[]{StopReason.SearchTimeout}),"deadline reset or repeated");
 var line=DLog.Lines.First(x=>x.Contains("DiveTP-search-timeout"));
 foreach(var key in new[]{"SearchStartedAt=","elapsed=60.0","DC=","World=","Instance=","reason=","exitTriggeredAt="})Check(line.Contains(key),key);
});
Run("DiveTP direction-only hint is not a valid dig result",()=>{
 var h=new OccultPotHooks();var r=new OccultCrescentPotRunner(h);r.Start();r.EnqueueChat("财宝在正东方向很远");Tick(r,h,59.9);Tick(r,h,60);Check(h.Stops.Contains(StopReason.SearchTimeout));
});
Run("DiveTP valid chest by deadline proceeds to interaction",()=>{
 var h=new OccultPotHooks();var r=new OccultCrescentPotRunner(h);r.Start();h.ChestVisible=true;r.EnqueueChat("发现了财宝");Tick(r,h,59.9);Tick(r,h,60);Check(h.Stops.Count==0&&r.Status==OccultPotStatus.OpeningChest);
});
Run("DiveTP confirmed continuation gets a new sixty-second deadline",()=>{
 var(r,h)=Continuation();Tick(r,h,3.02);
 for(int i=0;i<6;i++){r.EnqueueChat(i%2==0?"财宝在正东方向很远":"财宝在西北方向很远");Tick(r,h,3.1+i*10);}
 Tick(r,h,63);Check(h.Stops.Count==0);Tick(r,h,63.02);Check(h.Stops.SequenceEqual(new[]{StopReason.SearchTimeout}));
});
Run("pig DC 45s beats cat DC 30s after actual travel cost",()=>{
 RemoteIslandSnapshot[] rows=[new(CnDataCenterKind.Atomos,1252,planNow,planNow+45,0,0,0,4),new(CnDataCenterKind.Cat,1252,planNow,planNow+30,0,0,0,3)];
 Check(OccultTrackerPlanner.TryPickVisit(rows,[(CnDataCenterKind.Atomos,4u),(CnDataCenterKind.Cat,3u)],4,1252,planNow,CnDataCenterKind.Atomos,out var v));
 Check(v.DC==CnDataCenterKind.Atomos&&v.FinalScore==45&&v.TravelETA==5,"cross-DC churn");
});
Run("same DC other world is not mislabeled current instance",()=>{
 RemoteIslandSnapshot[] rows=[new(CnDataCenterKind.Chocobo,1252,planNow,planNow+30,0,0,0,2)];
 Check(OccultTrackerPlanner.TryPickVisit(rows,[(CnDataCenterKind.Chocobo,2u)],1,1055,planNow,CnDataCenterKind.Chocobo,out var v));
 Check(v.WorldID==2&&v.TravelETA==90&&v.SwitchPenalty==35&&v.FinalScore==125);
});
Run("same world different island uses 45s hop plus stickiness",()=>{
 Check(OccultTrackerPlanner.TryPickVisit([new(CnDataCenterKind.Chocobo,1346,planNow,planNow+30,0,0,0,1)],[(CnDataCenterKind.Chocobo,1u)],1,1252,planNow,CnDataCenterKind.Chocobo,out var v));
 Check(v.TravelETA==45&&v.SwitchPenalty==25&&v.FinalScore==70);
});
Run("cross DC uses 180s plus switch penalty",()=>{
 Check(OccultTrackerPlanner.TryPickVisit([new(CnDataCenterKind.Cat,1252,planNow,planNow+30,0,0,0,3)],[(CnDataCenterKind.Cat,3u)],1,1055,planNow,CnDataCenterKind.Chocobo,out var v));
 Check(v.TravelETA==180&&v.SwitchPenalty==60&&v.FinalScore==240);
});
Run("configured same-DC world does not hide current-world candidate",()=>{
 Check(OccultTrackerPlanner.TryPickVisit([new(CnDataCenterKind.Chocobo,1252,planNow,planNow+45,0,0,0,2)],[(CnDataCenterKind.Chocobo,2u)],1,1252,planNow,CnDataCenterKind.Chocobo,out var v));
 Check(v.WorldID==1&&v.FinalScore==45);
});
Run("small spawn advantage does not overcome current-instance stickiness",()=>{
 RemoteIslandSnapshot[] rows=[new(CnDataCenterKind.Chocobo,1252,planNow,planNow+130,0,0,0,1),new(CnDataCenterKind.Chocobo,1346,planNow,planNow+115,0,0,0,1)];
 Check(OccultTrackerPlanner.TryPickVisit(rows,[(CnDataCenterKind.Chocobo,1u)],1,1252,planNow,CnDataCenterKind.Chocobo,out var v));Check(v.Territory==1252&&v.FinalScore==130);
});
TreasureTests.Run(Run);

Console.WriteLine($"RESULT: {passed} passed, {failures} failed");
Environment.ExitCode = failures == 0 ? 0 : 1;

