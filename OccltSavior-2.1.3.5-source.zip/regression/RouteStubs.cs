using OccultPot.Models;
using System.Runtime.InteropServices;
namespace OccultPot.Core.Data
{
    internal static class CnWorldCatalog
    {
        internal static CnDataCenterKind? KindForWorldID(uint id) => (CnDataCenterKind)(id - 1);
        internal static string WorldName(uint id) => id.ToString();
        internal static string DCDisplayName(CnDataCenterKind dc) => dc.ToString();
    }
    internal static class IslandPotLayout { internal static string IslandLabel(ushort id) => id.ToString(); }
}
namespace OmenTools.OmenService
{
    internal static class LocalPlayerState { internal static bool IsInAnyParty;
        internal static object? Object = new();
        internal static System.Numerics.Vector3 Position;
        internal static float DistanceTo3D(System.Numerics.Vector3 p) => System.Numerics.Vector3.Distance(Position,p); }
    internal static class GameState { internal static uint TerritoryType = 1252; }
}
namespace OmenTools.Interop.Game.AddonEvent
{
    internal static class AddonSelectYesnoEvent
    {
        internal static string Text = "";
        internal static int Clicks;
        internal static bool ClickYes(string text)
        {
            if (!Text.Contains(text)) return false;
            Clicks++; Text = ""; return true;
        }
    }
}
namespace FFXIVClientStructs.FFXIV.Client.UI.Info
{
    internal unsafe struct InfoProxyPartyInvite
    {
        internal uint InviteTime;
        internal Name InviterName;
        internal static InfoProxyPartyInvite* Instance() => null;
        internal bool RespondToInvitation(string name, bool accepted) => true;
        internal struct Name { public override string ToString() => ""; }
    }
    internal unsafe struct InfoProxyPartyMember
    {
        private static readonly nint Address = Marshal.AllocHGlobal(1);
        internal static bool Ready = true, Throw, Accept = true;
        internal static int Calls;
        internal static InfoProxyPartyMember* Instance() => Ready ? (InfoProxyPartyMember*)Address : null;
        internal bool LeaveParty()
        {
            Calls++;
            if (Throw) throw new InvalidOperationException("Unavailable");
            return Accept;
        }
    }
}
namespace FFXIVClientStructs.FFXIV.Client.UI.Agent
{
    internal unsafe struct AgentPartyInvite
    {
        internal static AgentPartyInvite* Instance() => null;
        internal void Hide() { }
    }
}
namespace FFXIVClientStructs.FFXIV.Component.GUI
{
    internal enum AtkValueType { Int }
    internal struct AtkValue { internal AtkValueType Type; internal int Int; }
    internal unsafe struct AtkUnitBase
    {
        internal bool IsVisible, IsReady;
        internal int Id;
        private static readonly Dictionary<string,nint> Addons = [];
        internal static readonly List<(int Id,int Value,bool Update)> Calls = [];
        internal static nint Get(string name) => Addons.GetValueOrDefault(name);
        internal static void Reset()
        {
            foreach(var ptr in Addons.Values) Marshal.FreeHGlobal(ptr);
            Addons.Clear(); Calls.Clear();
        }
        internal static void Add(string name, int id, bool ready = true, bool visible = true)
        {
            var ptr = (AtkUnitBase*)Marshal.AllocHGlobal(sizeof(AtkUnitBase));
            *ptr = new AtkUnitBase { IsReady = ready, IsVisible = visible, Id = id };
            Addons.Add(name,(nint)ptr);
        }
        internal void FireCallback(int count, AtkValue* value, bool update) => Calls.Add((Id,value->Int,update));
    }
}

namespace FFXIVClientStructs.FFXIV.Client.Game.Event
{
    internal static class EventFramework
    {
        internal static bool Permitted = true, Throw;
        internal static int Calls;
        internal static bool Forced;
        internal static bool CanLeaveCurrentContent() => Permitted;
        internal static void LeaveCurrentContent(bool forced)
        {
            Calls++; Forced = forced;
            if (Throw) throw new InvalidOperationException("native unavailable");
        }
    }
}
