using OccultPot.Core.DrTreasure;
using OccultPot.Core.Nav;
using OccultPot.Models;

internal static class TreasureTests
{
    internal static void Run(Action<string, Action> run)
    {
        static void Check(bool ok, string message = "unexpected result") { if (!ok) throw new Exception(message); }
        (TreasureAutomationAdapter A, FakeWorld W, List<(string Type,string Reason)> Events) New(ushort territory=1252)
        {
            var w = new FakeWorld { Territory=territory }; var events = new List<(string,string)>();
            return (new(w, (type,reason)=>events.Add((type,reason))), w, events);
        }
        void Search(TreasureAutomationAdapter a) { a.Begin(0,30); a.Tick(0); a.Tick(2); a.Tick(2.1); }
        void ProbeHigh(TreasureAutomationAdapter a) { Search(a); a.OnChat("在当前区域中感知到了4个银宝箱、30个铜宝箱……！"); a.Tick(3); }
        void ReadyRoute(TreasureAutomationAdapter a, FakeWorld w, double now)
        { a.Tick(now); w.Distance=1000; w.AtPoint=true; a.Tick(now+1); a.Tick(now+3); w.AtPoint=false; }
        void Route(TreasureAutomationAdapter a, FakeWorld w) { ProbeHigh(a); ReadyRoute(a,w,4); }
        void Return(TreasureAutomationAdapter a, FakeWorld w, double now)
        { w.Distance=100; a.Tick(now); w.Distance=20; a.Tick(now+1); a.Tick(now+3); }
        void Restored(TreasureAutomationAdapter a, FakeWorld w, double now)
        { a.Tick(now); a.Tick(now+2.1); Check(!a.Active&&w.Job==7,"must restore original job and release control"); }

        foreach(var mode in Enum.GetValues<RunMode>()) run("only AutoPotTreasure can probe or dispatch DR: "+mode,()=>{
            var(a,w,e)=New(); if(RunModePolicy.UsesTreasure(mode))Search(a);
            Check((w.Uses==1)==(mode==RunMode.AutoPotTreasure));
            if(mode!=RunMode.AutoPotTreasure)Check(w.Switches==0&&w.Commands.Count==0&&!a.Active);
        });
        run("parser accepts order, fullwidth digits, spacing and punctuation variations",()=>{
            foreach(var s in new[]{"在当前区域中感知到了４个银宝箱、３０个铜宝箱……！","当前区域：30个铜宝箱，4个银宝箱！","当前区域 银宝箱：4 铜宝箱：30","当前区域 4 只 银宝箱 / 30 座 铜宝箱"})
                Check(TreasureCountParser.TryParse(s,out var silver,out var bronze)&&silver==4&&bronze==30,s);
            foreach(var s in new[]{"4个银宝箱30个铜宝箱","当前区域只有30个铜宝箱","当前区域银宝箱、铜宝箱","当前区域999999999999999个银宝箱30个铜宝箱"})
                Check(!TreasureCountParser.TryParse(s,out _,out _));
        });
        foreach(var count in new[]{0,29})run("bronze below 30 restores without PTP or DR: "+count,()=>{
            var(a,w,e)=New();Search(a);Check(w.Uses==1&&w.Job==0);
            a.OnChat($"当前区域2个银宝箱、{count}个铜宝箱！");a.Tick(3);Restored(a,w,4);
            Check(w.Commands.Count==0&&w.Preparations.Count==0&&e.Last().Type=="Resume");
        });
        foreach(ushort territory in new ushort[]{1252,1346})run("two complete rings with correct PTP before EACH ring territory="+territory,()=>{
            var(a,w,e)=New(territory);ProbeHigh(a);
            Check(a.State==TreasureAutomationState.PrepareOuterStart&&w.Commands.Count==0);
            var outer=territory==1252?"放浪神圣域遗迹":"沉没圣堂前";
            var inner=territory==1252?"石塔水沼":"妖火渔村";
            Check(IslandAethernet.ForTerritory(territory).Any(x=>x.Name==outer&&!x.IsCamp));
            Check(IslandAethernet.ForTerritory(territory).Any(x=>x.Name==inner&&!x.IsCamp));
            ReadyRoute(a,w,4);Check(a.State==TreasureAutomationState.Outer&&!a.HasLeftCamp);
            Return(a,w,10);Check(a.State==TreasureAutomationState.PrepareInnerStart&&!a.HasLeftCamp);
            a.Tick(14);a.Tick(15);Check(a.State==TreasureAutomationState.PrepareInnerStart,"camp startup cannot complete or start inner");
            ReadyRoute(a,w,16);Check(a.State==TreasureAutomationState.Inner&&!a.HasLeftCamp);
            Return(a,w,21);Restored(a,w,25);
            Check(w.Trace.SequenceEqual(new[]{"PTP:"+outer,"/pdr ptreasure 外环","/pdr ptreasure abort","PTP:"+inner,"/pdr ptreasure 内环","/pdr ptreasure abort"}),string.Join("|",w.Trace));
            Check(w.Uses==1&&e.Count(x=>x.Type=="Pause")==1&&e.Last().Type=="Resume");
        });
        run("destination arrival alone is insufficient while still in camp",()=>{
            var(a,w,e)=New();ProbeHigh(a);a.Tick(4);w.AtPoint=true;w.Distance=20;
            a.Tick(5);a.Tick(7);Check(a.State==TreasureAutomationState.PrepareOuterStart&&w.Commands.Count==0);
            a.Tick(23);a.Tick(25);a.Tick(43);Restored(a,w,44);Check(w.Preparations.Count==2&&w.Commands.Count==0);
        });
        run("far from camp but wrong destination never starts DR",()=>{
            var(a,w,e)=New();ProbeHigh(a);w.Distance=1000;a.Tick(4);a.Tick(23);a.Tick(25);a.Tick(43);Restored(a,w,44);
            Check(w.Preparations.Count==2&&w.Commands.Count==0);
        });
        run("second teleport can succeed after first timeout",()=>{
            var(a,w,e)=New();ProbeHigh(a);a.Tick(4);a.Tick(23);a.Tick(25);ReadyRoute(a,w,26);
            Check(a.State==TreasureAutomationState.Outer&&w.Preparations.Count==2&&w.Commands.Single()=="/pdr ptreasure 外环");
        });
        foreach(var inner in new[]{false,true}) foreach(var throws in new[]{false,true}) run($"PTP failure retries exactly once then restores inner={inner} throws={throws}",()=>{
            var(a,w,e)=New();if(inner){Route(a,w);Return(a,w,10);}else ProbeHigh(a);
            w.PrepareOK=false;w.ThrowPrepare=throws;a.Tick(14);a.Tick(16);Restored(a,w,17);
            Check(w.Preparations.Count==(inner?3:2)&&!w.Commands.Contains("/pdr ptreasure 内环"));
            Check(e.Any(x=>x.Reason.Contains("两次预备失败")));
        });
        run("loading resets pre-start stable arrival window",()=>{
            var(a,w,e)=New();ProbeHigh(a);a.Tick(4);w.Distance=1000;w.AtPoint=true;a.Tick(5);
            w.Ready=false;a.Tick(6);w.Ready=true;a.Tick(7);a.Tick(8.9);Check(w.Commands.Count==0);a.Tick(9);Check(a.State==TreasureAutomationState.Outer);
        });
        run("PTP pending dismount stays bounded and fails soft",()=>{
            var(a,w,e)=New();w.PreparePending=true;ProbeHigh(a);a.Tick(4);a.Tick(23);a.Tick(25);a.Tick(43);Restored(a,w,44);Check(w.Commands.Count==0);
        });
        run("DR unavailable fails soft before changing support job",()=>{
            var(a,w,e)=New();w.Available=false;a.Begin(0,30);Check(!a.Active&&w.Switches==0&&w.Uses==0&&e.Last().Type=="Resume");
        });
        run("chat timeout at eight seconds ignores late reply",()=>{
            var(a,w,e)=New();Search(a);a.Tick(10.09);Check(a.State==TreasureAutomationState.WaitChat);
            a.Tick(10.11);a.OnChat("当前区域3个银宝箱40个铜宝箱");Restored(a,w,11);
            Check(w.Commands.Count==0&&w.Preparations.Count==0&&e.Any(x=>x.Type=="Abort"));
        });
        run("departure must be observed AFTER route dispatch before camp return completes",()=>{
            var(a,w,e)=New();Route(a,w);w.Distance=20;a.Tick(8);a.Tick(10);
            Check(a.State==TreasureAutomationState.Outer&&!a.HasLeftCamp);
            a.Tick(52);Restored(a,w,53);Check(w.Commands.Last()=="/pdr ptreasure abort");
        });
        foreach(var inner in new[]{false,true}) run("route timeout aborts and resumes inner="+inner,()=>{
            var(a,w,e)=New();Route(a,w);if(inner){Return(a,w,10);ReadyRoute(a,w,14);}
            w.Distance=100;a.Tick(25);a.Tick(1000);Restored(a,w,1001);
            Check(w.Commands.Last()=="/pdr ptreasure abort"&&e.Any(x=>x.Reason.Contains("900秒")));
        });
        foreach(var throws in new[]{false,true})run("route command rejected or throws aborts partial start: "+throws,()=>{
            var(a,w,e)=New();w.CommandOK=false;w.ThrowCommand=throws;Route(a,w);Restored(a,w,8);
            Check(w.Commands.Contains("/pdr ptreasure abort"));
        });
        run("cast rejection restores and never retries search",()=>{
            var(a,w,e)=New();w.CastOK=false;Search(a);Restored(a,w,3);Check(w.Uses==1&&w.Commands.Count==0);
        });
        run("support switch failure times out without search",()=>{
            var(a,w,e)=New();w.SwitchOK=false;a.Begin(0,30);a.Tick(0);a.Tick(15);a.Tick(16);Check(!a.Active&&w.Job==7&&w.Uses==0);
        });
        run("DR unloaded mid-route aborts and restores",()=>{
            var(a,w,e)=New();Route(a,w);w.Available=false;a.Tick(8);Restored(a,w,9);Check(e.Any(x=>x.Type=="Abort"));
        });
        run("loading/unknown positions cannot finish running route",()=>{
            var(a,w,e)=New();Route(a,w);a.Tick(8);w.Distance=null;a.Tick(9);w.Distance=0;w.Ready=false;a.Tick(10);a.Tick(15);Check(a.State==TreasureAutomationState.Outer);
            w.Ready=true;a.Tick(16);a.Tick(17.9);Check(a.State==TreasureAutomationState.Outer);a.Tick(18);Check(a.State==TreasureAutomationState.PrepareInnerStart);
        });
        run("camp hysteresis ignores boundary jitter before departure",()=>{
            var(a,w,e)=New();Route(a,w);w.Distance=85;a.Tick(8);w.Distance=70;a.Tick(9);a.Tick(12);Check(!a.HasLeftCamp&&a.State==TreasureAutomationState.Outer);
        });
        run("only first matching chat controls the probe",()=>{
            var(a,w,e)=New();Search(a);a.OnChat("当前区域2个银宝箱29个铜宝箱");a.OnChat("当前区域2个银宝箱40个铜宝箱");a.Tick(3);Restored(a,w,4);Check(w.Commands.Count==0);
        });
        foreach(var preparing in new[]{false,true})run("cancel/emergency releases ownership and never restarts preparing="+preparing,()=>{
            var(a,w,e)=New();if(preparing)ProbeHigh(a);else Route(a,w);a.Cancel(8,"EmergencyExit");a.Cancel(8.1,"EmergencyExit");a.Tick(11);
            Check(!a.Active&&w.Job==7&&w.Commands.Count(x=>x=="/pdr ptreasure abort")== (preparing?0:1));
        });
        run("blocked job restoration releases work after twenty seconds and retries later",()=>{
            var(a,w,e)=New();Search(a);w.SwitchOK=false;a.OnChat("当前区域2个银宝箱29个铜宝箱");a.Tick(3);a.Tick(23);
            Check(!a.Active&&a.PendingRestoreJob==7&&e.Last().Type=="Resume");w.SwitchOK=true;a.Tick(25);a.Tick(27);Check(w.Job==7&&!a.PendingRestoreJob.HasValue);
        });
        run("game-read exceptions cannot reset restoration deadline forever",()=>{
            var(a,w,e)=New();Route(a,w);w.ThrowRead=true;a.Tick(8);a.Tick(9);a.Tick(28);
            Check(!a.Active&&a.PendingRestoreJob==7&&e.Last().Type=="Resume");
            w.ThrowRead=false;a.Tick(30);a.Tick(32);Check(w.Job==7&&!a.PendingRestoreJob.HasValue);
        });
        run("territory change aborts without starting inner",()=>{
            var(a,w,e)=New();Route(a,w);w.Territory=1055;a.Tick(8);Check(a.State==TreasureAutomationState.RestoreJob&&!w.Commands.Contains("/pdr ptreasure 内环"));
        });
        run("new island starts a fresh probe while duplicate Begin cannot reset running state",()=>{
            var(a,w,e)=New();Route(a,w);a.Begin(8,30);Check(a.State==TreasureAutomationState.Outer&&w.Uses==1);a.Cancel(9,"stop");a.Tick(12);a.Begin(13,30);a.Tick(13);a.Tick(15);a.Tick(15.1);Check(w.Uses==2);
        });
        run("history retains ten entries plus independent latest stop and pause",()=>{
            var h=new ActivityHistory();var now=DateTimeOffset.Now;h.Record("Pause","DR","ReadyIsland","DC=猪",now);h.Record("Stop","timeout","WorldTravel","DC=猫",now.AddSeconds(1));
            for(int i=0;i<12;i++)h.Record("Resume","resume "+i,"PlanRoute","",now.AddSeconds(2+i));
            Check(h.Entries.Count==10&&h.LastPause!.Reason=="DR"&&h.LastStop!.Reason=="timeout"&&h.LastPauseOrStop==h.LastStop);
        });
    }
    private sealed class FakeWorld : ITreasureAutomationWorld
    {
        public bool Available {get;set;}=true;
        internal int Job=7,Uses,Switches;
        internal float? Distance=0;
        internal ushort Territory=1252;
        internal bool Ready=true,SwitchOK=true,CastOK=true,CommandOK=true,ThrowCommand,AtPoint,PrepareOK=true,ThrowPrepare,PreparePending,ThrowRead;
        internal List<string> Commands=[],Preparations=[],Trace=[];
        public TreasureWorldSnapshot Read()=>ThrowRead?throw new Exception("game data unavailable"):new(Territory,Ready,Job,0,Distance);
        public bool SwitchJob(int job){Switches++;if(SwitchOK)Job=job;return SwitchOK;}
        public bool UseSearch(){Uses++;return CastOK;}
        public bool Command(string text){Commands.Add(text);Trace.Add(text);if(ThrowCommand)throw new Exception("dispatch failure");return CommandOK;}
        public TreasurePreparationResult PrepareStart(string point){Preparations.Add(point);Trace.Add("PTP:"+point);if(ThrowPrepare)throw new Exception("PTP failed");return PreparePending?TreasurePreparationResult.Pending:PrepareOK?TreasurePreparationResult.Sent:TreasurePreparationResult.Failed;}
        public bool AtPreparationPoint(ushort territory,string point)=>territory==Territory&&AtPoint;
        public void Log(string text){}
    }
}
