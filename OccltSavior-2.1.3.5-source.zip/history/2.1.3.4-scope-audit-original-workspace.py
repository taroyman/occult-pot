from pathlib import Path
import re,hashlib,difflib,json
base=Path(r'C:\Users\roy_t\Documents\Codex\2026-09-24\referenced-chatgpt-conversation-this-is-an\outputs\OccltSavior-2.1.3.3-source\occult-pot')
src=Path('work/source/occult-pot')
def method(s,name):
 m=re.search(r'    private (?:static )?\w+ '+name+r'\(',s);assert m,name
 start=s.index('{',m.start());depth=1;i=start+1
 while depth:
  if s[i]=='{':depth+=1
  elif s[i]=='}':depth-=1
  i+=1
 return s[m.start():i]
checks=[]
for f in ['Core/Session/ExitRecoveryController.cs','Core/Adapters/IslandLeave.cs','Core/Game/IslandExitWorld.cs','Core/Dig/NorthNearProbe.cs','Core/Game/TreasureChestInteractor.cs','Core/Adapters/KeitaPotTracker.cs','Core/Carrot/CarrotGameWorld.cs','Core/Carrot/CarrotData.cs','Core/Dig/OccultPotChestTables.cs','ConfigurationLoader.cs']:
 assert (base/f).read_bytes()==(src/f).read_bytes(),f
 checks.append('UNCHANGED '+f)
old=(base/'Core/Session/PotSessionOrchestrator.cs').read_text(encoding='utf-8-sig');new=(src/'Core/Session/PotSessionOrchestrator.cs').read_text(encoding='utf-8-sig')
for name in ['TickWaitFight','BeginWaitCampReturn','TickWaitCampReturn','LocalReconcileReady','IsIslandEntryReady']:
 assert method(old,name)==method(new,name),name
 checks.append('UNCHANGED method '+name)
for token in ['CampReturnIdleGiveUpSeconds = 8.0','LocalReconcileWaitSeconds = 8.0']:
 assert token in new;checks.append('UNCHANGED '+token)
assert 'TreasureAutomation' not in (src/'Core/Adapters/OccultTrackerPlanner.cs').read_text(encoding='utf-8')
assert 'ObjectTable' not in '\n'.join(f.read_text(encoding='utf-8') for f in (src/'Core/Treasure').glob('*.cs'))
checks.extend(['PASS DR independent of ETA planner','PASS DR counts only from chat parser; no ObjectTable count'])
changed=[]
for oldfile in base.rglob('*'):
 if not oldfile.is_file():continue
 rel=oldfile.relative_to(base);f=src/rel
 assert f.exists(),str(rel)
 if oldfile.read_bytes()!=f.read_bytes():changed.append(str(rel))
Path('work/audit.log').write_text('\n'.join(checks)+'\n\nChanged existing files:\n'+'\n'.join(changed),encoding='utf-8')
print('\n'.join(checks))
