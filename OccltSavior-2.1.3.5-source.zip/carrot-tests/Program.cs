using System.Numerics;
using OccultPot;
using OccultPot.Core.Carrot;
using OccultPot.Core.Safety;
using OccultPot.Core.Scheduler;
using OccultPot.Models;
using OmenTools;
using OmenTools.OmenService;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;

int passed=0, failed=0;
void Check(bool v, string message="check failed") { if(!v)throw new Exception(message); }
void Run(string name, Action test) { try { test(); passed++; Console.WriteLine("PASS "+name); } catch(Exception e) { failed++; Console.WriteLine("FAIL "+name+": "+e.Message); } }
(CarrotRunner r, FakeWorld w, PluginConfiguration c, int[] counts) Setup()
{ var w=new FakeWorld();var c=new PluginConfiguration();int[] n=[0];return(new(w,()=>n[0]++),w,c,n); }
void ToUse(CarrotRunner r, PluginConfiguration c)
{ Check(r.TryStart(0,c));r.Tick(0,c);r.Tick(.1,c);r.Tick(1.6,c);r.Tick(1.9,c); }
Run("defaults preserve Pot mode and 60m/1.5s/90s/30s",()=> {var c=new PluginConfiguration();Check(c.RunMode==RunMode.Pot&&c.CarrotSafetyRadius==60&&c.CarrotConfirmSeconds==1.5f&&c.CarrotStartBeforePotSeconds==90&&c.CarrotStopBeforePotSeconds==30);});
Run("legacy Mixed stays Pot plus idle carrots, never opts into DR",()=>{var c=new PluginConfiguration{RunMode=(RunMode)2};c.NormalizeCarrot();Check(c.RunMode==RunMode.Pot&&c.PotIdleCarrots&&!RunModePolicy.UsesTreasure(c.RunMode));});
Run("third mode survives config normalization and threshold defaults to 30",()=>{var c=new PluginConfiguration{RunMode=RunMode.AutoPotTreasure};c.NormalizeCarrot();Check(c.RunMode==RunMode.AutoPotTreasure&&c.BronzeTreasureThreshold==30);});
Run("invalid config normalized",()=>{var c=new PluginConfiguration{RunMode=(RunMode)99,CarrotSafetyRadius=float.NaN,CarrotConfirmSeconds=float.PositiveInfinity,CarrotStartBeforePotSeconds=-1,CarrotStopBeforePotSeconds=1000};c.NormalizeCarrot();Check(c.RunMode==RunMode.Pot&&c.CarrotSafetyRadius==60&&c.CarrotConfirmSeconds==1.5&&c.CarrotStartBeforePotSeconds>c.CarrotStopBeforePotSeconds);});
Run("both maps have 25 candidates, unknown map empty",()=>{Check(CarrotData.GetAll(1252).Count==25&&CarrotData.GetAll(1346).Count==25&&CarrotData.GetAll(1).Count==0);});
Run("player scan excludes only self, includes party and radius boundary",()=>{var self=new Player(1,Vector3.Zero);LocalPlayerState.Object=self;DService.Instance().ObjectTable=[self,new Player(2,new(60,0,0)),new Player(3,new(60.1f,0,0)),new Player(4,new(0,0,2)),new Player(5,Vector3.Zero,false)];Check(PlayerSafetyService.CountPlayers(Vector3.Zero,60)==2);});
Run("player count is centered on destination",()=>{LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[new Player(2,new(100,0,0))];Check(PlayerSafetyService.CountPlayers(new(100,0,0),60)==1&&PlayerSafetyService.CountPlayers(Vector3.Zero,60)==0);});
Run("missing local player fails closed",()=>{LocalPlayerState.Object=null;Check(PlayerSafetyService.CountPlayers(Vector3.Zero,60)==-1);});
Run("first landing pass occupied skips without use",()=>{var(r,w,c,n)=Setup();w.Players=1;r.TryStart(0,c);r.Tick(0,c);Check(w.Teleports==1);r.Tick(.1,c);Check(!r.IsActive&&w.Uses==0);Check(!r.TryStart(1,c));});
Run("second landing pass occupied skips",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);w.Players=1;r.Tick(1.6,c);Check(!r.IsActive&&w.Teleports==1&&w.Uses==0);});
Run("two clear landing passes wait full interval",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);r.Tick(1.59,c);Check(r.Phase==CarrotRunner.Step.Safety&&w.Uses==0);r.Tick(1.6,c);Check(r.Phase==CarrotRunner.Step.Use);r.Tick(1.7,c);Check(w.Uses==1);});
Run("player passing through between confirmations also skips",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);w.Players=1;r.Tick(.5,c);w.Players=0;r.Tick(2,c);Check(!r.IsActive&&w.Uses==0);});
Run("TP cooldown never performs remote safety confirmation",()=>{var(r,w,c,n)=Setup();w.TpSucceeds=false;r.TryStart(0,c);r.Tick(0,c);r.Tick(1.5,c);Check(w.Teleports==0&&w.Uses==0);w.TpSucceeds=true;r.Tick(2,c);r.Tick(2.1,c);r.Tick(3.59,c);Check(w.Uses==0&&r.Phase==CarrotRunner.Step.Safety);r.Tick(3.6,c);r.Tick(3.7,c);Check(w.Uses==1);});
Run("disabled safety cannot bypass hard gate",()=>{var(r,w,c,n)=Setup();c.CarrotPlayerSafetyEnabled=false;Check(!r.TryStart(0,c)&&w.Teleports==0);});
Run("no inventory never navigates or teleports",()=>{var(r,w,c,n)=Setup();w.CarrotCount=0;Check(!r.TryStart(0,c)&&w.Paths==0&&w.Teleports==0);});
Run("unsupported area / unavailable player does not start",()=>{var(r,w,c,n)=Setup();w.Ready=false;Check(!r.TryStart(0,c));});
Run("trace disappearing before second pass cancels",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);w.Traces.Clear();r.Tick(1.5,c);Check(r.Phase==CarrotRunner.Step.Scan&&w.Uses==0);r.Tick(2.5,c);Check(!r.IsActive&&w.Uses==0);});
Run("trace disappearing after arrival never uses item",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(1.5,c);r.Tick(1.7,c);w.Traces.Clear();r.Tick(1.9,c);Check(!r.IsActive&&w.Uses==0);});
Run("teleport timeout never retries command",()=>{var(r,w,c,n)=Setup();w.Arrive=false;r.TryStart(0,c);r.Tick(0,c);r.Tick(1.5,c);r.Tick(16.5,c);Check(!r.IsActive&&w.Teleports==1&&w.Uses==0);});
Run("remote unloaded candidate teleports before trace can be scanned",()=>{var(r,w,c,n)=Setup();w.Traces.Clear();w.Points=[new(500,0,0)];r.TryStart(0,c);r.Tick(0,c);Check(w.Paths==0&&w.Teleports==1&&w.Position.X==500);w.Traces.Add(new(new(500,0,0),55));r.Tick(.1,c);r.Tick(1.6,c);r.Tick(1.7,c);Check(w.Uses==1);});
Run("empty landing skips after bounded object-loading grace",()=>{var(r,w,c,n)=Setup();w.Traces.Clear();w.Points=[new(500,0,0),new(700,0,0)];r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);r.Tick(1.1,c);Check(!r.IsActive&&w.Uses==0&&w.Paths==0);Check(r.TryStart(1.2,c));r.Tick(1.2,c);Check(w.Position.X==700);});
Run("loaded trace is optional priority over candidate table",()=>{var(r,w,c,n)=Setup();w.Points=[new(1,0,0)];r.TryStart(0,c);r.Tick(0,c);Check(w.Position==new Vector3(10,0,0));});
Run("no navigation needed to probe far candidate",()=>{var(r,w,c,n)=Setup();w.Traces.Clear();w.Points=[new(500,0,0)];w.NavigateSucceeds=false;r.TryStart(0,c);r.Tick(0,c);Check(r.IsActive&&w.Teleports==1&&w.Paths==0);});
Run("bounded watchdog still runs while busy",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);w.Busy=true;r.Tick(120,c);Check(!r.IsActive&&w.Teleports==0);});
Run("busy interval invalidates earlier clear check",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);w.Busy=true;r.Tick(1,c);w.Busy=false;r.Tick(2,c);Check(w.Uses==0);r.Tick(3.5,c);r.Tick(3.6,c);Check(w.Uses==1);});
Run("dismount before item use",()=>{var(r,w,c,n)=Setup();w.Mounted=true;ToUse(r,c);Check(w.Uses==0&&!w.Mounted);r.Tick(2.1,c);Check(w.Uses==1);});
Run("inventory loss at destination does not use",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);r.Tick(1.6,c);w.CarrotCount=0;r.Tick(1.9,c);Check(w.Uses==0&&!r.IsActive);});
Run("item request is one-shot while waiting chest",()=>{var(r,w,c,n)=Setup();ToUse(r,c);for(int i=2;i<28;i++)r.Tick(i,c);Check(w.Uses==1&&n[0]==0&&!r.IsActive);});
Run("successful chest confirmed once after two-second settle",()=>{var(r,w,c,n)=Setup();ToUse(r,c);w.HasChest=true;r.Tick(2,c);r.Tick(2.2,c);w.ChestGone=true;r.Tick(3,c);r.Tick(4.99,c);Check(n[0]==0);r.Tick(5,c);r.Tick(6,c);Check(n[0]==1&&!r.IsActive);});
Run("unaccepted disappearing chest never counts",()=>{var(r,w,c,n)=Setup();ToUse(r,c);w.HasChest=true;w.AcceptOpen=false;r.Tick(2,c);r.Tick(2.2,c);w.ChestGone=true;r.Tick(3,c);r.Tick(5,c);Check(n[0]==0&&!r.IsActive);});
Run("cancel after use never opens late chest",()=>{var(r,w,c,n)=Setup();ToUse(r,c);r.Cancel("Pot抢占");w.HasChest=true;r.Tick(3,c);Check(w.Uses==1&&w.Opens==0&&n[0]==0);});
Run("world transition cancels target",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);w.World=2;r.Tick(2,c);Check(!r.IsActive&&w.Teleports==1&&w.Uses==0);});
Run("territory transition cancels target",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);w.Territory=1346;r.Tick(1,c);Check(!r.IsActive);});
Run("combat cancels target",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);w.Combat=true;r.Tick(1,c);Check(!r.IsActive&&w.Paths==0);});
Run("configuration disabled mid-run cancels",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);c.AutoCarrotEnabled=false;r.Tick(2,c);Check(!r.IsActive&&w.Teleports==1&&w.Uses==0);});
Run("skip goes to next point without camping",()=>{var(r,w,c,n)=Setup();w.Traces.Add(new(new(40,0,0),43));w.Players=1;r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);w.Players=0;Check(r.TryStart(.2,c));r.Tick(.2,c);r.Tick(.3,c);r.Tick(1.8,c);Check(w.Teleports==2&&w.Position.X==40);});
Run("mixed scheduler entry and stop boundaries",()=>{Check(CarrotSchedulePolicy.Allow(false,true,91,90,30));Check(!CarrotSchedulePolicy.Allow(false,true,90,90,30));Check(CarrotSchedulePolicy.Allow(true,true,31,90,30));Check(!CarrotSchedulePolicy.Allow(true,true,30,90,30));});
Run("mixed scheduler unknown / active Pot / reward immediately preempts",()=>{foreach(var eta in new double?[]{null,0,29,double.NaN,double.PositiveInfinity})Check(!CarrotSchedulePolicy.Allow(true,true,eta,90,30));Check(!CarrotSchedulePolicy.Allow(true,false,300,90,30));});
Run("preemption during landing safety emits no further teleport or use",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);if(!CarrotSchedulePolicy.Allow(true,true,29,90,30))r.Cancel("Pot");r.Tick(2,c);Check(w.Teleports==1&&w.Uses==0);});
Run("carrot chest rejects preexisting and unrelated gold coffers",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];
 using var pre=new TestChest(10,2009530,Vector3.Zero);using var other=new TestChest(11,2014741,Vector3.Zero);
 DService.Instance().ObjectTable.Add(pre);OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);DService.Instance().ObjectTable.Add(other);
 Check(!OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());OccultPot.Core.Game.TreasureChestInteractor.ClearSnapshot();
});
Run("carrot chest restricts new entities to origin within 8m",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var far=new TestChest(12,2009530,new(9,0,0));DService.Instance().ObjectTable.Add(far);Check(!OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
 using var near=new TestChest(13,2009530,new(3,0,0));DService.Instance().ObjectTable.Add(near);Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
 Check(OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());near.IsTargetable=false;
 Check(OccultPot.Core.Game.TreasureChestInteractor.TryTakeOpenedGrade(out _));Check(!OccultPot.Core.Game.TreasureChestInteractor.TryTakeOpenedGrade(out _));OccultPot.Core.Game.TreasureChestInteractor.ClearSnapshot();
});
Run("shared opener requires an accepted interaction",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var box=new TestChest(14,2009530,Vector3.Zero){Accepted=false};DService.Instance().ObjectTable.Add(box);
 Check(!OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());box.IsTargetable=false;Check(!OccultPot.Core.Game.TreasureChestInteractor.TryTakeOpenedGrade(out _));OccultPot.Core.Game.TreasureChestInteractor.ClearSnapshot();
});
Run("returning to Pot restores original chest-table filter",()=>{
 var pos=OccultPot.Core.Dig.OccultPotChestTables.GetAll(1252)[0];LocalPlayerState.Object=new Player(1,pos);DService.Instance().ObjectTable=[];
 OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);OccultPot.Core.Game.TreasureChestInteractor.SnapshotExisting();
 using var box=new TestChest(15,1789,pos){ObjectKind=4};DService.Instance().ObjectTable.Add(box);Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());Check(OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());
 box.IsTargetable=false;Check(OccultPot.Core.Game.TreasureChestInteractor.TryTakeOpenedGrade(out _));OccultPot.Core.Game.TreasureChestInteractor.ClearSnapshot();
});
Run("late player during dismount prevents use",()=>{var(r,w,c,n)=Setup();w.Mounted=true;ToUse(r,c);w.Players=1;r.Tick(2,c);Check(!r.IsActive&&w.Uses==0);});
Run("nearby unrelated trace cannot validate candidate",()=>{var(r,w,c,n)=Setup();w.Traces.Clear();w.Points=[new(500,0,0)];r.TryStart(0,c);r.Tick(0,c);w.Traces.Add(new(new(520,0,0),55));r.Tick(.1,c);r.Tick(1.1,c);Check(!r.IsActive&&w.Uses==0);});
Run("busy after clear confirmation requires fresh two passes",()=>{var(r,w,c,n)=Setup();r.TryStart(0,c);r.Tick(0,c);r.Tick(.1,c);r.Tick(1.6,c);w.Busy=true;r.Tick(1.7,c);w.Busy=false;r.Tick(2,c);r.Tick(3.49,c);Check(w.Uses==0);r.Tick(3.5,c);r.Tick(3.6,c);Check(w.Uses==1);});

Run("accepted carrot request without inventory decrement never opens",()=>{
 var(r,w,c,n)=Setup();w.ConsumeCarrot=false;ToUse(r,c);w.HasChest=true;r.Tick(2,c);r.Tick(5,c);Check(w.Opens==0&&r.Phase==CarrotRunner.Step.CarrotChestWait);r.Tick(27,c);Check(!r.IsActive&&w.Uses==1&&n[0]==0);
});
Run("delayed inventory synchronization enters dedicated detection state",()=>{
 var(r,w,c,n)=Setup();w.ConsumeCarrot=false;ToUse(r,c);r.Tick(2,c);w.CarrotCount--;r.Tick(3,c);Check(r.Phase==CarrotRunner.Step.CarrotChestDetect);w.HasChest=true;r.Tick(4,c);r.Tick(5,c);Check(w.Opens==1);
});
Run("chest spawn timeout remains bounded while busy",()=>{
 var(r,w,c,n)=Setup();ToUse(r,c);w.Busy=true;r.Tick(27,c);Check(!r.IsActive&&w.Uses==1&&w.Opens==0);
});
Run("chest beyond interaction radius uses existing navigation before opening",()=>{
 var(r,w,c,n)=Setup();ToUse(r,c);w.HasChest=true;w.ChestPosition=new(16,0,0);r.Tick(2,c);r.Tick(3,c);Check(w.Paths==1&&w.Opens==0);w.Position=new(15,0,0);r.Tick(4,c);Check(w.Opens==1);
});
Run("preloaded dormant bunny activates without changing entity id",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];
 using var box=new TestChest(60,2009530,Vector3.Zero){IsTargetable=false};DService.Instance().ObjectTable.Add(box);
 OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);Check(!OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());box.IsTargetable=true;
 Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());Check(OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());box.IsTargetable=false;Check(OccultPot.Core.Game.TreasureChestInteractor.TryTakeOpenedGrade(out _));
});
Run("localized unnamed known bunny supported",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var box=new TestChest(61,2009530,Vector3.Zero){Name=""};DService.Instance().ObjectTable.Add(box);Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
});
Run("new gold treasure object uses shared classifier",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var box=new TestChest(62,12345,Vector3.Zero){ObjectKind=4};DService.Instance().ObjectTable.Add(box);Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
});
Run("another explicit owner rejected even with no nearby player",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var box=new TestChest(63,2009530,Vector3.Zero){Owner=2};DService.Instance().ObjectTable.Add(box);Check(!OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
});
Run("crowd arrival blocks unknown-owner chest even after they leave",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 var other=new Player(2,new(10,0,0));DService.Instance().ObjectTable.Add(other);OccultPot.Core.Game.TreasureChestInteractor.ObserveCarrotSafety();DService.Instance().ObjectTable.Remove(other);
 using var box=new TestChest(64,2009530,Vector3.Zero);DService.Instance().ObjectTable.Add(box);Check(!OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
});
Run("explicit self owner remains usable in crowd",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 DService.Instance().ObjectTable.Add(new Player(2,new(10,0,0)));using var box=new TestChest(65,2009530,Vector3.Zero){Owner=1};DService.Instance().ObjectTable.Add(box);
 Check(OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());box.IsTargetable=false;Check(OccultPot.Core.Game.TreasureChestInteractor.TryTakeOpenedGrade(out _));
});
Run("tracked chest ownership is revalidated before interaction",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var box=new TestChest(66,2009530,Vector3.Zero);DService.Instance().ObjectTable.Add(box);Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());box.Owner=2;Check(!OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());
});
Run("tracked chest distance is revalidated before interaction",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var box=new TestChest(67,2009530,Vector3.Zero);DService.Instance().ObjectTable.Add(box);Check(OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());box.Position=new(20,0,0);Check(!OccultPot.Core.Game.TreasureChestInteractor.TryOpenNearby());
});
Run("multiple unowned new golden chests do not choose arbitrary nearest",()=>{
 LocalPlayerState.Object=new Player(1,Vector3.Zero);DService.Instance().ObjectTable=[];OccultPot.Core.Game.TreasureChestInteractor.SnapshotCarrot(Vector3.Zero);
 using var a=new TestChest(68,2009530,Vector3.Zero);using var b=new TestChest(69,2009530,new(1,0,0));DService.Instance().ObjectTable.Add(a);DService.Instance().ObjectTable.Add(b);Check(!OccultPot.Core.Game.TreasureChestInteractor.HasPotChest());
});
Run("settings normalize new probe defaults bounds and NaN",()=>{
 var c=new PluginConfiguration{NorthNearStepMeters=float.NaN,NorthNearMaxAttempts=100,NorthNearMaxDistance=float.NaN};c.NormalizeCarrot();Check(c.NorthNearStepMeters==5&&c.NorthNearMaxAttempts==12&&c.NorthNearMaxDistance==30);
 c.NorthNearStepMeters=0;c.NorthNearMaxDistance=1000;c.NormalizeCarrot();Check(c.NorthNearStepMeters==3&&c.NorthNearMaxDistance==96);
});
string ConfigFixture()
{var path=Path.Combine(Path.GetTempPath(),"ocsa-config-tests",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(path);return path;}
Run("legacy config migration preserves routes stats mode and old assembly metadata",()=>{
 var dir=ConfigFixture();var legacy=Path.Combine(dir,"OccultPot.json");var current=Path.Combine(dir,"OccltSavior.json");
 var text="""{"$type":"OccultPot.PluginConfiguration, OccultPot", "Version":19,"RunMode":2,"TpIntervalSeconds":7,"PreferTp":true,"UseDiveTp":true,"CarrotChestsOpened":33,"CarrotSafetyRadius":72,"Chocobo":{"$type":"OccultPot.Models.DataCenterRouteConfig, OccultPot","Enabled":false,"DestinationWorldID":123},"DigStatistics":{"InitialGold":22,"ContinuationGold":9}}""";
 File.WriteAllText(legacy,text);var c=ConfigurationLoader.Load(current,_=>{},out var migrated);Check(migrated&&c.RunMode==(RunMode)2&&c.CarrotChestsOpened==33&&c.TpIntervalSeconds==7&&c.CarrotSafetyRadius==72&&c.DigStatistics.InitialGold==22&&c.DigStatistics.ContinuationGold==9&&!c.Chocobo.Enabled&&c.Chocobo.DestinationWorldID==123);
 Check(File.ReadAllText(legacy)==text&&File.ReadAllText(legacy+".pre-OccltSavior-2.1.3.2.bak")==text&&!File.Exists(current));
});
Run("current config wins and migration never overwrites old backup",()=>{
 var dir=ConfigFixture();var legacy=Path.Combine(dir,"OccultPot.json");var current=Path.Combine(dir,"OccltSavior.json");File.WriteAllText(legacy,"{\"CarrotChestsOpened\":1}");File.WriteAllText(legacy+".pre-OccltSavior-2.1.3.2.bak","original backup");
 var c=ConfigurationLoader.Load(current,_=>{},out var migrated);Check(migrated&&c.CarrotChestsOpened==1&&File.ReadAllText(legacy+".pre-OccltSavior-2.1.3.2.bak")=="original backup");
 File.WriteAllText(current,"{\"CarrotChestsOpened\":99}");c=ConfigurationLoader.Load(current,_=>{},out migrated);Check(!migrated&&c.CarrotChestsOpened==99);
});
Run("corrupt current config fails without silently replacing with old settings",()=>{
 var dir=ConfigFixture();var legacy=Path.Combine(dir,"OccultPot.json");var current=Path.Combine(dir,"OccltSavior.json");File.WriteAllText(legacy,"{}");File.WriteAllText(current,"broken");bool threw=false;try{ConfigurationLoader.Load(current,_=>{},out _);}catch(Newtonsoft.Json.JsonException){threw=true;}Check(threw&&File.ReadAllText(current)=="broken");
});

Run("2.1.3.4 history survives configuration serialization",()=>{
 var cfg=new PluginConfiguration();var at=DateTimeOffset.Now;
 cfg.ActivityHistory.Record("Pause","DR 外环","TreasureAutomation","DC=猪;World=A;Instance=1",at);
 cfg.ActivityHistory.Record("Stop","CrossWorldTravel timeout","WorldTravel","DC=猫;World=B;Instance=2",at.AddSeconds(1));
 var json=Newtonsoft.Json.JsonConvert.SerializeObject(cfg);var loaded=Newtonsoft.Json.JsonConvert.DeserializeObject<PluginConfiguration>(json)!;
 Check(loaded.ActivityHistory.Entries.Count==2&&loaded.ActivityHistory.LastStop?.Reason=="CrossWorldTravel timeout"&&loaded.ActivityHistory.LastPause?.At==at);
});
Run("legacy mixed mode becomes pot with idle carrots without losing options",()=>{
 var cfg=new PluginConfiguration{RunMode=RunMode.Mixed,CarrotSafetyRadius=72,TpIntervalSeconds=7};cfg.NormalizeCarrot();
 Check(cfg.RunMode==RunMode.Pot&&cfg.PotIdleCarrots&&cfg.CarrotSafetyRadius==72&&cfg.TpIntervalSeconds==7&&cfg.BronzeTreasureThreshold==30);
});
Console.WriteLine($"RESULT: {passed} passed, {failed} failed");return failed==0?0:1;
