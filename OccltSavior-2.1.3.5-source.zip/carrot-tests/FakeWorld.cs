using System.Numerics;
using OccultPot.Core.Carrot;

sealed class FakeWorld : ICarrotWorld
{
    public ushort Territory {get;set;} = 1252;
    public uint World {get;set;} = 1;
    public bool Ready {get;set;} = true;
    public bool Busy {get;set;}
    public bool Combat {get;set;}
    public bool Mounted {get;set;}
    public int CarrotCount {get;set;} = 2;
    public Vector3 Position {get;set;} = Vector3.Zero;
    public List<CarrotTarget> Traces = [new(new Vector3(10,0,0), 42)];
    public IReadOnlyList<Vector3> Points {get;set;} = [];
    public IReadOnlyList<CarrotTarget> Scan() => Traces.ToArray();
    public bool TraceExists(CarrotTarget target) => Traces.Contains(target);
    public int Players, Teleports, Uses, Opens, Snapshots, Clears, Stops, Paths;
    public bool NavigateSucceeds = true, TpSucceeds = true, Arrive = true, UseSucceeds = true, AcceptOpen = true;
    private bool accepted, counted;
    public bool HasChest {get;set;}
    public bool ChestGone {get;set;}
    public int CountPlayers(Vector3 target, float radius) => Players;
    public bool Navigate(Vector3 target) { Paths++; return NavigateSucceeds; }
    public void StopMovement() => Stops++;
    public bool DiveTp(Vector3 target, double now, float interval) { if(!TpSucceeds)return false; Teleports++; if(Arrive)Position=target; return true; }
    public void Dismount() { Mounted=false; }
    public void SnapshotChests(Vector3 target) { Snapshots++; accepted=counted=false; }
    public bool ConsumeCarrot = true;
    public Vector3? ChestPosition {get;set;}
    public void ObserveChestSafety() { }
    public bool UseCarrot() { if(!UseSucceeds)return false; Uses++; if(ConsumeCarrot)CarrotCount--; return true; }
    public bool OpenChest() { Opens++; accepted |= AcceptOpen; return AcceptOpen; }
    public bool ConfirmChest() { if(!accepted || !ChestGone || counted)return false; counted=true; return true; }
    public void ClearChest() { Clears++; }
    public List<string> Logs = new();
    public void Log(string message) => Logs.Add(message);
}
