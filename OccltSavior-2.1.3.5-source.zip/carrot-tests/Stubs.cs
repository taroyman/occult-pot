using System.Numerics;
using OccultPot.Models;

namespace Dalamud.Configuration { public interface IPluginConfiguration { int Version {get;set;} } }
namespace OccultPot.Core.Data
{
    internal static class CnWorldCatalog { internal static uint HomeWorldID => 1; internal static CnDataCenterKind? HomeDCKind => CnDataCenterKind.Chocobo; }
}
namespace OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds
{
    public interface IGameObject
    {
        uint EntityID {get;} Vector3 Position {get;} bool IsValid();
        nint Address {get;} int ObjectKind {get;} string Name {get;} bool IsTargetable {get;}
    }
    public interface IPlayerCharacter : IGameObject { }
    public record Player(uint EntityID, Vector3 Position, bool Valid = true) : IPlayerCharacter
    { public bool IsValid() => Valid; public nint Address => 0; public int ObjectKind => 1; public string Name => "player"; public bool IsTargetable => true; }
}
namespace OmenTools.OmenService
{
    internal static class LocalPlayerState
    {
        internal static OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IPlayerCharacter? Object;
        internal static float DistanceToObject3D(OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IGameObject obj) => Vector3.Distance(Object!.Position, obj.Position);
    }
}
namespace OmenTools
{
    internal sealed class DService
    {
        private static readonly DService Self = new();
        internal static DService Instance() => Self;
        internal ObjectTable ObjectTable = new();
        internal ClientState ClientState = new();
    }
    internal class ClientState { internal uint TerritoryType = 1252; }
    internal class ObjectTable : List<Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IGameObject>
    {
        internal Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IGameObject? SearchByEntityID(uint id) => this.FirstOrDefault(o=>o.EntityID==id);
        internal Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IGameObject? FindNearest(Vector3 pos, Func<Dalamud.Services.Game.Object.Abstractions.ObjectKinds.IGameObject,bool> filter) => this.Where(filter).OrderBy(o=>Vector3.DistanceSquared(pos,o.Position)).FirstOrDefault();
    }
}
