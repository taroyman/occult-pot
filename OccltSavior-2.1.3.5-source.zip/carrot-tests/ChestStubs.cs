using System.Numerics;
using System.Runtime.InteropServices;
using OmenTools.Dalamud.Services.Game.Object.Abstractions.ObjectKinds;

namespace FFXIVClientStructs.FFXIV.Client.Game.Object { public struct GameObject { public uint BaseId; public uint OwnerId; } }
namespace Lumina.Excel.Sheets
{
    public struct RowRef { public uint RowId; }
    public struct Treasure { public RowRef SGB; }
    public struct EObj { public RowRef SgbPath; }
}
namespace OmenTools.Interop.Game.Lumina
{
    internal static class LuminaGetter { internal static bool TryGetRow<T>(uint id,out T row) { row=default!;return false; } }
}
namespace OmenTools.Dalamud { internal static class DLog { internal static void Debug(string text) { } } }
namespace OmenTools.Extensions
{
    internal static class ObjectExtensions { internal static bool TargetInteract(this IGameObject obj) => obj is TestChest c && c.Accepted; }
}
namespace OccultPot.Core.Game
{
    internal static class PlayerReader
    { internal static bool IsMoving => false; internal static float DistanceTo(Vector3 position) => Vector3.Distance(OmenTools.OmenService.LocalPlayerState.Object!.Position,position); }
}
internal sealed unsafe class TestChest : IGameObject, IDisposable
{
    public uint EntityID {get;init;}
    public Vector3 Position {get;set;}
    public bool IsValid() => true;
    public nint Address {get;}
    public int ObjectKind {get;init;} = 7;
    public string Name {get;init;} = "黄金财宝箱";
    public bool IsTargetable {get;set;} = true;
    public bool Accepted = true;
    public uint Owner { get => ((FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)Address)->OwnerId; set => ((FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)Address)->OwnerId=value; }
    internal TestChest(uint entity,uint id, Vector3 pos)
    {EntityID=entity;Position=pos;Address=Marshal.AllocHGlobal(sizeof(FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject));((FFXIVClientStructs.FFXIV.Client.Game.Object.GameObject*)Address)->BaseId=id; Owner=0;}
    public void Dispose()=>Marshal.FreeHGlobal(Address);
}
