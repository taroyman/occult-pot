from pathlib import Path
import hashlib, sys, difflib
base=Path(sys.argv[1]).resolve()
current=Path(__file__).resolve().parents[1]/'occult-pot'
allowed={'Configuration.cs','Models/RunMode.cs','Ui/CarrotSection.cs','Core/Session/PotSessionOrchestrator.cs','Core/Treasure/TreasureAutomationAdapter.cs','Core/Treasure/TreasureGameWorld.cs'}
changed=[];unchanged=[]
for p in sorted(base.rglob('*.cs')):
 rel=p.relative_to(base)
 if any(x in ('obj','bin') for x in rel.parts):continue
 q=current/rel
 assert q.exists(),f'deleted source: {rel}'
 if p.read_bytes()!=q.read_bytes():
  assert rel.as_posix() in allowed,f'out-of-scope change: {rel}'
  changed.append(rel.as_posix())
 else:unchanged.append(rel.as_posix())
print(f'PASS scope: {len(unchanged)} existing C# files byte-identical; {len(changed)} intended existing C# edits')
for rel in changed:print('CHANGED',rel)
s=(current/'Core/Session/PotSessionOrchestrator.cs').read_text(encoding='utf-8-sig')
b=(base/'Core/Session/PotSessionOrchestrator.cs').read_text(encoding='utf-8-sig')
assert s==b.replace('if (config.TreasureAutomationEnabled)','if (RunModePolicy.UsesTreasure(config.RunMode))')
print('PASS session differs ONLY at mode gate; all FATE wait methods, task queues, DR exclusive Tick branch and ready/pot fallback unchanged')
branch=s[s.index('        if (phase == SessionPhase.TreasureAutomation)'):s.index('        dig.Tick();',s.index('    internal void Tick()'))]
assert 'treasure.Tick(ExitNow);' in branch and 'return;' in branch and 'SessionPhase.ReadyIsland' in branch
assert s.index('if (phase == SessionPhase.TreasureAutomation)',s.index('internal void Tick()')) < s.index('tracker.Tick()',s.index('internal void Tick()'))
assert 'taskHelper.Abort(); find.Stop(); vnav.Stop(); BmrAi.ForceOff();' in s
assert 'carrot.Cancel("DR 接管控制"); carrotOwnsMovement = false;' in s
print('PASS static control audit: active treasure returns before dig, tracker, carrots, background jobs or route planning; handoff cancels queued movement; EmergencyExit remains prior to work')
for rel in ['Core/Dig/DiveSearchDeadline.cs','Core/Scheduler/TravelEstimate.cs','Core/Session/ExitRecoveryController.cs','Core/Session/PotSessionOrchestrator.Exit.cs','Core/Dig/NorthNearProbe.cs','Core/Game/TreasureChestInteractor.cs','Core/Adapters/KeitaPotTracker.cs','Core/Carrot/CarrotRunner.cs','Models/ActivityHistory.cs','Core/Nav/IslandTravel.cs']:
 assert (base/rel).read_bytes()==(current/rel).read_bytes()
 print('UNCHANGED',rel)
new_files={p.relative_to(current).as_posix() for p in current.rglob('*.cs') if not any(x in ('obj','bin') for x in p.relative_to(current).parts)}-{p.relative_to(base).as_posix() for p in base.rglob('*.cs')}
assert new_files=={'Core/Treasure/TreasurePreparationPoints.cs'},new_files
print('PASS only new production file: TreasurePreparationPoints.cs')
treasure='\n'.join(p.read_text(encoding='utf-8-sig') for p in (current/'Core/Treasure').glob('*.cs'))
assert not any(x in treasure for x in ['ObjectTable','TTS','亚返回'])
print('PASS treasure has no remote ObjectTable counting, TTS or return-cast hooks')
patch=[]
for rel in sorted(allowed|new_files|{'OccltSavior.Dev.csproj','OccltSaviorPlugin.csproj','OccltSavior.json','pluginmaster.json','README.md','CHANGELOG.md'}):
 p=base/rel;q=current/rel
 patch.extend(difflib.unified_diff(p.read_text(encoding='utf-8-sig').splitlines(True) if p.exists() else [],q.read_text(encoding='utf-8-sig').splitlines(True),fromfile='a/occult-pot/'+rel,tofile='b/occult-pot/'+rel))
(current.parent/'2.1.3.5-changes.patch').write_text(''.join(patch),encoding='utf-8')
